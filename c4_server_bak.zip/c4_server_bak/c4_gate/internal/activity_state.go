package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"github.com/sirupsen/logrus"
)

func SendActivityState(req *kproto.SendReq) (*kproto.SendResp, error) {
	// 循环所有的session，发送客户端消息
	logrus.Info("通知客户端活动状态：")
	for _, v := range Sessions.GetAllSessions() {
		v.AllocateContext().SetResponseMessage(ktcp.NewMessage(req.Packet.MsgId, req.Packet.Data)).Send()
	}

	return &kproto.SendResp{}, nil
}
