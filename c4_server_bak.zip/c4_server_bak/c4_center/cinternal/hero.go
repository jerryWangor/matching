package cinternal

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kmongo"
	"c4_center/kproto"
	"context"
	"fmt"
	"math/rand"
	"strings"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

var genRand = []string{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"}

func RandGen() string {
	var gen strings.Builder

	for k := 0; k < 9; k++ {
		for i := 0; i < 4; i++ {
			gen.WriteString(genRand[rand.Intn(len(genRand))])
		}
	}

	return gen.String()
}

//获取用户所有英雄
func LoadHeroByUserId(userId string) []*cmongo.Hero {
	var ret []*cmongo.Hero
	kmongo.Get(context.TODO(), kmongo.HeroCollection, &ret, bson.M{"user_id": userId})
	return ret
}

//更新英雄
func ReplaceHero(h *cmongo.Hero) error {
	if !kmongo.ReplaceOne(context.TODO(), kmongo.HeroCollection, bson.M{"_id": h.ID}, h) {
		return fmt.Errorf("update hero error -> %v", h.ID)
	}
	return nil
}

//增加英雄
func InsertHero(h *cmongo.Hero) {
	if !kmongo.InsertOne(context.TODO(), kmongo.HeroCollection, h) {
		logrus.Error("insert hero error.")
	}
}

//get hero by idx
func LoadHeroByIdx(idx string) *cmongo.Hero {
	var ret cmongo.Hero
	kmongo.GetOne(context.TODO(), kmongo.HeroCollection, &ret, bson.M{"_id": idx, "state": bson.M{"$ne": -1}})

	if len(ret.ID) <= 0 {
		return nil
	}

	return &ret
}

func LoadHeroByPos(userId string, pos int32) *cmongo.Hero {
	var ret cmongo.Hero
	kmongo.GetOne(context.TODO(), kmongo.HeroCollection, &ret, bson.M{"user_id": userId, "pos": pos, "state": bson.M{"$ne": -1}})

	if len(ret.ID) <= 0 {
		return nil
	}

	return &ret
}

//获取所有pos != 0 的英雄
func LoadHeroByNoPos(userId string) []*cmongo.Hero {
	var ret []*cmongo.Hero
	kmongo.Get(context.TODO(), kmongo.HeroCollection, &ret, bson.M{"user_id": userId, "pos": bson.M{"$ne": 0}, "state": bson.M{"$ne": -1}})
	return ret
}

func GetInitHero(userid, gene, geneMask string, ballId, grade, level int32) *cmongo.Hero {
	ret := &HeroInit{}
	return ret.InitHero(userid, gene, geneMask, ballId, grade, level)
}

const ratio float64 = 10000

type HeroInit struct {
	*cmongo.Hero
}

func (h *HeroInit) InitHero(userid, gene, geneMask string, ballId, grade, level int32) *cmongo.Hero {
	//shit
	if len(geneMask) <= 0 {
		geneMask = "000000000000000000000000000000000000"
	}

	h.Hero = &cmongo.Hero{ID: primitive.NewObjectID().Hex(), UserID: userid, Gene: gene, GeneMask: geneMask, BallId: ballId, State: cmongo.NORMAL, Grade: grade, Level: level}
	if err := h.LoadHeroConfig(); err != nil {
		logrus.Error(err)
		return nil
	}
	h.SetInitSkill()
	h.SetChessColor()
	return h.Hero
}

func (h *HeroInit) LoadHeroConfig() error {
	h.SkillConfig = make(map[int32]*game_config.SkillData)
	h.SkillEffectConfig = make(map[int32]*game_config.SkillEffectData)
	//英雄配置
	h.HeroConfig = game_config.HeroConfigInstant.GetInfo(h.GetHeroKeyGen())
	h.HeroAttrConfig = game_config.HeroAttrConfigInstant.GetInfo(h.Grade, h.Level)

	if h.HeroConfig == nil || h.HeroAttrConfig == nil {
		return fmt.Errorf("cannot get config . gen -> %v, grade -> %v, level -> %v", h.GetHeroKeyGen(), h.Grade, h.Level)
	}

	return nil
}

func (h *HeroInit) GetHeroKeyGen() string {
	return strings.ToLower(string(h.Gene[0]))
}

//随机初始化技能
func (h *HeroInit) SetInitSkill() {
	h.NSkill = h.RandSkill(h.HeroConfig.NSkill)
	h.USkill = h.RandSkill(h.HeroConfig.USkill)
	h.PSkill_1 = h.RandSkill(h.HeroConfig.PSkill_1)
	h.PSkill_2 = h.RandSkill(h.HeroConfig.PSkill_2)
	h.PSkill_3 = h.RandSkill(h.HeroConfig.PSkill_3)
}

//基础属性
func (h *HeroInit) GetMaxHP() int32 {
	return int32(float64(h.HeroAttrConfig.Hp) * float64(h.HeroConfig.HpParam) / ratio)
}

//基础属性
func (h *HeroInit) GetAttack() int32 {
	return int32(float64(h.HeroAttrConfig.Attack) * float64(h.HeroConfig.AttParam) / ratio)
}

//基础护盾
func (h *HeroInit) GetShield() int32 {
	return int32(float64(h.HeroAttrConfig.Shield) * float64(h.HeroConfig.ShieldParam) / ratio)
}

//随机英雄颜色
func (h *HeroInit) SetChessColor() {
	groups := game_config.ChessColorGroupConfigInstant.GetInfo(h.HeroConfig.ChessColor)
	if len(groups) <= 0 {
		return
	}

	var sum int32
	for _, w := range groups {
		sum += w.Scale
	}

	r := rand.Int31n(sum)
	var t int32
	for _, w := range groups {
		t += w.Scale
		if t > r {
			h.ChessColor = w.ChessColorType
			return
		}
	}
}

//gid = 技能库ID
func (h *HeroInit) RandSkill(gid int32) int32 {
	skills := game_config.SkillGroupConfigInstant.GetInfo(gid)
	if len(skills) <= 0 {
		return 0
	}

	var sum int32
	for _, w := range skills {
		sum += w.Scale
	}

	r := rand.Int31n(sum)
	var t int32
	for _, w := range skills {
		t += w.Scale
		if t > r {
			return w.SkillId
		}
	}

	return skills[len(skills)-1].SkillId
}

//英雄信息返回
func HeroData(h *cmongo.Hero) *kproto.HeroInfo {
	hi := &HeroInit{h}
	hi.LoadHeroConfig()

	ret := &kproto.HeroInfo{}
	ret.Id = hi.ID
	ret.Pos = hi.Pos
	ret.Grade = hi.Grade
	ret.Level = hi.Level
	ret.Class = hi.HeroConfig.Vocation
	ret.Gene = hi.Gene
	ret.GeneMask = hi.GeneMask
	ret.ChessColor = hi.ChessColor
	ret.MaxHp = hi.GetMaxHP()
	ret.MaxEnergy = hi.HeroConfig.MaxEnerge
	ret.CurShield = hi.GetShield()
	ret.Attack = hi.GetAttack()
	ret.Nskill = hi.NSkill
	ret.Uskill = hi.USkill
	ret.UserId = hi.UserID
	ret.State = int32(hi.State)
	ret.HeroConfigId = hi.HeroConfig.HeroId

	return ret
}

func HeroDataToHero(h *kproto.HeroInfo) *cmongo.Hero {
	ret := &cmongo.Hero{}
	ret.ID = h.Id
	ret.UserID = h.UserId
	ret.Grade = h.Grade
	ret.Level = h.Level
	ret.Gene = h.Gene
	ret.GeneMask = h.GeneMask
	ret.Pos = h.Pos
	ret.State = cmongo.HeroState(h.State)
	ret.ChessColor = h.ChessColor
	ret.NSkill = h.Nskill
	ret.USkill = h.Uskill

	return ret
}
