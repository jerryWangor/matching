package room

import (
	"c4_center/container/cmongo"
	"c4_center/kproto"
	"context"
	"time"

	"github.com/sirupsen/logrus"
)

type TableFsm struct {
	Table  *Table
	Ticker time.Ticker
	Ctx    context.Context
	Cancel context.CancelFunc
}

func NewTableFsm(table *Table) *TableFsm {
	ret := &TableFsm{
		Table:  table,
		Ticker: *time.NewTicker(time.Duration(table.Delay)),
	}
	ret.Ctx, ret.Cancel = context.WithCancel(context.TODO())
	return ret
}

func (t *TableFsm) Loop() {
	logrus.Infof("room -> %v start", t.Table.ID)
	for {
		select {
		case <-t.Ctx.Done():
			return
		case <-t.Ticker.C:
			t.state()
		}
	}
}

func (t *TableFsm) state() {
	t.Table.RoundPastTime += t.Table.Delay

	switch t.Table.State {
	case INIT_STATE:
		t.initState()
	case ROLL_STATE:
		t.rollState()
	case PLAY_STATE:
		t.playState()
	case FINISH_STATE:
		t.finishState()
	}
}

func (t *TableFsm) initState() {
	//30s超时 || 是否准备完成
	if t.Table.RoundPastTime >= 30*int64(time.Second) || t.Table.IsReady() {
		//初始化信息
		t.Table.Roll()
		t.Table.Boardcast(uint32(kproto.MSG_BATTLE_BOARD_RESP_ID), t.Table.EnterRoomOutData())
		t.Table.State = ROLL_STATE
		t.Table.RoundPastTime = 0
	}
}

func (t *TableFsm) rollState() {
	if t.Table.RoundPastTime >= 5*int64(time.Second) {
		t.Table.State = PLAY_STATE
		t.Table.ChangeRound(1, false)

		//player action loop
		for _, v := range t.Table.Players {
			v.PlayerAction()
		}
	}
}

func (t *TableFsm) playState() {
	//双方掉线
	if !t.Table.IsAlive() {
		t.Table.State = FINISH_STATE
		return
	}

	//game over if maxround
	if int32(t.Table.CurRound) >= t.Table.MaxRound {
		t.Table.State = FINISH_STATE
		return
	}

	//游戏结束
	if t.Table.IsEnd() {
		//结算
		t.Table.RewardResult()
		t.Table.State = FINISH_STATE
		return
	}

	//change round when round timeout
	t.GetCurPlayer().SubActionTime(t.Table.Delay)
	if t.Table.RoundPastTime >= t.Table.RoundTime {
		//set receiver
		t.GetCurPlayer().SetActionReceiver(false)
		//check action time
		if t.GetCurPlayer().IsActionTimeOver() {
			t.Table.ChangeRound(0.5, true)
		}
		return
	}

	//change round if player action has finished
	if t.CanChangeRound() {
		t.Table.ChangeRound(0.5, true)
		return
	}
}

func (t *TableFsm) finishState() {
	t.GameOver()
	SrManagerInstant.DestoryRoom(t.Table.ID)
}

func (t *TableFsm) CanChangeRound() bool {
	if p := t.GetCurPlayer(); p != nil {
		return p.IsActionFinish()
	}
	return false
}

func (t *TableFsm) GetCurPlayer() *Player {
	return t.Table.Players[t.Table.CurPlayerID]
}

func (t *TableFsm) ReciveAction(userid string, ac *PlayerMessage) {
	t.Table.Players[userid].ReciveAction(ac)
}

func (t *TableFsm) GameOver() {
	logrus.Infof("room -> %v finish", t.Table.ID)

	t.Ticker.Stop()
	t.Cancel()
	t.Table.Clear()

	//如果是正常结束
	if t.Table.GameResult.State == 1 {
		switch t.Table.MatchType {
		case cmongo.MATCH_TYPE_1:
			//发送胜利方道具
			winner := t.Table.GetWinner()
			winner.SendMsg(uint32(kproto.MSG_BATTLE_END_GAME_RESP_ID), &kproto.BATTLE_END_GAME_RESP{Winner: t.Table.GameResult.Winner, ResultType: t.Table.GameResult.ResultType, MatchType: t.Table.MatchType, Rank1Result: winner.RankReward.OutData().(*kproto.Rank1Result)})
			//发送失败方道具
			loser := t.Table.GetLoser()
			loser.SendMsg(uint32(kproto.MSG_BATTLE_END_GAME_RESP_ID), &kproto.BATTLE_END_GAME_RESP{Winner: t.Table.GameResult.Winner, ResultType: t.Table.GameResult.ResultType, MatchType: t.Table.MatchType, Rank1Result: loser.RankReward.OutData().(*kproto.Rank1Result)})
		default:
			t.Table.Boardcast(uint32(kproto.MSG_BATTLE_END_GAME_RESP_ID), &kproto.BATTLE_END_GAME_RESP{Winner: t.Table.GameResult.Winner, ResultType: t.Table.GameResult.ResultType, MatchType: t.Table.MatchType})
		}

	}
}
