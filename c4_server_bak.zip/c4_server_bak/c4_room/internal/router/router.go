package router

import (
	"c4_center/container/credis"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/ktcp"
	"c4_room/internal/room"
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/sirupsen/logrus"
)

//可认输最小回合
const SURRENDER_ROUND = 3

func enterRoomCheck(userId, roomId string, session ktcp.Session) (int32, error) {
	//redis check
	sessStr, err := kredis.GetStr(context.Background(), userId)
	if err != nil {
		return -444, fmt.Errorf("do not have session of userid : %s;", userId)
	}

	var sessData credis.SessionInfo
	if json.Unmarshal([]byte(sessStr), &sessData) != nil {
		return -555, fmt.Errorf("session unmarshal err of userid : %s;", userId)
	}

	//房间ID不匹配
	if sessData.RoomID != roomId {
		return -666, fmt.Errorf("roomId error : redis -> %v , req -> %v;", sessData.RoomID, roomId)
	}

	//此帐号己在使用
	if s := room.Sessions.GetSession(userId); s != nil {
		s.SetFlag(1)
		s.Close()
		// return -777, fmt.Errorf("the userid is in room -> %v , userid -> %v;", sessData.RoomID, userId)
	}

	//room
	rm := room.SrManagerInstant.GetRoom(roomId)
	if rm == nil {
		//set room info to redis
		sessData.RoomID = ""
		sessData.RoomTcpAddress = ""

		//encode
		b, err := json.Marshal(sessData)
		if err != nil {
			return -886, fmt.Errorf("march json error ->%v  userid -> %v;", err, userId)
		}

		//session store
		err = kredis.SetStr(context.Background(), sessData.UserID, string(b), time.Hour*24)
		if err != nil {
			return -887, fmt.Errorf("set session error  -> %v , userid -> %v;", err, userId)
		}

		return -888, fmt.Errorf("the room has dismissed  -> %v , userid -> %v;", sessData.RoomID, userId)
	}

	//check player
	if rm.Table.GetPlayer(userId) == nil {
		return -999, fmt.Errorf("the player is nil ,  userid -> %v;", userId)
	}

	//设置玩家session
	rm.Table.GetPlayer(userId).SetSession(session)

	//set session
	session.SetID(userId)
	room.Sessions.SetSession(session)

	return 0, nil
}

func EnterRoom(ctx ktcp.Context) {
	var req kproto.BATTLE_ENTER_ROOM_REQ
	ctx.Bind(&req)

	//进房间检测
	if code, err := enterRoomCheck(req.UserId, req.RoomId, ctx.Session()); code != 0 {
		logrus.Info(err)
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_ENTER_ROOM_RESP_ID), &kproto.BATTLE_ENTER_ROOM_RESP{Code: code})
		return
	}

	//进入房间信息返回
	ctx.SetResponse(uint32(kproto.MSG_BATTLE_ENTER_ROOM_RESP_ID), &kproto.BATTLE_ENTER_ROOM_RESP{})

	// rm.Table.Board.Print()
}

func ReEnterRoom(ctx ktcp.Context) {
	var req kproto.BATTLE_REENTER_ROOM_REQ
	ctx.Bind(&req)

	//进房间检测
	if code, err := enterRoomCheck(req.UserId, req.RoomId, ctx.Session()); code != 0 {
		logrus.Info(err)
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_REENTER_ROOM_RESP_ID), &kproto.BATTLE_REENTER_ROOM_RESP{Code: code})
		return
	}

	//二次检测
	rm := room.SrManagerInstant.GetRoom(req.RoomId)
	if rm == nil {
		logrus.Info("the room is dismiss -> %v", req.RoomId)
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_REENTER_ROOM_RESP_ID), &kproto.BATTLE_REENTER_ROOM_RESP{Code: -888})
		return
	}

	//房间初始状态特殊处理
	if rm.Table.State == room.INIT_STATE {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_REENTER_ROOM_RESP_ID), &kproto.BATTLE_REENTER_ROOM_RESP{Code: 1})
	}

	//进入房间信息返回
	ctx.SetResponse(uint32(kproto.MSG_BATTLE_REENTER_ROOM_RESP_ID), rm.Table.ReEnterRoomOutData())

}

func Move(ctx ktcp.Context) {
	var req kproto.BATTLE_MOVE_REQ
	ctx.Bind(&req)

	rmId := room.PlayerManagerInstant.GetRoom(ctx.Session().ID().(string))
	rm := room.SrManagerInstant.GetRoom(rmId)
	if rm == nil {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_MOVE_RESP_ID), &kproto.BATTLE_MOVE_RESP{Code: -1})
		return
	}

	rm.ReciveAction(ctx.Session().ID().(string), room.NewPlayerMessage(uint32(kproto.MSG_BATTLE_MOVE_REQ_ID), req))
	ctx.SetResponse(uint32(kproto.MSG_BATTLE_MOVE_RESP_ID), &kproto.BATTLE_MOVE_RESP{})
}

func UseSkill(ctx ktcp.Context) {
	var req kproto.BATTLE_USE_SKILL_REQ
	ctx.Bind(&req)

	rmId := room.PlayerManagerInstant.GetRoom(ctx.Session().ID().(string))
	rm := room.SrManagerInstant.GetRoom(rmId)
	if rm == nil {
		return
	}

	rm.ReciveAction(ctx.Session().ID().(string), room.NewPlayerMessage(uint32(kproto.MSG_BATTLE_USE_SKILL_REQ_ID), req))
}

//认输
func Surrender(ctx ktcp.Context) {
	rmId := room.PlayerManagerInstant.GetRoom(ctx.Session().ID().(string))
	rm := room.SrManagerInstant.GetRoom(rmId)
	if rm == nil {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_SURRENDER_RESP_ID), &kproto.BATTLE_SURRENDER_RESP{Code: -1})
		return
	}

	player := rm.Table.GetPlayer(ctx.Session().ID().(string))
	if player == nil {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_SURRENDER_RESP_ID), &kproto.BATTLE_SURRENDER_RESP{Code: -2})
		return
	}

	//认输回合
	if rm.Table.CurRound < SURRENDER_ROUND {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_SURRENDER_RESP_ID), &kproto.BATTLE_SURRENDER_RESP{Code: -3})
		return
	}

	// surrender
	player.SetSurrender()

	//认输成功
	ctx.SetResponse(uint32(kproto.MSG_BATTLE_SURRENDER_RESP_ID), &kproto.BATTLE_SURRENDER_RESP{})
}

func SetAuto(ctx ktcp.Context) {
	var req kproto.BATTLE_AUTO_REQ
	ctx.Bind(&req)

	rmId := room.PlayerManagerInstant.GetRoom(ctx.Session().ID().(string))
	rm := room.SrManagerInstant.GetRoom(rmId)
	if rm == nil {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_AUTO_RESP_ID), &kproto.BATTLE_AUTO_RESP{Code: -1})
		return
	}
	player := rm.Table.GetPlayer(ctx.Session().ID().(string))
	if player == nil {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_AUTO_RESP_ID), &kproto.BATTLE_AUTO_RESP{Code: -2})
		return
	}

	//set flag
	player.Auto = !player.Auto

	ctx.SetResponse(uint32(kproto.MSG_BATTLE_AUTO_RESP_ID), &kproto.BATTLE_AUTO_RESP{Auto: player.Auto})
}

//心跳
func HeartBeat(ctx ktcp.Context) {
	if room.Sessions.GetSession(ctx.Session().ID().(string)) == nil {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_HEARTBEAT_RESP_ID), &kproto.BATTLE_HEARTBEAT_RESP{Time: -1})
		return
	}

	rmId := room.PlayerManagerInstant.GetRoom(ctx.Session().ID().(string))
	rm := room.SrManagerInstant.GetRoom(rmId)
	if rm == nil {
		ctx.SetResponse(uint32(kproto.MSG_BATTLE_HEARTBEAT_RESP_ID), &kproto.BATTLE_HEARTBEAT_RESP{Time: -1})
		return
	}

	ctx.SetResponse(uint32(kproto.MSG_BATTLE_HEARTBEAT_RESP_ID), &kproto.BATTLE_HEARTBEAT_RESP{Time: (rm.Table.RoundTime - rm.Table.RoundPastTime) / int64(time.Millisecond), RoundTime: rm.Table.RoundTime / int64(time.Millisecond)})
}
