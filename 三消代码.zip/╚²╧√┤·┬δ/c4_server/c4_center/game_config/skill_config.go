package game_config

type SkillData struct {
	Id             int32     `tb_name:"流水号"`
	SkillId        int32     `tb_name:"技能ID"`
	Level          int32     `tb_name:"技能等级"`
	HeroLvl        int32     `tb_name:"英雄等级"`
	NameId         int32     `tb_name:"技能名称文本ID"`
	DescId         int32     `tb_name:"技能描述文本ID"`
	SkillIcon      string    `tb_name:"技能图标"`
	IsInitiative   int32     `tb_name:"主被动技能标签"`
	SkillType      SkillType `tb_name:"技能类型"`
	StartCD        int32     `tb_name:"开局冷却(回合)"`
	IntervalCD     int32     `tb_name:"技能冷却(回合)"`
	Condition      string    `tb_name:"自动触发条件"`
	ConditionParam string    `tb_name:"自动触发条件参数"`
	blackMaskTime  int32     `tb_name:"必杀技黑屏时间(ms)"`
	EffectId       []int32   `tb_name:"效果序列ID"`
	EffectTimeline []int32   `tb_name:"效果时间轴(ms)"`
	SkillTotalTime int32     `tb_name:"技能总时间"`
}

var SkillConfigInstant *SkillConfig

type SkillConfig struct {
	SkillData []*SkillData
	Infos     map[int32]*SkillData
}

func InitSkillConfig(path string) {
	SkillConfigInstant = &SkillConfig{Infos: make(map[int32]*SkillData)}
	//加载
	LoadJsonFile(path+"/SkillData.json", SkillConfigInstant)
	//初始化
	SkillConfigInstant.InitIndex()
}

func (s *SkillConfig) InitIndex() {
	for i, v := range s.SkillData {
		s.Infos[v.SkillId] = s.SkillData[i]
	}
}

func (s *SkillConfig) GetInfo(id int32) *SkillData {
	return s.Infos[id]
}
