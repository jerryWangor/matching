package game_config

type ServerConfigData struct {
	Id    string `tb_name:"编号"`
	Value string `tb_name:"值"`
}

var ServerConfigInstant *ServerConfig

type ServerConfig struct {
	ServerConfigData []*ServerConfigData
	Infos            map[string]*ServerConfigData
}

func InitServerConfig(path string) {
	ServerConfigInstant = &ServerConfig{Infos: make(map[string]*ServerConfigData)}
	//加载
	LoadJsonFile(path+"/ServerConfigData.json", ServerConfigInstant)
	//初始化
	ServerConfigInstant.InitIndex()
}

//初始化索引
func (hc *ServerConfig) InitIndex() {
	for i, v := range hc.ServerConfigData {
		hc.Infos[v.Id] = hc.ServerConfigData[i]
	}
}

func (hc *ServerConfig) GetInfo(key string) *ServerConfigData {
	return hc.Infos[key]
}
