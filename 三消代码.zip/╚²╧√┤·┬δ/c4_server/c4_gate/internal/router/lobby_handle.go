package router

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_gate/gate_registry"
	"c4_gate/internal"
	"context"
	"time"

	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

//get ranking
func LobbyGetRanking(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RANKING_RESP_ID), &kproto.LOBBY_RANKING_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RANKING_RESP_ID), &kproto.LOBBY_RANKING_RESP{Code: -2})
	}
}

//func LobbyGetRankingHeroLevel(kctx ktcp.Context) {
//	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
//		logrus.Error("not login.")
//		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RANKING_HERO_LEVEL_RESP_ID), &kproto.LOBBY_RANKING_HERO_LEVEL_RESP{Code: -1})
//		return
//	}
//
//	err := LobbyRpc(kctx)
//	if err != nil {
//		logrus.Error(err)
//		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RANKING_HERO_LEVEL_RESP_ID), &kproto.LOBBY_RANKING_HERO_LEVEL_RESP{Code: -2})
//	}
//}

//enter lobby
func EnterLobby(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_GATE_ENTER_LOBBY_RESP_ID), &kproto.GATE_ENTER_LOBBY_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_GATE_ENTER_LOBBY_RESP_ID), &kproto.GATE_ENTER_LOBBY_RESP{Code: -2})
	}
}

//get activity
func LobbyGetActivity(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ACTIVITY_RESP_ID), &kproto.LOBBY_ACTIVITY_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ACTIVITY_RESP_ID), &kproto.LOBBY_ACTIVITY_RESP{Code: -2})
	}
}

//get activity assign
func LobbyGetActivityAssign(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ACTIVITY_RESP_ID), &kproto.LOBBY_ACTIVITY_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ACTIVITY_RESP_ID), &kproto.LOBBY_ACTIVITY_RESP{Code: -2})
	}
}

//gm order
func LobbyGmOrder(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_GM_RESP_ID), &kproto.LOBBY_GM_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_GM_RESP_ID), &kproto.LOBBY_GM_RESP{Code: -99})
	}
}

//send to lobby
func LobbyGetHeroes(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_HERO_RESP_ID), &kproto.LOBBY_HERO_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_HERO_RESP_ID), &kproto.LOBBY_HERO_RESP{Code: -2})
	}
}

//send to lobby
func LobbySetHeroPos(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_HERO_POS_RESP_ID), &kproto.LOBBY_HERO_POS_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_HERO_POS_RESP_ID), &kproto.LOBBY_HERO_POS_RESP{Code: -2})
	}
}

func LobbyRpc(kctx ktcp.Context) error {
	//get grpc service
	service, err := gate_registry.EtcdClient.GetServiceInDiscovery(gate_registry.LOBBY_SERVICE)
	if err != nil {
		return err
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return err
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: kctx.Session().ID().(string), Packet: &kproto.Packet{MsgId: kctx.Request().ID().(uint32), Data: kctx.Request().Data()}})
	if err != nil {
		return err
	}

	//respone
	kctx.SetResponseMessage(ktcp.NewMessage(resp.Packet.MsgId, resp.Packet.Data))
	return nil
}
