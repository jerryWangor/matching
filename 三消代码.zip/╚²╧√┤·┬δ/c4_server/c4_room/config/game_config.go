package config

import "c4_center/game_config"

func InitGameConfig() {
	//init
	game_config.InitHeroAttrConfig(GameConfigInstant.Path)
	game_config.InitChessColorGroupConfig(GameConfigInstant.Path)
	game_config.InitHeroConfig(GameConfigInstant.Path)
	game_config.InitSkillConfig(GameConfigInstant.Path)
	game_config.InitSkillEffectConfig(GameConfigInstant.Path)
	game_config.InitSkillGroup(GameConfigInstant.Path)
	game_config.InitFormulaParametersConfig(GameConfigInstant.Path)
	game_config.InitPvPSegmentConfig(GameConfigInstant.Path)
	game_config.InitPVPChestOrderConfig(GameConfigInstant.Path)
	game_config.InitPVPChestQualityConfig(GameConfigInstant.Path)
	game_config.InitItemConfig(GameConfigInstant.Path)
	game_config.InitChristmasDropConfig(GameConfigInstant.Path)
}
