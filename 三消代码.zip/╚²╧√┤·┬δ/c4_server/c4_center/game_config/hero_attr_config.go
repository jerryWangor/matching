package game_config

import "fmt"

type HeroAttrData struct {
	Id     int32 `tb_name:"属性ID"`
	Grade  int32 `tb_name:"星级"`
	Level  int32 `tb_name:"等级"`
	Hp     int32 `tb_name:"生命"`
	Shield int32 `tb_name:"护盾"`
	Attack int32 `tb_name:"攻击力"`
}

var HeroAttrConfigInstant *HeroAttrConfig

type HeroAttrConfig struct {
	HeroAttrData []*HeroAttrData
	Infos        map[string]*HeroAttrData
}

func InitHeroAttrConfig(path string) {
	HeroAttrConfigInstant = &HeroAttrConfig{Infos: make(map[string]*HeroAttrData)}
	//加载
	LoadJsonFile(path+"/HeroAttrData.json", HeroAttrConfigInstant)
	//初始化
	HeroAttrConfigInstant.InitIndex()
}

//初始化索引
func (hc *HeroAttrConfig) InitIndex() {
	for i, v := range hc.HeroAttrData {
		hc.Infos[hc.getKey(v.Grade, v.Level)] = hc.HeroAttrData[i]
	}
}

func (hc *HeroAttrConfig) GetInfo(grade, level int32) *HeroAttrData {
	return hc.Infos[hc.getKey(grade, level)]
}

func (hc *HeroAttrConfig) getKey(grade, level int32) string {
	return fmt.Sprintf("%v-%v", grade, level)
}
