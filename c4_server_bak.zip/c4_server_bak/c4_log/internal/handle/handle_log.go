package handle

import (
	"c4_center/game_config"
	"c4_center/klog"
	"c4_center/kmysql"
	"c4_center/utils"
	"fmt"
	"github.com/sirupsen/logrus"
	"reflect"
	"strings"
	"time"
)

var LogInsertDataChan chan *klog.LogData

func Init() {
	LogInsertDataChan = make(chan *klog.LogData, 10000)
}

// 定时器
func TickerLoop() {
	// 检查不分月表是否创建
	CheckNotSplitTableOrCreate()
	CheckSplitTableOrCreate()
	ticker := time.NewTicker(time.Hour * 24)
	go func() {
		for {
			<-ticker.C
			// 24小时间隔检查分月表是否创建
			CheckSplitTableOrCreate()
		}
	}()
}

// 执行不分表检查，创建
func CheckNotSplitTableOrCreate() {
	for _, t := range game_config.LogTableConfigInstant.NotSplitInfos {
		if t.Split == 0 {
			if !kmysql.TableIsExists(t.TableName) {
				logrus.Infof("%s 表不存在，创建！", t.TableName)
				kmysql.CreateTable(t.Sql)
			}
		}
	}
}

// 执行分表检查，创建
func CheckSplitTableOrCreate() {
	// 分月
	for _, t := range game_config.LogTableConfigInstant.SplitMonthInfos {
		// 获取当前时间和后三个月的时间
		stime := time.Now()
		etime := stime
		etime = etime.AddDate(0, 3, 0)
		minfo, _ := utils.GetBetweenMonths(stime, etime)
		for _, v := range minfo {
			tname := t.TableName + "_" + v.MonStr
			if !kmysql.TableIsExists(tname) {
				logrus.Infof("%s 表不存在，创建！", tname)
				sql := strings.Replace(t.Sql, "$month", v.MonStr, 1)
				kmysql.CreateTable(sql)
			}
		}
	}

	// 分天
	for _, t := range game_config.LogTableConfigInstant.SplitDayInfos {
		// 获取当前时间和后三天的时间
		stime := time.Now()
		etime := stime
		etime = etime.AddDate(0, 0, 3)
		dinfo := utils.GetBetweenDates(stime.Format("2006-01-02"), etime.Format("2006-01-02"))
		for _, v := range dinfo {
			tname := t.TableName + "_" + v
			if !kmysql.TableIsExists(tname) {
				logrus.Infof("%s 表不存在，创建！", tname)
				sql := strings.Replace(t.Sql, "$day", v, 1)
				kmysql.CreateTable(sql)
			}
		}
	}

}

func LogLoop() {

	defer func() {
		if rr := recover(); rr != nil {
			logrus.Error(rr)
		}
	}()

	for {
		// 监听日志通道
		d, ok := <-LogInsertDataChan
		if !ok {
			logrus.Info("日志服务通道关闭")
			return
		}

		fmt.Println("读取到了日志", d)
		// 解析结构体model，写入日志
		switch d.Type {
		case klog.LogTypeInsert:

			err := InsertTableData(d.ModelName, d.Data)
			if err != nil {
				logrus.Error("data save err")
			}

			//case "LogPoints":
			//	point := cmysql.LogPoints{}
			//	if err := mapstructure.Decode(d.Data, &point); err != nil {
			//		logrus.Warn("data err")
			//	} else {
			//		// 插入数据
			//		tname := GetRealTableName(d.ModelName)
			//		kmysql.InsertUpdate(tname, &point)
			//	}
			//case "LogPlayer":
			//	player := cmysql.LogPlayer{}
			//	if err := mapstructure.Decode(d.Data, &player); err != nil {
			//		logrus.Warn("data err")
			//	} else {
			//		// 插入数据
			//		tname := GetRealTableName(d.ModelName)
			//		kmysql.InsertUpdate(tname, &player)
			//	}
			//}
		}
	}
}

// 获取实际的表名（这里还有一种考虑，通过数据中的date_time来判断是哪个分表）
func GetRealTableName(mname string) string {

	v, ok := game_config.LogTableConfigInstant.Infos[mname]
	if !ok {
		logrus.Warnf("not table data: %s", mname)
		return ""
	}

	// 如果有分月表就用分月表
	switch v.Split {
	case 0: // 不分表
		return v.TableName
	case 1: // 分月
		month := time.Now().Format("200601")
		return v.TableName + "_" + month
	case 2: // 分天
	}

	logrus.Warnf("未找到日志表配置：%s", mname)
	return ""
}

// 从json配置中解析数据并保存
func InsertTableData(tname string, data map[string]interface{}) error {
	var sfarr []reflect.StructField

	tablename := GetRealTableName(tname)

	// 获取字段信息
	val, ok := game_config.LogTableConfigInstant.Infos[tname]
	if !ok {
		logrus.Warnf("not table data: %s", tname)
		return nil
	}
	fmt.Println(data, val.Field)
	for ke, va := range val.Field {
		if v, ok := data[ke]; ok {
			s := reflect.StructTag(`gorm:"` + va.Key + `"`)
			fmt.Println(ke, s)
			sf := reflect.StructField{
				Name: va.Name,
				Type: reflect.TypeOf(v),
				Tag:  s,
			}
			sfarr = append(sfarr, sf)
		}
	}

	//生成对象
	typ := reflect.StructOf(sfarr)
	vv := reflect.New(typ).Elem()
	//设置对象数据
	for ke, va := range val.Field {
		if v, ok := data[ke]; ok {
			vv.FieldByName(va.Name).Set(reflect.ValueOf(v))
		}
	}

	return kmysql.InsertUpdate(tablename, vv.Addr().Interface())
}

func Close() {
	close(LogInsertDataChan)
}
