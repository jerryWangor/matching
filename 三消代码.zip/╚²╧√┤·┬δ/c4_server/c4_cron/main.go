package main

import (
	"c4_center/game_config"
	"c4_center/khttp"
	"c4_center/klog"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/ktcp"
	"c4_center/registry/etcd"
	"c4_cron/config"
	"c4_cron/cron_registry"
	"c4_cron/internal"
	"c4_cron/internal/cron"
	"c4_cron/internal/http"
	"net"
	"os"
	"os/signal"
	"syscall"
	"time"

	redisv8 "github.com/go-redis/redis/v8"
	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/grpc"
)

func main() {
	//初始化配置
	config.Init("app.ini")
	//初始化logs
	klog.InitLog(config.LogsConfigInstant.Path, config.LogsConfigInstant.Level)
	//初始化游戏配置
	config.InitGameConfig()
	//watch
	go game_config.WatchGameConfig(config.GameConfigInstant.Path, config.InitGameConfig)

	//初始化mongo
	kmongo.Init(config.MongoConfigInstant.Mongo_DB, options.Client().ApplyURI(config.MongoConfigInstant.Mongo_addr))

	//初始化redis
	kredis.Init(&redisv8.Options{
		Addr:     config.RedisConfigInstant.Redis_addr,
		Password: config.RedisConfigInstant.Redis_pswd,
		DB:       config.RedisConfigInstant.Redis_DB,
		PoolSize: config.RedisConfigInstant.Redis_poolSize,
	})

	//初始化etcd
	cron_registry.InitCronRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))

	//注册etcd服务
	if err := cron_registry.EtcdClient.Register(config.GrpcServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cron_registry.EtcdClient.Register(config.HttpServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	//监听所需etcd服务
	cron_registry.EtcdClient.Watch(cron_registry.GATE_SERVICE)

	//启动rpc服务
	lis, err := net.Listen("tcp", config.GrpcConfigInstant.Grpc_addr)
	if err != nil {
		logrus.Fatalf("failed to listen: %v", err)
	}

	var opts []grpc.ServerOption
	grpcServer := grpc.NewServer(opts...)
	kproto.RegisterCronServiceServer(grpcServer, &internal.CronService{})
	// grpcServer.Serve(lis)
	go func() { grpcServer.Serve(lis) }()

	//启动http服务
	server := khttp.NewServer(&khttp.HttpServerOption{
		Router: khttp.NewRouter(&ktcp.ProtobufCodec{}),
	})
	server.NotFoundHandler(http.NotFound)
	server.Use(khttp.RecoverMiddleware())
	server.AddRoute("/gettime", http.GetTime)

	go server.Serve(config.HttpConfigInstant.Http_addr)

	// 开启定时器
	go cron.OpenCron()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh

	cron.Close()
	grpcServer.Stop()
	logrus.Infof("server stopped.")
}
