package game_config

type ActivityData struct {
	ActivityID   int32  `tb_name:"活动ID"`
	ActivityName string `tb_name:"活动名称"`
	StartTime    string `tb_name:"开始时间"`
	EndTime      string `tb_name:"结束时间"`
	FreshTime    string `tb_name:"刷新时间"`
	ActivityIcon string `tb_name:"活动图标"`
}

var ActivityConfigInstant *ActivityConfig

type ActivityConfig struct {
	ActivityData []*ActivityData
	Infos        map[int32]*ActivityData //key == Id
}

func InitActivityConfig(path string) {
	ActivityConfigInstant = &ActivityConfig{Infos: make(map[int32]*ActivityData)}
	//加载
	LoadJsonFile(path+"/ActivityData.json", ActivityConfigInstant)
	//初始化
	ActivityConfigInstant.InitIndex()
}

func (h *ActivityConfig) InitIndex() {
	for i, _ := range h.ActivityData {
		h.Infos[h.ActivityData[i].ActivityID] = h.ActivityData[i]
	}
}

func (h *ActivityConfig) GetInfo(id int32) *ActivityData {
	data, ok := h.Infos[id]
	if !ok {
		return nil
	}
	return data
}
