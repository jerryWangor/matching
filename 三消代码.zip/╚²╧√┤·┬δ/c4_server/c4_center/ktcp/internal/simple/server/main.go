package main

import (
	"c4_center/ktcp"
	"c4_center/ktcp/internal/fixture"
	"c4_center/ktcp/internal/simple/common"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/sirupsen/logrus"
)

var log *logrus.Logger

func init() {
	log = logrus.New()
	log.SetLevel(logrus.TraceLevel)
}

func main() {
	ktcp.SetLogger(log)
	s := ktcp.NewServer(&ktcp.ServerOption{
		SocketReadBufferSize:  1024 * 1024,
		SocketWriteBufferSize: 1024 * 1024,
		ReadTimeout:           time.Second * 3,
		WriteTimeout:          time.Second * 3,
		RespQueueSize:         0,
		Packer:                ktcp.NewDefaultPacker(),
		Codec:                 nil,
	})
	s.OnSessionCreate = func(sess ktcp.Session) {
		log.Infof("session created: %v", sess.ID())
	}
	s.OnSessionClose = func(sess ktcp.Session) {
		log.Warnf("session closed: %v", sess.ID())
	}

	// register global middlewares
	s.Use(fixture.RecoverMiddleware(log), logMiddleware)

	// register a route
	s.AddRoute(common.MsgIdPingReq, func(c ktcp.Context) {
		c.SetResponseMessage(ktcp.NewMessage(common.MsgIdPingAck, []byte("pong")))
	})

	go func() {
		if err := s.Serve(fixture.ServerAddr); err != nil {
			log.Errorf("serve err: %s", err)
		}
	}()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh
	if err := s.Stop(); err != nil {
		log.Errorf("server stopped err: %s", err)
	}
	time.Sleep(time.Second * 3)
}

func logMiddleware(next ktcp.HandlerFunc) ktcp.HandlerFunc {
	return func(c ktcp.Context) {
		req := c.Request()
		log.Infof("rec <<< id:(%d) size:(%d) data: %s", req.ID(), len(req.Data()), req.Data())
		defer func() {
			resp := c.Response()
			log.Infof("snd >>> id:(%d) size:(%d) data: %s", resp.ID(), len(resp.Data()), resp.Data())
		}()
		next(c)
	}
}
