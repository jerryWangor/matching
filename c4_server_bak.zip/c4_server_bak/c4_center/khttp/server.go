package khttp

import (
	"net/http"
)

type HttpServer struct {
	router *Router
}

type HttpServerOption struct {
	Router *Router
}

func NewServer(opt *HttpServerOption) *HttpServer {
	return &HttpServer{
		router: opt.Router,
	}
}

func (h *HttpServer) Serve(addr string) error {
	h.router.printHandlers(addr)
	return http.ListenAndServe(addr, h.router)
}

// AddRoute registers message handler and middlewares to the router.
func (h *HttpServer) AddRoute(msgID interface{}, handler HandlerFunc, middlewares ...MiddlewareFunc) {
	h.router.register(msgID, handler, middlewares...)
}

// Use registers global middlewares to the router.
func (h *HttpServer) Use(middlewares ...MiddlewareFunc) {
	h.router.registerMiddleware(middlewares...)
}

// NotFoundHandler sets the not-found handler for router.
func (h *HttpServer) NotFoundHandler(handler HandlerFunc) {
	h.router.setNotFoundHandler(handler)
}
