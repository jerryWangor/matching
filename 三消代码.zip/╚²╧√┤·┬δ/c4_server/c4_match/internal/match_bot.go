package internal

import (
	"c4_center/game_config"
	"c4_match/internal/store"
	"time"
)

type MatchBot interface {
	Match(user *store.User) bool
}

//练习赛
type PractiseBot struct {
}

func (p *PractiseBot) Match(user *store.User) bool {
	return false
}

//排位赛类型1
type Rank1Bot struct {
}

//是否匹配机器人
func (r *Rank1Bot) Match(user *store.User) bool {
	config := game_config.RobotMatchRuleConfigInstant.GetMinInfo(int32(user.Score))
	if config == nil {
		return false
	}

	//开关 0:关　1:开
	if config.Switch == 0 {
		return false
	}

	//时间 || 连输场次
	now := time.Now()
	extendTime := user.JoinTime.Add(time.Second * time.Duration(config.MatchTimes))

	return now.Unix() > extendTime.Unix() || user.ConLose >= config.LoseTimes
}
