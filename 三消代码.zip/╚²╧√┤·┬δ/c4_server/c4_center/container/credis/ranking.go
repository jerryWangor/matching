package credis

type Ranking struct {
	Score  float64
	Member interface{}
}
