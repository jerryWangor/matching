package internal

import (
	"c4_center/encry"
	"c4_lobby/config"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"
)

var (
	USER_BALLS_API       = "/api/wallet/getusercrystalballs?address=%v&startindex=%v&pagecount=%v"
	BALL_STATE_API       = "/api/wallet/getcrystalballstate?ballidlist=%v"
	START_INDEX    int32 = 0
	PAGE_COUNT     int32 = 10
	IN_GAME              = "Boa"
)

type APIGetUserBallsResp struct {
	State int32     `json:"state"`
	Data  *APIBalls `json:"data"`
}

type APIBalls struct {
	Balls    []*APIBall `json:"Balls"`
	Total    int64      `json:"Total"`
	EndIndex int64      `json:"EndIndex"`
}

type APIBall struct {
	Ballid                  int32  `json:"Ballid"`
	Owner                   string `json:"Owner"`
	Gene                    string `json:"Gene"`
	Mutatedgene             string `json:"Mutatedgene"`
	Birthday                int64  `json:"Birthday"`
	Dynasty                 int64  `json:"Dynasty"`
	SalePrice               int64  `json:"SalePrice"`
	ReproductionPrice       int64  `json:"ReproductionPrice"`
	IsSale                  bool   `json:"IsSale"`
	IsReproduction          bool   `json:"IsReproduction"`
	ReproductionInterval    int64  `json:"ReproductionInterval"`
	Fatherid                int32  `json:"Fatherid"`
	Montherid               int32  `json:"Montherid"`
	FatherReproductionTimes int64  `json:"FatherReproductionTimes"`
	MotherReproductionTimes int64  `json:"MotherReproductionTimes"`
	Token                   int64  `json:"Token"`
}

type APIGetBallStateResp struct {
	State int32           `json:"state"`
	Data  []*APIBallState `json:"data"`
}

type APIBallState struct {
	Name   string `json:"Name"`
	Value  int32  `json:"Value"`
	BallId int32  `json:"BallId"`
	Key    string `json:"Key"`
}

func WalletHttpRequest(url string) ([]byte, error) {
	cli := http.Client{Timeout: time.Second * 3}
	resp, err := cli.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	return body, nil
}

func APIGetUserBalls(address string) ([]*APIBall, error) {
	var ret []*APIBall

	var request func(startIndex, pageCount int32) error

	request = func(startIndex, pageCount int32) error {
		balls, err := WalletHttpRequest(fmt.Sprintf(config.WalletconfigInstant.Domain+USER_BALLS_API, address, startIndex, pageCount))
		if err != nil {
			return err
		}

		var info APIGetUserBallsResp
		err = json.Unmarshal(balls, &info)
		if err != nil {
			return err
		}

		if info.State != 0 {
			return fmt.Errorf("state error -> %v", info.State)
		}

		ret = append(ret, info.Data.Balls...)

		if int(info.Data.Total) > len(ret) {
			if err := request(startIndex+pageCount, pageCount); err != nil {
				return err
			}
		}
		return nil
	}

	return ret, request(START_INDEX, PAGE_COUNT)
}

func APIGetBallState(ids []int32) (*APIGetBallStateResp, error) {
	b, err := json.Marshal(ids)
	if err != nil {
		return nil, err
	}

	resp, err := WalletHttpRequest(fmt.Sprintf(config.WalletconfigInstant.Domain+BALL_STATE_API, string(encry.Base64Encode(b))))
	if err != nil {
		return nil, err
	}

	var ret APIGetBallStateResp
	err = json.Unmarshal(resp, &ret)
	if err != nil {
		return nil, err
	}

	if ret.State != 0 {
		return nil, fmt.Errorf("get ball error -> %v", ret.State)
	}

	return &ret, nil
}

func GetBalls(address string) ([]*APIBall, error) {
	//获取用户所有水晶人列表
	balls, err := APIGetUserBalls(address)
	if err != nil {
		return nil, err
	}

	var ids []int32
	for _, v := range balls {
		ids = append(ids, v.Ballid)
	}

	//查询所有水晶人状态
	resp, err := APIGetBallState(ids)
	if err != nil {
		return nil, err
	}

	var ret []*APIBall

	for _, v := range resp.Data {
		if v.Name != IN_GAME || v.Value != 1 {
			continue
		}

		for kk, vv := range balls {
			if vv.Ballid == v.BallId {
				ret = append(ret, balls[kk])
				break
			}
		}
	}

	return ret, nil
}
