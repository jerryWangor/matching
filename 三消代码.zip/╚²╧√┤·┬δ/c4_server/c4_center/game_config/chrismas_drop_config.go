package game_config

type ChristmasDropData struct {
	ID           int32  `tb_name:"掉落ID"`
	DropRange    string `tb_name:"掉落数量区间"`
	MaxDailyDrop int32  `tb_name:"每日掉落上限"`
	TotalDrop    int32  `tb_name:"掉落总上限"`
}

var ChristmasDropConfigInstant *ChristmasDropConfig

type ChristmasDropConfig struct {
	ChristmasDropData []*ChristmasDropData
	Infos             map[int32]*ChristmasDropData //key == HeaddresId
}

func InitChristmasDropConfig(path string) {
	ChristmasDropConfigInstant = &ChristmasDropConfig{Infos: make(map[int32]*ChristmasDropData)}
	//加载
	LoadJsonFile(path+"/ChristmasDropData.json", ChristmasDropConfigInstant)
	//初始化
	ChristmasDropConfigInstant.InitIndex()
}

func (h *ChristmasDropConfig) InitIndex() {
	for i, v := range h.ChristmasDropData {
		h.Infos[v.ID] = h.ChristmasDropData[i]
	}
}

func (h *ChristmasDropConfig) GetInfo(id int32) *ChristmasDropData {
	return h.Infos[id]
}
