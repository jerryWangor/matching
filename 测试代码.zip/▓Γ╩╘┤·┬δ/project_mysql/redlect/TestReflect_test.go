package redlect

import (
	"fmt"
	"reflect"
	"testing"
	"time"
)

func TestReflect(t *testing.T) {
	fmt.Println(time.Now().Unix())
	// use of StructOf method
	typ := reflect.StructOf([]reflect.StructField{
		{
			Name: "Height",
			Type: reflect.TypeOf(float64(0)),
			Tag:  `json:"tag"`,
		},
		{
			Name: "Name",
			Type: reflect.TypeOf("abc"),
			Tag:  `json:"name"`,
		},
	})

	fmt.Println(typ)
}
