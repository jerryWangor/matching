package gate_registry

import (
	"c4_center/kproto"
	"context"
	"testing"
	"time"

	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

func TestGrpcInvoke(t *testing.T) {
	GrpcInvoke1("127.0.0.1:8000")
}

func GrpcInvoke1(addr string) {
	conn, err := grpc.DialContext(context.Background(), addr, grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
		return
	}

	defer conn.Close()

	client := kproto.NewGateServiceClient(conn)

	//设定请求超时时间
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	resp, err := client.SendToClient(ctx, &kproto.SendReq{UserId: "aaa", Packet: &kproto.Packet{MsgId: 111}})
	if err != nil {
		logrus.Error(err)
		return
	}

	logrus.Info(resp)

}
