package game_config

type RobotMatchRuleData struct {
	Exp        int32 `tb_name:"段位积分"`
	MatchTimes int32 `tb_name:"匹配时间"`
	LoseTimes  int32 `tb_name:"连输场次"`
	Switch     int32 `tb_name:"开关"`
}

var RobotMatchRuleConfigInstant *RobotMatchRuleConfig

type RobotMatchRuleConfig struct {
	RobotMatchRuleData []*RobotMatchRuleData
	Infos              map[int32]*RobotMatchRuleData
}

func InitRobotMatchRuleConfig(path string) {
	RobotMatchRuleConfigInstant = &RobotMatchRuleConfig{Infos: make(map[int32]*RobotMatchRuleData)}
	//加载
	LoadJsonFile(path+"/RobotMatchRuleData.json", RobotMatchRuleConfigInstant)
	//初始化
	RobotMatchRuleConfigInstant.InitIndex()
}

func (s *RobotMatchRuleConfig) InitIndex() {
	for i, v := range s.RobotMatchRuleData {
		s.Infos[v.Exp] = s.RobotMatchRuleData[i]
	}
}

func (s *RobotMatchRuleConfig) GetMinInfo(exp int32) *RobotMatchRuleData {
	count := 0

	for count < len(s.RobotMatchRuleData)-1 {
		if s.RobotMatchRuleData[count].Exp >= exp {
			break
		}

		count++
	}

	return s.RobotMatchRuleData[count]
}
