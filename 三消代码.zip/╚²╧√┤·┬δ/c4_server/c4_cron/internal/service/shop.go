package service

import (
	"c4_center/kmongo"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
)

// 更新某个商店ID的所有购买次数
func DeleteBuyLimitByShopId(shopId int32) error {
	if !kmongo.DeleteMany(context.TODO(), kmongo.ShopBuyLimitCollection, bson.M{"shop_id": shopId}) {
		return fmt.Errorf("update ShopBuyLimit error. -> shop_id: %v, limit_num: %v", shopId)
	}
	return nil
}
