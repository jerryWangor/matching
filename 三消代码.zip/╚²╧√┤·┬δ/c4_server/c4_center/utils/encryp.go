package utils

import (
	"crypto/md5"
	"fmt"
)

// ------------------------------------- 加密 -----------------------------------------

// GetMd5String md5加密
func GetMd5String(str string) string {
	data := []byte(str)
	has := md5.Sum(data)
	md5str := fmt.Sprintf("%x", has)
	return md5str
}
