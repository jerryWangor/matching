package service

import (
	"c4_center/container/cmongo"
	"c4_center/kmongo"
	"c4_center/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

// 获取订单
func GetPayOrder(orderId string) *cmongo.PayOrder {
	var ret cmongo.PayOrder
	kmongo.GetOne(context.TODO(), kmongo.PayOrderCollection, &ret, bson.M{"order_id": orderId})
	if len(ret.ID) <= 0 {
		return nil
	}
	return &ret
}

// 获取订单
func GetPayOrderByHashData(hashData string) *cmongo.PayOrder {
	var ret cmongo.PayOrder
	kmongo.GetOne(context.TODO(), kmongo.PayOrderCollection, &ret, bson.M{"hash_data": hashData})
	if len(ret.ID) <= 0 {
		return nil
	}
	return &ret
}

// 获取有hash但没有成功的订单
func GetPayOrderByAwait(userId string) []*cmongo.PayOrder {
	var ret []*cmongo.PayOrder
	kmongo.Get(context.TODO(), kmongo.PayOrderCollection, &ret, bson.M{"user_id": userId, "hash_data": bson.M{"$ne": ""}, "result": 0, "is_supple": 0})
	return ret
}

func InsertPayOrder(i *cmongo.PayOrder) error {
	if !kmongo.InsertOne(context.TODO(), kmongo.PayOrderCollection, i) {
		return fmt.Errorf("insert pay_order error. -> %v", i)
	}
	return nil
}

// 更新hash
func UpdatePayOrderHash(i *cmongo.PayOrder) error {
	if !kmongo.UpdateOne(context.TODO(), kmongo.PayOrderCollection,
		bson.M{"order_id": i.OrderId},
		bson.M{"$set": bson.M{"hash_data": i.HashData}}) {
		return fmt.Errorf("update pay_order error. -> user_id: %v, order_id: %v", i.UserID, i.OrderId)
	}
	return nil
}

// 更新hash result
func UpdatePayOrder(i *cmongo.PayOrder) error {
	if !kmongo.UpdateOne(context.TODO(), kmongo.PayOrderCollection,
		bson.M{"order_id": i.OrderId},
		bson.M{"$set": bson.M{"hash_data": i.HashData, "result": i.Result, "result_info": i.ResultInfo, "pay_time": i.PayTime, "is_supple": i.IsSupple}}) {
		return fmt.Errorf("update pay_order error. -> user_id: %v, order_id: %v", i.UserID, i.OrderId)
	}
	return nil
}

// 获取账号信息
func GetAccount(userId string) *cmongo.Account {
	var ret cmongo.Account
	kmongo.GetOne(context.TODO(), kmongo.AccountCollection, &ret, bson.M{"user_id": userId})
	if len(ret.Token) <= 0 {
		return nil
	}
	return &ret
}

func InitPayOrder(userId string, token string, orderId string, itemId int32, itemNum int64, cType string, cNum int64) *cmongo.PayOrder {
	return &cmongo.PayOrder{
		ID:           primitive.NewObjectID().Hex(),
		UserID:       userId,
		Token:        token,
		OrderId:      orderId,
		ItemId:       itemId,
		ItemNum:      itemNum,
		CurrencyType: cType,
		CurrencyNum:  cNum,
		DateTime:     utils.GetNowTime(),
	}
}
