package room

import (
	"c4_center/cinternal"
	"c4_center/container/cmongo"
	"c4_center/kproto"
	"c4_room/internal/battle"
	"fmt"
	"math/rand"
)

//初始化bot信息
func InitBot(matchUser *kproto.MatchUser, table *Table) (*Player, error) {
	ret := &Player{ID: matchUser.UserId, Table: table, actionCount: 1, actionChan: make(chan *PlayerMessage, 10), Hero: make(map[int32]*battle.BattleHero), HeroResultInfo: NewHeroResultInfo()}

	//bot
	ret.Bot = true
	//auto
	ret.Auto = true
	//bot level
	ret.BotLevel = matchUser.BotLevel
	//ready
	ret.SetReady(true)
	//设置昵称
	ret.NickName = "Player" + fmt.Sprintf("%05v", rand.Int31n(100000))
	//设置英雄
	ret.SetBotInitHero(matchUser.BotHeros)
	//set rank
	var rankInfo cmongo.PlayerRankInfo
	rankInfo.InitPlayerRankInfo(matchUser.UserId)
	rankInfo.SetRank1Score(matchUser.BotScore)
	ret.RankInfo = &rankInfo
	//set reward
	ret.SetInitRankReward()

	return ret, nil
}

//设置bot英雄
func (p *Player) SetBotInitHero(heroes []*kproto.HeroInfo) {
	for index := range heroes {
		h := &battle.BattleHero{Hero: cinternal.HeroDataToHero(heroes[index])}
		h.LoadHeroConfig()
		h.LoadSkillConfig()
		p.SetHeroes(h)
	}
}
