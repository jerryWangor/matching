package cron

import (
	"c4_center/container/cmongo"
	"c4_center/kmongo"
	"c4_center/kredis"
	"c4_center/utils"
	"c4_cron/internal/service"
	"context"
	"github.com/robfig/cron/v3"
	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"reflect"
	"time"
)

type Ranking struct {
	Id      int32
	EntryID cron.EntryID
	Cron    *cron.Cron
}

func (s *Ranking) Init() {
	logrus.Infof("排行榜初始化！-> %v", s.Id)
	s.Run()
}

func (s *Ranking) Run() {
	logrus.Infof("排行榜检查中！-> %v", s.Id)
	// 判断关闭时间
	closeTime := utils.DateTimeToTimestamp("20060102 150405", "20221212 100000")
	if utils.GetNowTime() > closeTime {
		s.End()
		return
	}
	s.Reset()
}

func (s *Ranking) Begin() {
	logrus.Infof("排行榜开启！-> %v", s.Id)
}

func (s *Ranking) End() {
	logrus.Infof("排行榜关闭！-> %v", s.Id)
	delete(AllCronData.RankEntryIds, s.Id)
	s.Cron.Remove(s.EntryID)
}

// 排行榜生成
func (s *Ranking) Reset() {
	s.SetRanking()
}

func (s *Ranking) SetRanking() {
	logrus.Infof("排行榜刷新！-> %v", s.Id)
	// 从mongo中查询所有玩家的分数数据
	data, err := service.GetAllPlayerRankInfo()
	if err != nil {
		logrus.Error(err)
		return
	}

	// 写redis
	if err := kredis.ZRAdd(context.TODO(), cmongo.RANKING_REDIS_NAME, data); err != nil {
		logrus.Error(err)
		return
	}

	// 同时写一份mongo
	time.Sleep(50 * time.Microsecond)
	insertDatas := make([]interface{}, 0)
	rData := kredis.ZRangeWithScores(context.TODO(), cmongo.RANKING_REDIS_NAME, 0, cmongo.RANKING_SAVE_NUM-1)
	for k, val := range rData {
		insertData := &cmongo.PlayerRankingTmp{
			ID:       primitive.NewObjectID().Hex(),
			Rank:     int32(k + 1),
			Token:    val.Member.(string),
			Score:    int32(val.Score * -1),
			DateTime: utils.GetHourZeroTimeStamp(),
		}
		insertDatas = append(insertDatas, reflect.ValueOf(insertData).Interface())
	}

	kmongo.InsertMany(context.TODO(), kmongo.PlayerRankingTmpCollection, insertDatas)
}

// 商店中的物品发生改变
func (s *Ranking) Change() {
}
