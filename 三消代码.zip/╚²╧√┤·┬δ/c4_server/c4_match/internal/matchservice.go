package internal

import (
	"c4_center/cinternal"
	"c4_center/container/cmongo"
	"c4_center/container/credis"
	"c4_center/game_config"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/utils"
	"c4_match/internal/store"
	"c4_match/match_registry"
	"context"
	"encoding/json"
	"math/rand"
	"time"

	"github.com/google/uuid"
	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

type MatchService interface {
	MatchFinish(response *MatchFinishResponse)
	MatchTimeOut(response *TimeOutResponse)
	MatchError(response *ErrorResponse)
	Process()
}

type MatchFinishResponse struct {
	User1         *store.User `json:"user_1"`
	User2         *store.User `json:"user_2"`
	MatchRuleName string      `json:"match_rule_name"`
	MatchType     int32       `json:"match_type"`
	Time          time.Time   `json:"time"`
	ActionType    string      `json:"action_type"`
}

type TimeOutResponse struct {
	User          *store.User `json:"user"`
	Time          time.Time   `json:"time"`
	ActionType    string      `json:"action_type"`
	MatchRuleName string      `json:"match_rule_name"`
}

type ErrorResponse struct {
	ActionType string `json:"action_type"`
	Error      error  `json:"error"`
}

type RespServer struct {
	matchFinish  chan *MatchFinishResponse
	matchTimeOut chan *TimeOutResponse
	matchErr     chan *ErrorResponse
}

func NewMatchFinishResponse(matchRule string, user1, user2 *store.User, matchType int32) *MatchFinishResponse {
	return &MatchFinishResponse{
		Time:          time.Now(),
		MatchRuleName: matchRule,
		User1:         user1,
		User2:         user2,
		MatchType:     matchType,
		ActionType:    "match",
	}
}

func NewMatchTimeOutResponse(matchRule string, user *store.User) *TimeOutResponse {
	return &TimeOutResponse{
		Time:          time.Now(),
		MatchRuleName: matchRule,
		ActionType:    "timeout",
		User:          user,
	}
}

func NewErrorResponse(err error) *ErrorResponse {
	return &ErrorResponse{
		ActionType: "error",
		Error:      err,
	}

}

func NewRespServer(chanSize int32) *RespServer {
	return &RespServer{
		matchFinish:  make(chan *MatchFinishResponse, chanSize),
		matchTimeOut: make(chan *TimeOutResponse, chanSize),
		matchErr:     make(chan *ErrorResponse, chanSize),
	}
}

func (r *RespServer) MatchFinish(response *MatchFinishResponse) {
	r.matchFinish <- response
}

func (r *RespServer) MatchTimeOut(response *TimeOutResponse) {
	r.matchTimeOut <- response
}

func (r *RespServer) MatchError(response *ErrorResponse) {
	r.matchErr <- response
}

func (r *RespServer) Process() {
	for {
		func() {
			defer utils.HandleCrash()

			select {
			case r := <-r.matchFinish: //匹配成功
				logrus.Infof("match : user1_id : %s ; user2_id: %s ;", r.User1.ID, r.User2.ID)
				rid := uuid.NewString()
				//create room rpc
				resp, err := SendCreateRoom(rid, r.MatchType, r.User1, r.User2)
				if err != nil {
					logrus.Error(err)
					return
				}

				//send to client
				MatchSuccess(rid, r.User1, resp)
				MatchSuccess(rid, r.User2, resp)
			case r := <-r.matchTimeOut: //匹配超时
				logrus.Infof("match : user1_id : %s timeout ;", r.User.ID)
				packet, err := getPacket(uint32(kproto.MSG_MATCH_RESULT_RESP_ID), &kproto.MATCH_RESULT_RESP{Code: -1})
				if err != nil {
					logrus.Error(err)
					return
				}

				match_registry.RpcSendToGate(r.User.ID, packet)
			case <-r.matchErr: //匹配错误

			}
		}()
	}
}

func SendCreateRoom(roomId string, matchType int32, user1, user2 *store.User) (*kproto.MATCH_CREAT_ROOM_RESP, error) {
	//get grpc service
	service, err := match_registry.EtcdClient.GetServiceInDiscovery(match_registry.ROOM_SERVICE)
	if err != nil {
		return nil, err
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}

	defer conn.Close()

	//client
	client := kproto.NewRoomServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//send to client
	packet, err := getPacket(
		uint32(kproto.MSG_MATCH_CREATE_ROOM_REQ_ID),

		func() *kproto.MATCH_CREATE_ROOM_REQ {
			ret := &kproto.MATCH_CREATE_ROOM_REQ{
				RoomId:    roomId,
				MatchType: matchType,
			}

			ret.Player1, ret.Player2 = GetMatchUser(user1, user2)
			return ret
		}(),
	)

	if err != nil {
		return nil, err
	}

	//request
	resp, err := client.RoomCreateRpc(ctx, &kproto.SendReq{Packet: packet})
	if err != nil {
		return nil, err
	}

	//respone
	var respData kproto.MATCH_CREAT_ROOM_RESP
	if err := Codec.Decode(resp.Packet.Data, &respData); err != nil {
		return nil, err
	}

	return &respData, nil
}

//send to client
func MatchSuccess(roomId string, user *store.User, resp *kproto.MATCH_CREAT_ROOM_RESP) {
	if user.Bot {
		return
	}

	sessStr, err := kredis.GetStr(context.Background(), user.ID)
	if err != nil {
		logrus.Errorf("do not have session of userid : %s;", user.ID)
		return
	}

	var sessData credis.SessionInfo
	if json.Unmarshal([]byte(sessStr), &sessData) != nil {
		logrus.Errorf("session unmarshal err of userid : %s;", user.ID)
		return
	}

	//set room info to redis
	sessData.RoomID = roomId
	sessData.RoomTcpAddress = resp.Address

	//encode
	b, err := json.Marshal(sessData)
	if err != nil {
		logrus.Error(err)
		return
	}

	//session store
	err = kredis.SetStr(context.Background(), sessData.UserID, string(b), time.Hour*24)
	if err != nil {
		logrus.Error(err)
		return
	}

	//send to client
	packet, err := getPacket(uint32(kproto.MSG_MATCH_RESULT_RESP_ID), &kproto.MATCH_RESULT_RESP{RoomId: roomId, RoomAddr: resp.Address})
	if err != nil {
		logrus.Error(err)
		return
	}

	match_registry.RpcSendToGate(user.ID, packet)
}

//-----------------------------------------------match user---------------------------------------------------

func GetMatchUser(user1, user2 *store.User) (*kproto.MatchUser, *kproto.MatchUser) {
	if user1.Bot {
		return BotMatchUser(user1, user2), &kproto.MatchUser{UserId: user2.ID, Bot: user2.Bot}
	}

	if user2.Bot {
		return &kproto.MatchUser{UserId: user1.ID, Bot: user1.Bot}, BotMatchUser(user2, user1)
	}

	return &kproto.MatchUser{UserId: user1.ID, Bot: user1.Bot}, &kproto.MatchUser{UserId: user2.ID, Bot: user2.Bot}
}

func BotMatchUser(bot, other *store.User) *kproto.MatchUser {
	//bot level
	botLevelCfg := game_config.RobotParametersConfigInstant.GetMinInfo(int32(other.Score))
	botLevel := rand.Int31n(botLevelCfg.MoveTimes_Max-botLevelCfg.MoveTimes_Min) + botLevelCfg.MoveTimes_Min

	//user hero info
	botHeroCount, botHeroGrade, botHeroLevel := BotHeroCountGradeLevel(other.ID)
	// count & level min
	botHeroCount = utils.Max(botHeroCount, botLevelCfg.MinHeros)
	botHeroLevel = utils.Max(botHeroLevel, botLevelCfg.LowHeroLv)

	//team config
	botTeam := game_config.RobotTeamConfigInstant.GetByCount(int32(botHeroCount))
	ret := &kproto.MatchUser{UserId: bot.ID, BotScore: int32(other.Score), Bot: bot.Bot, BotLevel: botLevel}

	//bot heroes
	if len(botTeam.Position_1) > 0 {
		ret.BotHeros = append(ret.BotHeros, cinternal.HeroData(BotInitHero(botTeam.Position_1, 1, botHeroGrade, botHeroLevel)))
	}
	if len(botTeam.Position_2) > 0 {
		ret.BotHeros = append(ret.BotHeros, cinternal.HeroData(BotInitHero(botTeam.Position_2, 2, botHeroGrade, botHeroLevel)))
	}
	if len(botTeam.Position_3) > 0 {
		ret.BotHeros = append(ret.BotHeros, cinternal.HeroData(BotInitHero(botTeam.Position_3, 3, botHeroGrade, botHeroLevel)))
	}
	if len(botTeam.Position_4) > 0 {
		ret.BotHeros = append(ret.BotHeros, cinternal.HeroData(BotInitHero(botTeam.Position_4, 4, botHeroGrade, botHeroLevel)))
	}
	if len(botTeam.Position_5) > 0 {
		ret.BotHeros = append(ret.BotHeros, cinternal.HeroData(BotInitHero(botTeam.Position_5, 5, botHeroGrade, botHeroLevel)))
	}
	if len(botTeam.Position_6) > 0 {
		ret.BotHeros = append(ret.BotHeros, cinternal.HeroData(BotInitHero(botTeam.Position_6, 6, botHeroGrade, botHeroLevel)))
	}
	return ret
}

func BotInitHero(genDress string, pos, grade, level int32) *cmongo.Hero {
	ret := cinternal.GetInitHero("BOT", BotGen(genDress), "", 0, 0, grade, level)
	ret.Pos = pos
	return ret
}

func BotHeroCountGradeLevel(other string) (int32, int32, int32) {
	var count, grade, level int32

	hs := cinternal.LoadHeroByNoPos(other)
	count = int32(len(hs))

	for _, v := range hs {
		level += v.Level
		grade += v.Grade
	}

	return count, grade / count, utils.Max(1, level/count)

}

func BotGen(g string) string {
	s := []byte(cinternal.RandGen())
	s[0] = g[0]
	return string(s)
}
