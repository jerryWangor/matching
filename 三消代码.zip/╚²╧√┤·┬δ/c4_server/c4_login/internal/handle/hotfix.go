package handle

import (
	"c4_center/game_config"
	"c4_center/khttp"
)

//hotfix address
func Hotfix(ctx khttp.Context) {
	d := game_config.ServerConfigInstant.GetInfo("hotfix")
	if d != nil {
		ctx.ResponseWriter().Write([]byte(d.Value))
		return
	}

	ctx.ResponseWriter().Write([]byte("cannot get key : hotfix."))
}
