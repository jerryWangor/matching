package battle

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kproto"
	"math/rand"
	"strings"
)

const ratio int32 = 10000
const LIMIT_TOKEN_ID int32 = 635

type BattleHero struct {
	*cmongo.Hero
}

func (h *BattleHero) LoadHeroConfig() {
	h.SkillConfig = make(map[int32]*game_config.SkillData)
	h.SkillEffectConfig = make(map[int32]*game_config.SkillEffectData)
	//英雄配置
	h.HeroConfig = game_config.HeroConfigInstant.GetInfo(h.GetHeroKeyGen())
	h.HeroAttrConfig = game_config.HeroAttrConfigInstant.GetInfo(h.Grade, h.Level)

	// xmax drop
	if h.Token > 0 {
		// > 635 使用配置
		if h.Token > LIMIT_TOKEN_ID {
			h.XmasConfig = game_config.ChristmasDropConfigInstant.GetInfo(h.HeroConfig.ChristmasDropID)
		} else {
			// <= 635使用1
			h.XmasConfig = game_config.ChristmasDropConfigInstant.GetInfo(1)
		}
	}

	//init
	h.CurHp = h.GetMaxHP()
	h.CurShield = h.GetMaxShield()
}

func (h *BattleHero) LoadSkillConfig() {
	//技能配置
	h.SkillConfig[h.NSkill] = game_config.SkillConfigInstant.GetInfo(h.NSkill)
	h.SkillConfig[h.USkill] = game_config.SkillConfigInstant.GetInfo(h.USkill)
	h.SkillConfig[h.PSkill_1] = game_config.SkillConfigInstant.GetInfo(h.PSkill_1)
	h.SkillConfig[h.PSkill_2] = game_config.SkillConfigInstant.GetInfo(h.PSkill_2)
	h.SkillConfig[h.PSkill_3] = game_config.SkillConfigInstant.GetInfo(h.PSkill_3)

	//技能效果
	h.SetEffectIds(h.NSkill)
	h.SetEffectIds(h.USkill)
	h.SetEffectIds(h.PSkill_1)
	h.SetEffectIds(h.PSkill_2)
	h.SetEffectIds(h.PSkill_3)
}

func (h *BattleHero) SetEffectIds(skillId int32) {
	skillConfig := h.SkillConfig[skillId]
	if skillConfig == nil {
		return
	}

	for _, v := range skillConfig.EffectId {
		h.SkillEffectConfig[v] = game_config.SkillEffectConfigInstant.GetInfo(v)
	}
}

func (h *BattleHero) GetMaxHP() int32 {
	return int32(float64(h.HeroAttrConfig.Hp) * float64(h.HeroConfig.HpParam) / float64(ratio))
}

func (h *BattleHero) GetAttack() int32 {
	return int32(float64(h.HeroAttrConfig.Attack) * float64(h.HeroConfig.AttParam) / float64(ratio))
}

//基础护盾
func (h *BattleHero) GetMaxShield() int32 {
	return int32(float64(h.HeroAttrConfig.Shield) * float64(h.HeroConfig.ShieldParam) / float64(ratio))
}

func (h *BattleHero) GetMaxEnergy() int32 {
	if h.Token > LIMIT_TOKEN_ID {
		return h.HeroConfig.MaxEnerge_A
	} else {
		return h.HeroConfig.MaxEnerge
	}
}

func (h *BattleHero) GetGrade() int32 {
	return h.Grade
}

func (h *BattleHero) GetLevel() int32 {
	return h.Level
}

func (h *BattleHero) GetEffects(skillId int32) []*game_config.SkillEffectData {
	skillConfig := h.SkillConfig[skillId]
	if skillConfig == nil {
		return nil
	}

	var ret []*game_config.SkillEffectData

	for _, v := range skillConfig.EffectId {
		if vv := h.SkillEffectConfig[v]; vv != nil {
			ret = append(ret, vv)
		}
	}
	return ret
}

//升星或升级后配置需要变更
func (h *BattleHero) UpdateConfig() {
	h.HeroAttrConfig = game_config.HeroAttrConfigInstant.GetInfo(h.Grade, h.Level)
}

func (h *BattleHero) GetHeroKeyGen() string {
	return strings.ToLower(string(h.Gene[0]))
}

func (h *BattleHero) IsInColor(color int32) bool {
	return h.ChessColor == color
}

//随机初始化技能
func (h *BattleHero) SetInitSkill() {
	h.NSkill = h.RandSkill(h.HeroConfig.NSkill)
	h.USkill = h.RandSkill(h.HeroConfig.USkill)
	h.PSkill_1 = h.RandSkill(h.HeroConfig.PSkill_1)
	h.PSkill_2 = h.RandSkill(h.HeroConfig.PSkill_2)
	h.PSkill_3 = h.RandSkill(h.HeroConfig.PSkill_3)
}

//随机英雄颜色
func (h *BattleHero) SetChessColor() {
	groups := game_config.ChessColorGroupConfigInstant.GetInfo(h.HeroConfig.ChessColor)
	if len(groups) <= 0 {
		return
	}

	var sum int32
	for _, w := range groups {
		sum += w.Scale
	}

	r := rand.Int31n(sum)
	var t int32
	for _, w := range groups {
		t += w.Scale
		if t > r {
			h.ChessColor = w.ChessColorType
			return
		}
	}
}

//gid = 技能库ID
func (h *BattleHero) RandSkill(gid int32) int32 {
	skills := game_config.SkillGroupConfigInstant.GetInfo(gid)
	if len(skills) <= 0 {
		return 0
	}

	var sum int32
	for _, w := range skills {
		sum += w.Scale
	}

	r := rand.Int31n(sum)
	var t int32
	for _, w := range skills {
		t += w.Scale
		if t > r {
			return w.SkillId
		}
	}

	return skills[len(skills)-1].SkillId
}

func (h *BattleHero) HeroData() *kproto.HeroInfo {
	ret := &kproto.HeroInfo{}
	ret.Id = h.ID
	ret.Pos = h.Pos
	ret.Grade = h.Grade
	ret.Level = h.Level
	ret.Class = h.HeroConfig.Vocation
	ret.Gene = h.Gene
	ret.GeneMask = h.GeneMask
	ret.ChessColor = h.ChessColor
	ret.CurHp = h.CurHp
	ret.MaxHp = h.GetMaxHP()
	ret.CurEnergy = h.CurEnergy
	ret.MaxEnergy = h.GetMaxEnergy()
	ret.CurShield = h.CurShield
	ret.MaxShield = h.GetMaxShield()
	ret.Attack = h.GetAttack()
	ret.Nskill = h.NSkill
	ret.Uskill = h.USkill
	ret.UserId = h.UserID
	ret.State = int32(h.State)
	ret.HeroConfigId = h.HeroConfig.HeroId

	return ret
}

func (h *BattleHero) GetHeroQuality() int32 {
	if h.Token > LIMIT_TOKEN_ID {
		return h.HeroConfig.Quality_A
	} else {
		return h.HeroConfig.Quality
	}
}

func (h *BattleHero) GetHeroInitLevel() int32 {
	if h.Token > LIMIT_TOKEN_ID {
		return h.HeroConfig.InitialLevel_A
	} else {
		return h.HeroConfig.InitialLevel
	}
}
