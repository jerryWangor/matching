package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/utils"
	"context"
	"fmt"
)

type GateService struct {
	kproto.UnimplementedGateServiceServer
}

func (s *GateService) SendToClient(ctx context.Context, req *kproto.SendReq) (*kproto.SendResp, error) {
	if s := Sessions.GetSession(req.UserId); s != nil {
		s.AllocateContext().SetResponseMessage(ktcp.NewMessage(req.Packet.MsgId, req.Packet.Data)).Send()
	}

	return &kproto.SendResp{Code: 1}, nil
}

func (s *GateService) GateRpc(ctx context.Context, req *kproto.SendReq) (*kproto.SendResp, error) {
	f := func() (*kproto.SendResp, error) {
		defer utils.HandleCrash()

		switch req.Packet.MsgId {
		case uint32(kproto.MSG_GATE_ACTIVITY_NOTICE_ASYNC_RESP_ID):
			return SendActivityState(req)
		case uint32(kproto.MSG_GATE_SHOP_NOTICE_ASYNC_RESP_ID):
			return SendShopState(req)
		case uint32(kproto.MSG_GATE_ONLINE_REQ_ID):
			return GetOnline(req)
		default:
			return nil, fmt.Errorf("msg -> %v not handle in gate service", req.Packet.MsgId)
		}
	}

	return f()
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}

func GetOnline(req *kproto.SendReq) (*kproto.SendResp, error) {
	packet, err := getPacket(uint32(kproto.MSG_GATE_ONLINE_RESP_ID), &kproto.GATE_ONLINE_RESP{Num: Sessions.Size()})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}
