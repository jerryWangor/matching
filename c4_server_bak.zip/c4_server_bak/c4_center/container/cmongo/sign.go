package cmongo

type TypeSign int32

const (
	DATETIME_FORMAT             = "20060102 150405"
	TYPE_SIGN_MONTH    TypeSign = 1
	TYPE_SIGN_WEEK     TypeSign = 2
	TYPE_SIGN_ACTIVITY TypeSign = 3
)

// 用户道具信息
type Sign struct {
	ID       string   `bson:"_id"`       // idx
	UserID   string   `bson:"user_id"`   // 玩家ID
	Type     TypeSign `bson:"type"`      // 签到类型 1 月签到 2 周签到 3 活动签到
	DateTime int64    `bson:"date_time"` // 0点时间戳，每月1号或者每周1号或者活动开始时间
	Data     int64    `bson:"data"`      // 签到数据

}
