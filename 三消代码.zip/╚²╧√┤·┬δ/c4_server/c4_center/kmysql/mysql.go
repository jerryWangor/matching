package kmysql

import (
	"errors"
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
	"strings"
)

var db *gorm.DB

func Init(dns string) {

	client, err := gorm.Open(mysql.Open(dns), &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			TablePrefix:   "",                                // table name prefix, table for `User` would be `t_users`
			SingularTable: true,                              // use singular table name, table for `User` would be `user` with this option enabled
			NoLowerCase:   false,                             // skip the snake_casing of names
			NameReplacer:  strings.NewReplacer("CID", "Cid"), // use name replacer to change struct/field name before convert it to db name
		},
		//Logger: logger.Default.LogMode(logger.Info),
	})
	if err != nil {
		fmt.Println(err)
	}

	sqlDB, err := client.DB()
	sqlDB.SetMaxIdleConns(10)
	sqlDB.SetMaxOpenConns(100)
	//client.SingularTable(true)

	db = client
}

// 直接执行原生sql
func Exec(esql string) error {
	db.Exec(esql)
	if db.Error != nil {
		return errors.New("error")
	}

	return nil
}

// 事务执行原生sql
func Transaction(sqls []string) error {
	return db.Transaction(func(tx *gorm.DB) error {
		for _, v := range sqls {
			if err := tx.Exec(v).Error; err != nil {
				// 返回任何错误都会回滚事务
				return err
			}
		}
		// 返回 nil 提交事务
		return nil
	})
}

// 插入更新
func InsertUpdate(tname string, v interface{}) error {
	db.Table(tname).Save(v)

	if db.Error != nil {
		return errors.New("error")
	}

	return nil
}

// 插入更新
func InsertUpdateVal(v interface{}) error {
	db.Save(v)

	if db.Error != nil {
		return errors.New("error")
	}

	return nil
}

// 检查表是否存在
func TableIsExists(tname string) bool {
	return db.Migrator().HasTable(tname)
	//table := Tables{}
	//db.Raw("select * from information_schema.TABLES where TABLE_NAME = ?", tname).Find(&table)
	//return !reflect.DeepEqual(table, Tables{})
}

// 创建表
func CreateTable(sql string) error {
	db.Exec(sql)
	if db.Error != nil {
		return errors.New("error")
	}
	return nil
}
