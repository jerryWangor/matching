package main

import (
	"fmt"
	"github.com/golang/protobuf/protoc-gen-go/generator"
	"modeltools/dbtools"
	"modeltools/generate"
)

type Log struct {
	Id int
}

func main() {
	//loglogin := Log{Id: 1}
	//show(loglogin)
	//初始化数据库
	dbtools.Init()
	//generate.Genertate()               //生成所有表信息
	generate.Genertate("log_points", "log_account_login", "log_player") //生成指定表信息，可变参数可传入多个表名

	fmt.Println(generator.CamelCase("last_login_time"))
}

//func show(s interface{}) {
//	fmt.Println(reflect.TypeOf(s).Name())
//}
