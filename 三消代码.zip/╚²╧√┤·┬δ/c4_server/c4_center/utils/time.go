package utils

import (
	"github.com/robfig/cron/v3"
	"github.com/sirupsen/logrus"
	"strconv"
	"time"
)

// ------------------------------------- 时间相关函数 -----------------------------------------

func GetNowTime() int64 {
	return time.Now().Unix()
}

func GetNowTimeString() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

// GetNowDateString 获取当前日期
func GetNowDateString() string {
	return time.Now().Format("2006-01-02")
}

// 获取当天0点的时间戳
func GetZeroTimeStamp() int64 {
	t := time.Now()
	return time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, t.Location()).Unix()
}

// 获取整点0点的时间戳
func GetHourZeroTimeStamp() int64 {
	t := time.Now()
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), 0, 0, 0, t.Location()).Unix()
}

// 获取当月0点的时间戳
func GetMonthZeroTimeStamp() int64 {
	t := time.Now()
	return time.Date(t.Year(), t.Month(), 1, 0, 0, 0, 0, t.Location()).Unix()
}

// 时间转时间戳
func DateTimeToTimestamp(f string, s string) int64 {
	res, _ := time.ParseInLocation(f, s, time.Local)
	return res.Unix()
}

// 获取两个时间相差天数
func GetDaysBetween2Date(format string, date1Str, date2Str string) (int64, error) {
	// 将字符串转化为Time格式
	date1, err := time.ParseInLocation(format, date1Str, time.Local)
	if err != nil {
		return 0, err
	}
	// 将字符串转化为Time格式
	date2, err := time.ParseInLocation(format, date2Str, time.Local)
	if err != nil {
		return 0, err
	}
	if date1.Sub(date2).Seconds() > 0 {
		return 0, nil
	}

	//计算相差天数
	return int64(date2.Sub(date1).Hours() / 24), nil
}

// 解析excel中的 “080000”，转成秒数
func GetNumberToSeconds(s string) int64 {
	if len(s) != 6 {
		return 0
	}
	var num int64
	hour := s[0:2]
	min := s[2:4]
	sec := s[4:]
	if hour != "00" {
		hnum, _ := strconv.ParseInt(hour, 10, 32)
		num += hnum * 60 * 60
	}
	if min != "00" {
		mnum, _ := strconv.ParseInt(min, 10, 32)
		num += mnum * 60
	}
	if sec != "00" {
		snum, _ := strconv.ParseInt(sec, 10, 32)
		num += snum
	}
	return num
}

type MonthInfo struct {
	StartDay string
	EndDay   string
	MonStr   string
}

/*
// 将时间分隔成每月
例：2021-09-22 16:00:00 -- 2021-12-01 15:59:59
结果：
2021-09-22 16:00:00 2021-09-30 23:59:59 202109
2021-10-01 00:00:00 2021-10-31 23:59:59 202110
2021-11-01 00:00:00 2021-11-30 23:59:59 202111
2021-12-01 00:00:00 2021-12-01 15:59:59 202112
*/
func GetBetweenMonths(t1, t2 time.Time) ([]MonthInfo, bool) {
	sameMonth := false
	result := make([]MonthInfo, 0)
	//	先判断两个日期是否在同一个月
	if t1.Format("200601") == t2.Format("200601") {
		result = append(result, MonthInfo{
			StartDay: t1.Format("2006-01-02 15:04:05"),
			EndDay:   t2.Format("2006-01-02 15:04:05"),
			MonStr:   t2.Format("200601"),
		})
		sameMonth = true
	} else {

		//	获取第一个日期在当月的最后一天的23:59:59
		endT1 := time.Date(t1.Year(), t1.Month()+1, 1, 0, 0, 0, -1, t1.Location())

		result = append(result, MonthInfo{
			StartDay: t1.Format("2006-01-02 15:04:05"),
			EndDay:   endT1.Format("2006-01-02 15:04:05"),
			MonStr:   t1.Format("200601"),
		})

		// 将第一个日期的时间重置为当月的1号，防止增加1个月后得到的日期不是下月的1号
		t1Tmp := time.Date(t1.Year(), t1.Month(), 1, 0, 0, 0, 0, t1.Location())

		// 判断是否达到第二个日期
		var i = 1
		for {
			t3 := t1Tmp.AddDate(0, i, 0)
			// 判断是否到达第二个日期所在的月份
			if t3.Format("200601") == t2.Format("200601") {
				// 获取第二个日期在当月的第一天的起始时间
				startT2 := time.Date(t2.Year(), t2.Month(), 1, 0, 0, 0, 0, t2.Location())

				result = append(result, MonthInfo{
					StartDay: startT2.Format("2006-01-02 15:04:05"),
					EndDay:   t2.Format("2006-01-02 15:04:05"),
					MonStr:   t2.Format("200601"),
				})
				// 跳出
				break
			} else {
				startT3 := time.Date(t3.Year(), t3.Month(), 1, 0, 0, 0, 0, t3.Location())
				endT3 := time.Date(t3.Year(), t3.Month()+1, 1, 0, 0, 0, -1, t3.Location())
				result = append(result, MonthInfo{
					StartDay: startT3.Format("2006-01-02 15:04:05"),
					EndDay:   endT3.Format("2006-01-02 15:04:05"),
					MonStr:   t3.Format("200601"),
				})
			}
			i++

			// 为了防止异常导致 for 循环无法停止出现内存溢出，加一个防护措施
			if i > 12 {
				break
			}
		}
	}

	return result, sameMonth
}

// GetBetweenDates 根据开始日期和结束日期计算出时间段内所有日期
// 参数为日期格式，如：2020-01-01
func GetBetweenDates(sdate, edate string) []string {
	d := []string{}
	timeFormatTpl := "2006-01-02 15:04:05"
	if len(timeFormatTpl) != len(sdate) {
		timeFormatTpl = timeFormatTpl[0:len(sdate)]
	}
	date, err := time.Parse(timeFormatTpl, sdate)
	if err != nil {
		// 时间解析，异常
		return d
	}
	date2, err := time.Parse(timeFormatTpl, edate)
	if err != nil {
		// 时间解析，异常
		return d
	}
	if date2.Before(date) {
		// 如果结束时间小于开始时间，异常
		return d
	}
	// 输出日期格式固定
	timeFormatTpl = "20060102"
	date2Str := date2.Format(timeFormatTpl)
	d = append(d, date.Format(timeFormatTpl))
	for {
		date = date.AddDate(0, 0, 1)
		dateStr := date.Format(timeFormatTpl)
		d = append(d, dateStr)
		if dateStr == date2Str {
			break
		}
	}
	return d
}

func GetNextRefreshTime(refreshTime string) int64 {
	// 计算下一次刷新时间
	//fmt.Println(refreshTime)
	if len(refreshTime) <= 0 {
		return 0
	}
	secondParser := cron.NewParser(
		cron.Second | cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow | cron.Descriptor,
	)
	p, err := secondParser.Parse(refreshTime)
	if err != nil {
		logrus.Error(err)
		return 0
	}
	t := time.Now()
	t = p.Next(t)
	//fmt.Println("下次刷新时间", t.Unix())
	return t.Unix()
}
