package game_config

type ShopType struct {
	ID           int32  `tb_name:"商城ID"`
	Name         int32  `tb_name:"商城名称"`
	Refresh_Time string `tb_name:"刷新时间"`
	Order        int32  `tb_name:"商城排序"`
	Switch       int32  `tb_name:"商城开关"`
}

var ShopTypeConfigInstant *ShopTypeConfig

type ShopTypeConfig struct {
	ShopType []*ShopType
	Infos    map[int32]*ShopType //key == Id
}

func InitShopTypeConfig(path string) {
	ShopTypeConfigInstant = &ShopTypeConfig{Infos: make(map[int32]*ShopType)}
	//加载
	LoadJsonFile(path+"/ShopType.json", ShopTypeConfigInstant)
	//初始化
	ShopTypeConfigInstant.InitIndex()
}

func (h *ShopTypeConfig) InitIndex() {
	for i, _ := range h.ShopType {
		h.Infos[h.ShopType[i].ID] = h.ShopType[i]
	}
}

func (h *ShopTypeConfig) GetInfo(id int32) *ShopType {
	data, ok := h.Infos[id]
	if !ok {
		return nil
	}
	return data
}
