package handle

import (
	"c4_center/khttp"
	"c4_center/utils"
	"encoding/json"
	"fmt"
	"github.com/gogf/gf/os/glog"
	"github.com/gogf/gf/os/gproc"
	"github.com/gogf/gf/text/gstr"
	"runtime"
)

type Time struct {
	Time string `json:"time"` // 时间
}

// 设置服务器时间
func SetTime(ctx khttp.Context) {
	ctx.Request().ParseForm()
	pass := ctx.Request().FormValue("pass")
	message := ctx.Request().FormValue("message")
	fmt.Println("message", message)
	if pass == "" || message == "" {
		ReturnJson(ctx, -1, "param is null", nil)
		return
	}
	//// 验证pass
	sign := utils.GetMd5String(KEY + message)
	if pass != sign {
		ReturnJson(ctx, -2, "pass error", nil)
		return
	}
	// 解析message
	var t = Time{}
	if err := json.Unmarshal([]byte(message), &t); err != nil {
		ReturnJson(ctx, -1, "params error", nil)
		return
	}

	if r := UpdateSystemDate(t.Time); r {
		ReturnJson(ctx, 0, "success", nil)
	} else {
		ReturnJson(ctx, -1, "set time error", nil)
	}
}

func UpdateSystemDate(dateTime string) bool {
	system := runtime.GOOS
	switch system {
	case "windows":
		{
			_, err1 := gproc.ShellExec(`date  ` + gstr.Split(dateTime, " ")[0])
			_, err2 := gproc.ShellExec(`time  ` + gstr.Split(dateTime, " ")[1])
			if err1 != nil && err2 != nil {
				glog.Info("更新系统时间错误:请用管理员身份启动程序!")
				return false
			}
			return true
		}
	case "linux":
		{
			_, err1 := gproc.ShellExec(`date -s  "` + dateTime + `"`)
			if err1 != nil {
				glog.Info("更新系统时间错误:", err1.Error())
				return false
			}
			return true
		}
	case "darwin":
		{
			_, err1 := gproc.ShellExec(`date -s  "` + dateTime + `"`)
			if err1 != nil {
				glog.Info("更新系统时间错误:", err1.Error())
				return false
			}
			return true
		}
	}
	return false
}
