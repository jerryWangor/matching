package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/utils"
	"context"
	"fmt"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

var Codec ktcp.Codec

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

type MatchRpcService struct {
	kproto.UnimplementedMatchServiceServer
}

func (r *MatchRpcService) MatchRpc(ctx context.Context, req *kproto.SendReq) (*kproto.SendResp, error) {
	f := func() (*kproto.SendResp, error) {
		defer utils.HandleCrash()

		switch req.Packet.MsgId {
		case uint32(kproto.MSG_MATCH_REQUEST_REQ_ID):
			return AddUser(req)
		case uint32(kproto.MSG_MATCH_CANCEL_REQ_ID):
			return MatchCancel(req)
		default:
			return nil, fmt.Errorf("msg -> %v not handle in match service", req.Packet.MsgId)
		}

	}

	return f()
}

func (r *MatchRpcService) RoomStateRpc(context.Context, *kproto.SendReq) (*kproto.SendResp, error) {
	return nil, status.Errorf(codes.Unimplemented, "method RoomStateRpc not implemented")
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
