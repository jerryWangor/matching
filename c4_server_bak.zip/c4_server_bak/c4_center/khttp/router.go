package khttp

import (
	"c4_center/ktcp"
	"fmt"
	"io"
	"net/http"
	"os"
	"reflect"
	"runtime"
	"sort"

	"github.com/olekukonko/tablewriter"
	"github.com/spf13/cast"
)

func NewRouter(codec ktcp.Codec) *Router {
	return &Router{
		handlerMapper:     make(map[interface{}]HandlerFunc),
		middlewaresMapper: make(map[interface{}][]MiddlewareFunc),
		codec:             codec,
	}
}

type Router struct {
	handlerMapper     map[interface{}]HandlerFunc
	middlewaresMapper map[interface{}][]MiddlewareFunc
	globalMiddlewares []MiddlewareFunc
	notFoundHandler   HandlerFunc
	codec             ktcp.Codec
}

type HandlerFunc func(ctx Context)

type MiddlewareFunc func(next HandlerFunc) HandlerFunc

var nilHandler HandlerFunc = func(ctx Context) {}

func (rt *Router) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	var handler HandlerFunc
	if v, has := rt.handlerMapper[r.URL.Path]; has {
		handler = v
	}

	var mws = rt.globalMiddlewares
	if v, has := rt.middlewaresMapper[r.URL.Path]; has {
		mws = append(mws, v...) // append to global ones
	}

	// create the handlers stack
	wrapped := rt.wrapHandlers(handler, mws)

	// and call the handlers stack
	wrapped(rt.allocateContext(w, r))
}

// wrapHandlers wraps handler and middlewares into a right order call stack.
// Makes something like:
// 	var wrapped HandlerFunc = m1(m2(m3(handle)))
func (rt *Router) wrapHandlers(handler HandlerFunc, middles []MiddlewareFunc) (wrapped HandlerFunc) {
	if handler == nil {
		handler = rt.notFoundHandler
	}
	if handler == nil {
		handler = nilHandler
	}

	wrapped = handler
	for i := len(middles) - 1; i >= 0; i-- {
		m := middles[i]
		wrapped = m(wrapped)
	}
	return wrapped
}

// register stores handler and middlewares for id.
func (rt *Router) register(id interface{}, h HandlerFunc, m ...MiddlewareFunc) {
	if h != nil {
		rt.handlerMapper[id] = h
	}
	ms := make([]MiddlewareFunc, 0, len(m))
	for _, mm := range m {
		if mm != nil {
			ms = append(ms, mm)
		}
	}
	if len(ms) != 0 {
		rt.middlewaresMapper[id] = ms
	}
}

// registerMiddleware stores the global middlewares.
func (rt *Router) registerMiddleware(m ...MiddlewareFunc) {
	for _, mm := range m {
		if mm != nil {
			rt.globalMiddlewares = append(rt.globalMiddlewares, mm)
		}
	}
}

func (rt *Router) setNotFoundHandler(handler HandlerFunc) {
	rt.notFoundHandler = handler
}

func (rt *Router) allocateContext(w http.ResponseWriter, r *http.Request) Context {
	ret := &routeContext{}
	ret.SetCode(rt.codec)
	ret.SetRequest(r)
	ret.SetResponseWriter(w)
	return ret
}

// printHandlers prints registered route handlers to console.
func (r *Router) printHandlers(addr string) {
	var w io.Writer = os.Stdout

	_, _ = fmt.Fprintf(w, "\n[HTTP] Message-Route Table: \n")
	table := tablewriter.NewWriter(w)
	table.SetHeader([]string{"Message ID", "Route Handler"})
	table.SetAutoFormatHeaders(false)

	// sort ids
	ids := make([]interface{}, 0, len(r.handlerMapper))
	for id := range r.handlerMapper {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(i, j int) bool {
		a, b := cast.ToString(ids[i]), cast.ToString(ids[j])
		return a < b
	})

	// add table row
	for _, id := range ids {
		h := r.handlerMapper[id]
		handlerName := runtime.FuncForPC(reflect.ValueOf(h).Pointer()).Name()
		table.Append([]string{fmt.Sprintf("%v", id), handlerName})
	}

	table.Render()
	_, _ = fmt.Fprintf(w, "[HTTP] Serving at: %s\n\n", addr)
}
