package handle

import (
	"c4_center/khttp"
	"c4_center/kproto"
	"c4_gm/gm_registry"
	"fmt"
)

func GetOnline(ctx khttp.Context) {
	getGateOnline(ctx)
	ctx.ResponseWriter().Write([]byte("\n"))
	getRoomOnline(ctx)
}

func getGateOnline(ctx khttp.Context) {
	services, err := gm_registry.EtcdClient.GetAllServicesInDiscovery(gm_registry.GATE_SERVICE)
	if err != nil {
		ReturnJson(ctx, -1, "get gate-services error", nil)
		return
	}

	packet, _ := getPacket(uint32(kproto.MSG_GATE_ONLINE_REQ_ID), &kproto.GATE_ONLINE_REQ{})
	for k, v := range services {
		resp, err := GateRpc(packet, services[k])
		if err != nil {
			ReturnJson(ctx, -2, err.Error(), nil)
			continue
		}

		var respData kproto.GATE_ONLINE_RESP
		if err := Codec.Decode(resp.Packet.Data, &respData); err != nil {
			ReturnJson(ctx, -2, "gate resp data error", nil)
			continue
		}

		ReturnJson(ctx, 0, fmt.Sprintf("Gate %v Online : %v", v.ID, respData.Num), nil)
	}
}

func getRoomOnline(ctx khttp.Context) {
	services, err := gm_registry.EtcdClient.GetAllServicesInDiscovery(gm_registry.ROOM_SERVICE)
	if err != nil {
		ReturnJson(ctx, -1, "get room-services error", nil)
		return
	}

	packet, _ := getPacket(uint32(kproto.MSG_BATTLE_ONLINE_REQ_ID), &kproto.BATTLE_ONLINE_REQ{})
	for k, v := range services {
		resp, err := RoomRpc(packet, services[k])
		if err != nil {
			ReturnJson(ctx, -2, err.Error(), nil)
			continue
		}

		var respData kproto.BATTLE_ONLINE_RESP
		if err := Codec.Decode(resp.Packet.Data, &respData); err != nil {
			ReturnJson(ctx, -2, "room resp data error", nil)
			continue
		}

		ReturnJson(ctx, 0, fmt.Sprintf("Room %v Online : %v", v.ID, respData.Num), nil)
	}
}
