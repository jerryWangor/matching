package game_config

import "fmt"

type PVPChestQualityData struct {
	QualityId int32  `tb_name:"品质类型Id"`
	RankId    int32  `tb_name:"段位Id"`
	ItemId    string `tb_name:"道具Id"`
}

var PVPChestQualityConfigInstant *PVPChestQualityConfig

type PVPChestQualityConfig struct {
	PVPChestQualityData []*PVPChestQualityData
	Infos               map[string]*PVPChestQualityData
}

func InitPVPChestQualityConfig(path string) {
	PVPChestQualityConfigInstant = &PVPChestQualityConfig{Infos: make(map[string]*PVPChestQualityData)}
	//加载
	LoadJsonFile(path+"/PVPChestQualityData.json", PVPChestQualityConfigInstant)
	//初始化
	PVPChestQualityConfigInstant.InitIndex()
}

func (s *PVPChestQualityConfig) InitIndex() {
	for i, v := range s.PVPChestQualityData {
		s.Infos[s.GetKey(v.QualityId, v.RankId)] = s.PVPChestQualityData[i]
	}
}

func (s *PVPChestQualityConfig) GetInfo(quality, rankId int32) *PVPChestQualityData {
	return s.Infos[s.GetKey(quality, rankId)]
}

func (s *PVPChestQualityConfig) GetKey(quality, rankId int32) string {
	return fmt.Sprintf("%v-%v", quality, rankId)
}
