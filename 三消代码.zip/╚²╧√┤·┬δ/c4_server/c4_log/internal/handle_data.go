package internal

import (
	"c4_center/khttp"
	"c4_center/klog"
	"c4_center/kproto"
	"c4_log/internal/handle"
	"encoding/json"
	"errors"
	"github.com/sirupsen/logrus"
)

func NotFound(ctx khttp.Context) {
	// panic("11111111111111111")
	// fmt.Fprintln(ctx.ResponseWriter(), "not found.")
	logrus.Errorf("cant find router for url: %s", ctx.Request().URL)
}

func CheckData(req *kproto.SendReq) (*kproto.SendResp, error) {
	// 把data解析成logdata
	logdata := &klog.LogData{}
	err := json.Unmarshal(req.Packet.Data, logdata)
	if err != nil {
		return nil, err
	}

	// 判断执行sql切片是否为空
	if logdata.Data == nil {
		return nil, errors.New("data is null")
	}

	// 判断是插入还是更新
	if logdata.Type == klog.LogTypeInsert {
		handle.LogInsertDataChan <- logdata
	}

	//fmt.Println(logdata)

	packet, err := getPacket(req.Packet.MsgId, &kproto.LOGIN_SESSION_RESP{})
	if err != nil {
		logrus.Error("packet error")
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
