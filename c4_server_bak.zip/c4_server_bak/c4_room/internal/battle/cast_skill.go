package battle

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kproto"
)

//一次攻击
func HeroEffect(srcHero *BattleHero, skillId int32, srcHeros []*BattleHero, dstHeros []*BattleHero) *kproto.HeroAtt {
	ret := &kproto.HeroAtt{UserId: srcHero.UserID, HeroPos: srcHero.Pos, SkillId: skillId}

	effects := srcHero.GetEffects(skillId)
	for _, ev := range effects {
		ret.Effects = append(ret.Effects, SingleEffect(ev.Id, srcHero, srcHeros, dstHeros))
	}
	return ret
}

//单次效果
func SingleEffect(effectId int32, srcHero *BattleHero, srcHeros []*BattleHero, dstHeros []*BattleHero) *kproto.HeroAttEffect {
	ret := &kproto.HeroAttEffect{EffectId: effectId}

	// fmt.Printf("英雄技能效果: %v\n", effectId)

	targets := GetTargetHeros(effectId, srcHero, srcHeros, dstHeros)
	for _, tv := range targets {
		ret.Targets = append(ret.Targets, SingleAttack(effectId, srcHero, tv))
	}
	return ret
}

//单次攻击
func SingleAttack(effectId int32, srcHero *BattleHero, dstHero *BattleHero) *kproto.HeroAttTarget {
	effect := game_config.SkillEffectConfigInstant.GetInfo(effectId)
	if effect == nil {
		return nil
	}

	switch effect.EffectType {
	case 1:
		return AttackType1(effectId, srcHero, dstHero)
	case 2:
		return AttackType2(effectId, srcHero, dstHero)
	case 3:
		return AttackType3(effectId, srcHero, dstHero)

	}

	return nil
}

//直伤
func AttackType1(effectId int32, srcHero *BattleHero, dstHero *BattleHero) *kproto.HeroAttTarget {
	dmg := GetEffectValue(effectId, srcHero, dstHero)

	//侁先计算护盾
	if dmg > dstHero.CurShield {
		dmg -= dstHero.CurShield
		dstHero.CurShield = 0
		dstHero.CurHp = Max(0, dstHero.CurHp-dmg)
	} else {
		dstHero.CurShield -= dmg
	}

	if dstHero.CurHp <= 0 {
		dstHero.State = cmongo.DEATH
	}

	// fmt.Printf("位置 %v 剩余护盾 %v -- 剩余血量 %v\n", dstHero.Pos, dstHero.CurShield, dstHero.CurHp)

	return &kproto.HeroAttTarget{UserId: dstHero.UserID, HeroPos: dstHero.Pos, Value: &kproto.HeroAttValue{CurHp: dstHero.CurHp, CurShield: dstHero.CurShield, State: int32(dstHero.State)}}
}

//加血
func AttackType2(effectId int32, srcHero *BattleHero, dstHero *BattleHero) *kproto.HeroAttTarget {
	val := GetEffectValue(effectId, srcHero, dstHero)

	dstHero.CurHp = Min(dstHero.GetMaxHP(), dstHero.CurHp+val)

	// fmt.Printf("位置 %v 剩余护盾 %v -- 剩余血量 %v\n", dstHero.Pos, dstHero.CurShield, dstHero.CurHp)

	return &kproto.HeroAttTarget{UserId: dstHero.UserID, HeroPos: dstHero.Pos, Value: &kproto.HeroAttValue{CurHp: dstHero.CurHp, CurShield: dstHero.CurShield, State: int32(dstHero.State)}}
}

//加盾
func AttackType3(effectId int32, srcHero *BattleHero, dstHero *BattleHero) *kproto.HeroAttTarget {
	val := GetEffectValue(effectId, srcHero, dstHero)

	dstHero.CurShield = Min(dstHero.CurShield+val, dstHero.GetMaxShield())

	// fmt.Printf("位置 %v 剩余护盾 %v -- 剩余血量 %v\n", dstHero.Pos, dstHero.CurShield, dstHero.CurHp)

	return &kproto.HeroAttTarget{UserId: dstHero.UserID, HeroPos: dstHero.Pos, Value: &kproto.HeroAttValue{CurHp: dstHero.CurHp, CurShield: dstHero.CurShield, State: int32(dstHero.State)}}
}

func Max(x, y int32) int32 {
	if x > y {
		return x
	}

	return y
}

func Min(x, y int32) int32 {
	if x < y {
		return x
	}

	return y
}
