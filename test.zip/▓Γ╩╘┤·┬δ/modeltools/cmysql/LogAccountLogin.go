package cmysql

type LogAccountLogin struct {
	Id int `gorm:"primaryKey" json:"id"` 
	Accid string `gorm:"" json:"accid"` 
	LoginTime int `gorm:"" json:"logintime"` 
}