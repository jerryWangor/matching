package room

import (
	"c4_center/container/cmongo"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/utils"
	"c4_room/internal/battle"
	"context"
	"fmt"
	"math/rand"
	"sync"

	"go.mongodb.org/mongo-driver/bson"
)

//英雄位置列表
var (
	HeroPos  = []int32{1, 2, 3, 4, 5, 6}
	ROLL_POS = []int32{1, 2, 3, 4, 5, 6}
)

type PlayerMessage struct {
	MsgId uint32
	Data  interface{}
}

func NewPlayerMessage(msgId uint32, data interface{}) *PlayerMessage {
	return &PlayerMessage{MsgId: msgId, Data: data}
}

type Player struct {
	ID             string //userid
	NickName       string
	Table          *Table //所在桌
	actionCount    int32  //操作次数
	actionFinish   bool   //操作次数是否用完
	actionReceiver bool   //是否接收操作
	actionTime     int64  //技能&消除消耗时间(只保存最大时间)
	surrender      bool   //认输
	actionChan     chan *PlayerMessage
	Ctx            context.Context
	Session        ktcp.Session
	Ready          bool
	Hero           map[int32]*battle.BattleHero //玩家阵容英雄 {key=1-6} 位置
	HeroResultInfo *HeroResultInfo
	Bot            bool //是否为机器人
	Auto           bool //是否自动战斗
	BotLevel       int32
	RollPoint      int32
	RankInfo       *cmongo.PlayerRankInfo //积分
	RankReward     RankReward             //结算道具接口
	Lock           sync.Mutex
}

//初始化player
func InitPlayer(userid string, table *Table) (*Player, error) {
	ret := &Player{ID: userid, Table: table, actionCount: 1, actionChan: make(chan *PlayerMessage, 10), Hero: make(map[int32]*battle.BattleHero), HeroResultInfo: NewHeroResultInfo()}
	//设置昵称
	if err := ret.SetInitNickName(); err != nil {
		return nil, err
	}

	//设置rankupdate
	ret.SetInitRankReward()
	//设置积分
	ret.SetInitScore()
	//设置英雄
	ret.SetInitHero()

	return ret, nil
}

//设置rank update
func (p *Player) SetInitRankReward() {
	switch p.Table.MatchType {
	case cmongo.MATCH_TYPE_1:
		p.RankReward = &Rank1RewardResult{}
	default:
		p.RankReward = &RankDefaultRewardResult{}
	}
}

//设置初始化英雄
func (p *Player) SetInitHero() {
	var ll []*cmongo.Hero
	kmongo.Get(context.TODO(), kmongo.HeroCollection, &ll, bson.M{"user_id": p.ID, "state": cmongo.ATTACK})

	for index := range ll {
		h := &battle.BattleHero{Hero: ll[index]}
		h.LoadHeroConfig()
		h.LoadSkillConfig()
		p.SetHeroes(h)
	}
}

//设置初始化昵称
func (p *Player) SetInitNickName() error {
	var account cmongo.Account
	kmongo.GetOne(context.TODO(), kmongo.AccountCollection, &account, bson.M{"user_id": p.ID})
	if len(account.ID) <= 0 {
		return fmt.Errorf("cannot get account -> %v", p.ID)
	}

	p.NickName = account.NickName

	return nil
}

//初始化积分
func (p *Player) SetInitScore() {
	var rankInfo cmongo.PlayerRankInfo
	kmongo.GetOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rankInfo, bson.M{"user_id": p.ID})

	if len(rankInfo.ID) <= 0 {
		rankInfo.UserID = p.ID
	}

	p.RankInfo = &rankInfo
}

func (p *Player) SetHeroes(heros ...*battle.BattleHero) {
	for i := range heros {
		p.Hero[heros[i].Pos] = heros[i]
	}
}

func (p *Player) RollExcept(except int32) int32 {
	if except < 0 {
		p.RollPoint = ROLL_POS[rand.Intn(len(ROLL_POS))]
		return p.RollPoint
	}

	var rest []int32
	for _, v := range ROLL_POS {
		if v == except {
			continue
		}

		rest = append(rest, v)
	}

	p.RollPoint = rest[rand.Intn(len(rest))]
	return p.RollPoint
}

func (p *Player) SetCtx(ctx context.Context) {
	p.Ctx = ctx
}

func (p *Player) GetID() string {
	return p.ID
}

func (p *Player) SetReady(r bool) {
	p.Ready = r
}

func (p *Player) IsReady() bool {
	return p.Ready
}

func (p *Player) SendMsg(msgid uint32, data interface{}) {
	if p.Session != nil {
		p.Session.AllocateContext().MustSetResponse(msgid, data).Send()
	}
}

func (p *Player) SetSession(sess ktcp.Session) {
	if sess != nil {
		p.SetReady(true)
	}

	p.Session = sess
}

func (p *Player) ReciveAction(ac *PlayerMessage) {
	p.actionChan <- ac
}

func (p *Player) PlayerAction() {
	go p.DoAction()
	if p.Bot {
		go p.AutoSwap()
	}

}

func (p *Player) IsActionFinish() bool {
	return p.actionFinish
}

func (p *Player) CheckActionCount() {
	p.actionCount--
	if p.actionCount <= 0 {
		p.actionFinish = true
	}
}

func (p *Player) ResetActionCount() {
	p.actionCount = 1
	p.actionFinish = false
}

func (p *Player) AddActionCount(count int32) {
	p.actionCount += count
}

//设置操作时间
func (p *Player) SetActionTime(time int64) {
	if p.actionTime < time {
		p.actionTime = time
	}

}

//减少操作时间
func (p *Player) SubActionTime(time int64) {
	p.actionTime = utils.Max64(0, p.actionTime-time)
}

//操作时间是否完成
func (p *Player) IsActionTimeOver() bool {
	return p.actionTime <= 0
}

//设置action receiver
func (p *Player) SetActionReceiver(val bool) {
	p.actionReceiver = val
}

//获取
func (p *Player) GetActionReceiver() bool {
	return p.actionReceiver
}

//认输
func (p *Player) SetSurrender() {
	p.surrender = true
}

//
func (p *Player) GetSurrender() bool {
	return p.surrender
}

func (p *Player) PlayerData() *kproto.PlayerInfo {
	ret := &kproto.PlayerInfo{Userid: p.ID, RollPoint: p.RollPoint}

	for _, v := range p.Hero {
		ret.HInfos = append(ret.HInfos, v.HeroData())
	}
	return ret
}

//是否结束
func (p *Player) IsEnd() (bool, int32) {
	if p.surrender {
		return true, 1
	}

	for _, v := range p.Hero {
		if v.State != cmongo.DEATH {
			return false, 0
		}
	}
	return true, 0
}
