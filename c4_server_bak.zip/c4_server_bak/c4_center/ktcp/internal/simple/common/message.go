package common

const (
	_ int = iota
	MsgIdPingReq
	MsgIdPingAck
)
