package handle

import (
	"bytes"
	"c4_center/kproto"
	"c4_center/ktcp"
	"fmt"
	"io/ioutil"
	"net/http"
	"testing"

	"google.golang.org/protobuf/proto"
)

func TestLogin(t *testing.T) {
	b, _ := proto.Marshal(&kproto.LOGIN_SESSION_PLATFORM_REQ{Platform: "aaaaaaaa", Token: "bbb"})
	req, err := http.NewRequest("POST", "http://lobby.lyami.net:16001/platform/login", bytes.NewBuffer(b))
	if err != nil {
		t.Fatal(err)
	}

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}

	body, _ := ioutil.ReadAll(resp.Body)

	m := &kproto.LOGIN_SESSION_RESP{}
	proto.Unmarshal(body, m)

	t.Log(m)

}

func TestGG(t *testing.T) {
	aa := []byte{10, 7, 119, 97, 110, 103, 106, 105, 110}
	cc := &ktcp.ProtobufCodec{}

	var h kproto.BATTLE_END_GAME_RESP
	cc.Decode(aa, &h)

	fmt.Println(h)
}
