package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"context"
)

var Codec ktcp.Codec

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

type CronService struct {
	kproto.UnimplementedCronServiceServer
}

func (l *CronService) CronRpc(context.Context, *kproto.SendReq) (*kproto.SendResp, error) {
	return &kproto.SendResp{}, nil
}
