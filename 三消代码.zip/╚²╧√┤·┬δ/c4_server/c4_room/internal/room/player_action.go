package room

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kproto"
	"c4_room/internal/battle"
	"sort"
	"time"
)

func (p *Player) GetMaxHeroColor() int32 {
	m := make(map[int32]int32)

	for _, v := range p.Hero {
		if v.State == cmongo.DEATH {
			continue
		}

		m[v.ChessColor] = m[v.ChessColor] + 1
	}

	var color, count int32 = 0, 0

	for k, v := range m {
		if v > count {
			count = v
			color = k
		}
	}

	return color
}

func (p *Player) AutoSwap() {
	if p.Table.State != PLAY_STATE {
		return
	}

	for {
		select {
		case <-p.Ctx.Done():
			return
		default:
			time.Sleep(time.Millisecond * 10)

			if p.Auto {
				if !p.GetActionReceiver() {
					continue
				}

				p.AutoMove()
				p.AutoSkill()
			}

		}
	}
}

func (p *Player) AutoSkill() {
	for _, v := range p.Hero {
		if v == nil || v.CurEnergy < v.GetMaxEnergy() || v.State == cmongo.DEATH {
			continue
		}

		time.Sleep(time.Millisecond * 100)
		msg := NewPlayerMessage(uint32(kproto.MSG_BATTLE_USE_SKILL_REQ_ID), kproto.BATTLE_USE_SKILL_REQ{Pos: v.Pos})
		p.ReciveAction(msg)
	}
}

func (p *Player) AutoMove() {
	if !p.IsActionTimeOver() {
		return
	}

	time.Sleep(time.Duration(p.Table.RoundTime / int64(p.BotLevel)))

	pi, tx, ty := p.Table.Board.AutoMove(p.GetMaxHeroColor(), true)
	msg := NewPlayerMessage(uint32(kproto.MSG_BATTLE_MOVE_REQ_ID), kproto.BATTLE_MOVE_REQ{MSource: &kproto.BallCoordinate{X: pi.PosX, Y: pi.PosY}, MTar: &kproto.BallCoordinate{X: tx, Y: ty}})
	p.ReciveAction(msg)
}

func (p *Player) DoAction() {
	for {
		select {
		case <-p.Ctx.Done():
			return
		case a := <-p.actionChan:
			if !p.GetActionReceiver() {
				if p.Session != nil {
					p.Session.AllocateContext().MustSetResponse(uint32(kproto.MSG_BATTLE_MOVE_ASYN_RESP_ID), &kproto.BATTLE_MOVE_ASYN_RESP{Code: -99}).Send()
				}
				continue
			}

			switch a.MsgId {
			case uint32(kproto.MSG_BATTLE_MOVE_REQ_ID):
				p.move(a.Data)
			case uint32(kproto.MSG_BATTLE_USE_SKILL_REQ_ID):
				p.HeroUseSkill(a.Data)
			}
		}
	}
}

func (p *Player) move(data interface{}) {
	req := data.(kproto.BATTLE_MOVE_REQ)

	//不能移动返回
	if !p.Table.Board.SwapAuto(req.MSource.X, req.MSource.Y, req.MTar.X, req.MTar.Y) {
		p.Session.AllocateContext().MustSetResponse(uint32(kproto.MSG_BATTLE_MOVE_ASYN_RESP_ID), &kproto.BATTLE_MOVE_ASYN_RESP{Code: -100}).Send()
		return
	}

	//减少可操作次数
	p.CheckActionCount()
	//设置时间
	p.SetActionTime(int64(1+len(p.Table.ResultInfo)) * int64(time.Second))
	//可以移动返回
	p.Table.Boardcast(uint32(kproto.MSG_BATTLE_MOVE_ASYN_RESP_ID), &kproto.BATTLE_MOVE_ASYN_RESP{MSource: req.MSource, MTar: req.MTar})

	//消除后棋盘信息返回
	keys := []int32{}
	for k := range p.Table.ResultInfo {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool { return keys[i] < keys[j] })

	// fmt.Printf("---移动{%v:%v} -> {%v:%v} 后数据产出---\n", req.MSource.X, req.MSource.Y, req.MTar.X, req.MTar.Y)
	for index, k := range keys {
		v := p.Table.ResultInfo[k]
		// fmt.Printf("第%v次数据产出打印----------------\n", k)

		// clear := v.OutClearData()
		// newP := v.OutNewPieceData()

		// fmt.Println("-----------clear-------------")
		// for k := range clear {
		// 	fmt.Println(clear[k])
		// }

		// fmt.Println("-----------new-------------")
		// for k := range newP {
		// 	fmt.Println(newP[k])
		// }

		p.Table.Boardcast(uint32(kproto.MSG_BATTLE_ELIMINATE_RESP_ID),
			&kproto.BATTLE_ELIMINATE_RESP{
				EliminatedBalls:  v.OutClearData(),
				BallsCreated:     v.OutNewPieceData(),
				Atts:             p.HeroResultInfo.NskillResult[k],
				Energies:         p.HeroResultInfo.OutEnergyResult(k),
				ActionCount:      p.actionCount,
				IsAddActionCount: v.IsAddAction,
				IsLast:           index == len(keys)-1})

	}

	//是否洗牌
	if p.Table.IsShuffle {
		p.Table.Boardcast(uint32(kproto.MSG_BATTLE_SHUFFLE_RESP_ID), p.Table.ShuffleInfo)
		// fmt.Println("-----------shuffle-------------")
		// p.Table.Board.Print()
		// fmt.Println("-----------send msg-------------")

		// for _, v := range p.Table.ShuffleInfo.Coors {
		// 	fmt.Printf("src->{%v:%v} dst ->{%v:%v}\n", v.Src.X, v.Src.Y, v.Dst.X, v.Dst.Y)
		// }
	}
}

//增加英雄能量
func (p *Player) AddHeroEnergy(color int32) {
	for _, v := range p.Hero {
		if v.IsInColor(color) && v.CurEnergy < v.GetMaxEnergy() {
			v.CurEnergy++
		}
	}
}

//英雄能量记录
func (p *Player) RecordHeroEnergy(count int32) {
	for _, v := range p.Hero {
		p.HeroResultInfo.AddEnergyResult(count, NewEnergyResultInfo(v.UserID, v.Pos, v.CurEnergy))
	}
}

//使用主动技能
func (p *Player) HeroUseSkill(data interface{}) {
	req := data.(kproto.BATTLE_USE_SKILL_REQ)
	h := p.Hero[req.Pos]

	//能量不足
	if h == nil || h.CurEnergy < h.GetMaxEnergy() || h.State == cmongo.DEATH {
		if p.Session != nil {
			p.Session.AllocateContext().MustSetResponse(uint32(kproto.MSG_BATTLE_USE_SKILL_RESP_ID), &kproto.BATTLE_USE_SKILL_RESP{Code: -1}).Send()
		}
		return
	}

	//更新能量
	h.CurEnergy = 0
	//主动技能释放
	ret := battle.HeroEffect(h, h.USkill, p.GetHeroesSlice(), p.Table.GetExceptPlayer(p.ID).GetHeroesSlice())
	//设置时间
	cfg := game_config.SkillConfigInstant.GetInfo(h.USkill)
	p.SetActionTime(int64(cfg.SkillTotalTime) * int64(time.Millisecond))
	//发送
	p.Table.Boardcast(uint32(kproto.MSG_BATTLE_USE_SKILL_RESP_ID), &kproto.BATTLE_USE_SKILL_RESP{Atts: ret, Energy: h.CurEnergy, HeroIdx: h.ID})

	// logrus.WithField("SEND", "SKILL").Infof("SEND SKILL %v - %v - %v", h.HeroConfig.HeroId, h.USkill, time.Now().UnixMilli())
}

//英雄普攻
func (p *Player) HeroAttack(count, color int32) {
	for _, pos := range HeroPos {
		h := p.Hero[pos]

		if h == nil || h.State == cmongo.DEATH || !h.IsInColor(color) {
			continue
		}
		//一次攻击
		ret := battle.HeroEffect(h, h.NSkill, p.GetHeroesSlice(), p.Table.GetExceptPlayer(p.ID).GetHeroesSlice())
		//设置时间
		cfg := game_config.SkillConfigInstant.GetInfo(h.NSkill)
		p.SetActionTime(int64(cfg.SkillTotalTime) * int64(time.Millisecond))
		//记录
		p.HeroResultInfo.AddNskillResult(count, ret)
	}
}

func (p *Player) GetHeroesSlice() []*battle.BattleHero {
	var ret []*battle.BattleHero
	for k := range p.Hero {
		if p.Hero[k].State == cmongo.DEATH {
			continue
		}

		ret = append(ret, p.Hero[k])
	}
	return ret
}
