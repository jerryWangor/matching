package khttp

import (
	"c4_center/ktcp"
	"fmt"
	"io/ioutil"
	"net/http"

	"github.com/sirupsen/logrus"
)

type Context interface {
	Request() *http.Request
	ResponseWriter() http.ResponseWriter
	SetRequest(request *http.Request)
	SetResponseWriter(writer http.ResponseWriter)
	SetCode(codec ktcp.Codec)
	Bind(v interface{}) error
	Send(v interface{})
}

type routeContext struct {
	codec ktcp.Codec
	w     http.ResponseWriter
	r     *http.Request
}

func (rc *routeContext) Request() *http.Request {
	return rc.r
}

func (rc *routeContext) ResponseWriter() http.ResponseWriter {
	return rc.w
}

func (rc *routeContext) SetRequest(request *http.Request) {
	rc.r = request
}

func (rc *routeContext) SetResponseWriter(writer http.ResponseWriter) {
	rc.w = writer
}

func (rc *routeContext) SetCode(codec ktcp.Codec) {
	rc.codec = codec
}

func (rc *routeContext) Bind(v interface{}) error {
	data, err := ioutil.ReadAll(rc.r.Body)
	if err != nil {
		return fmt.Errorf("read data err: %s", err)

	}

	return rc.codec.Decode(data, v)
}

func (rc *routeContext) Send(v interface{}) {
	data, err := rc.codec.Encode(v)
	if err != nil {
		logrus.Error(err)
		return
	}

	rc.w.Write(data)
}
