package match_registry

import (
	"c4_center/container/credis"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/registry"
	"c4_center/registry/discovery"
	"c4_center/registry/etcd"
	"context"
	"encoding/json"
	"fmt"
	"math/rand"
	"time"

	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

var (
	ROOM_SERVICE string = "room-grpc"
	GATE_SERVICE string = "gate-grpc"
	EtcdClient   *RoomManagerRegistry
)

type RoomManagerRegistry struct {
	ctx       context.Context
	client    *etcd.Registry
	discovery *discovery.Discovery
}

func InitLoginRegistry(config clientv3.Config, opts ...etcd.Option) {
	cli, err := clientv3.New(config)
	if err != nil {
		logrus.Fatal(err)
	}

	EtcdClient = &RoomManagerRegistry{ctx: context.TODO(), client: etcd.New(cli, opts...), discovery: discovery.NewDiscovery()}
}

func (g *RoomManagerRegistry) Register(service *registry.ServiceInstance) error {
	return g.client.Register(g.ctx, service)
}

func (g *RoomManagerRegistry) Deregister(service *registry.ServiceInstance) error {
	return g.client.Deregister(g.ctx, service)
}

// name or name/id
func (g *RoomManagerRegistry) getService(name string) (*registry.ServiceInstance, error) {
	infos, err := g.client.GetService(g.ctx, name)
	if err != nil {
		return nil, err
	}

	if len(infos) <= 0 {
		return nil, fmt.Errorf("service of %s : is empty", name)
	}

	return infos[rand.Intn(len(infos))], nil
}

func (g *RoomManagerRegistry) GetServiceInDiscovery(name string) (*registry.ServiceInstance, error) {
	node := g.discovery.PickNode(name)
	if node == nil {
		logrus.Errorf("cannot get service ->  %v", name)
		return g.getService(name)
	}
	return node, nil
}

// func (g *RoomManagerRegistry) GetSpecServiceInDiscovery(name string, id string) (*registry.ServiceInstance, error) {
// 	node := g.discovery.GetSpecNode(name, id)
// 	if node == nil {
// 		return nil, fmt.Errorf("cannot get service ->  %v", name)
// 	}

// 	return node, nil
// }

func (g *RoomManagerRegistry) Watch(name string) {
	w, err := g.client.Watch(g.ctx, name)
	if err != nil {
		logrus.Fatal(err)
		return
	}

	//init
	res, err := w.Next()
	if err != nil {
		logrus.Fatal(err)
		return
	}

	g.discovery.RefreshNode(name, res...)

	//loop watch
	go func() {
		for {
			res, err := w.Next()
			if err != nil {
				logrus.Error(err)
				return
			}

			g.discovery.RefreshNode(name, res...)
		}
	}()
}
func RpcSendToGate(userid string, val *kproto.Packet) {
	sessStr, err := kredis.GetStr(context.Background(), userid)
	if err != nil {
		logrus.Infof("do not have session of userid : %s;", userid)
		return
	}

	var sessData credis.SessionInfo
	if json.Unmarshal([]byte(sessStr), &sessData) != nil {
		logrus.Infof("session unmarshal err of userid : %s;", userid)
		return
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), sessData.GateGrpcAddress, grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Infof("grpc error that invoke gate: %v;", err)
		return
	}

	defer conn.Close()

	client := kproto.NewGateServiceClient(conn)
	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	resp, err := client.SendToClient(ctx, &kproto.SendReq{UserId: userid, Packet: val})
	if err != nil {
		logrus.Infof("send to gate error: %v;", err)
		return
	}

	logrus.Info(resp)

	// //gate rpc
	// conn, err := grpc.Dial(sessData.GateGrpcAddress, grpc.WithTransportCredentials(insecure.NewCredentials()))
	// if err != nil {
	// 	logrus.Infof("grpc error that invoke gate: %v;", err)
	// 	return
	// }

	// if _, err := kproto.NewGateServiceClient(conn).SendToClient(context.Background(), &kproto.SendReq{UserId: userid, Packet: val}); err != nil {
	// 	logrus.Infof("send to gate error: %v;", err)
	// 	return
	// }
}
