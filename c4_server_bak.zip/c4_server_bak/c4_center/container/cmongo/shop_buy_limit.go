package cmongo

// 用户道具信息
type ShopBuyLimit struct {
	ID       string `bson:"_id"`       // idx
	UserID   string `bson:"user_id"`   // 所属玩家ID
	ShopId   int32  `bson:"shop_id"`   // 商店ID
	ItemId   int32  `bson:"item_id"`   // 商品序列ID
	BuyNum   int32  `bson:"buy_num"`   // 已购买数量
	LimitNum int32  `bson:"limit_num"` // 限购数量
}
