package http

import (
	"c4_center/khttp"
	"encoding/json"
	"github.com/sirupsen/logrus"
)

// 接收到的数据格式: pass=xxxxx&message={定好的json数据}
// 使用key加密规则: key=md5(KEY+message)
const KEY = "153dc7b62ec637173a4f3f288e252e6c"

type JsonResp struct {
	Code    int32
	Message string
	Data    interface{}
}

func NotFound(ctx khttp.Context) {
	logrus.Errorf("cant find router for url: %s", ctx.Request().URL)
}

func ReturnJson(ctx khttp.Context, code int32, message string, data interface{}) {
	jdata := JsonResp{Code: code, Message: message, Data: data}
	jsondata, _ := json.Marshal(jdata)
	ctx.ResponseWriter().Write(jsondata)
}
