package room

import (
	"c4_center/kproto"
	"c4_room/internal/match3"
)

//一次消除结果
type ResultInfo struct {
	//不能使用指针,需要拷贝数据记录
	ClearPieces []match3.Piece //消除的棋子
	NewPieces   []match3.Piece //新生成的棋子
	IsAddAction bool           //是否增加操作次数
}

func NewResultInfo() *ResultInfo {
	return &ResultInfo{}
}

func (r *ResultInfo) SetClearPiece(p match3.Piece) {
	r.ClearPieces = append(r.ClearPieces, p)
}
func (r *ResultInfo) SetClearPieces(p []match3.Piece) {
	r.ClearPieces = append(r.ClearPieces, p...)
}

func (r *ResultInfo) SetNewPiece(p match3.Piece) {
	r.NewPieces = append(r.NewPieces, p)
}

func (r *ResultInfo) SetNewPieces(p []match3.Piece) {
	r.NewPieces = append(r.NewPieces, p...)
}

func (r *ResultInfo) OutClearData() []*kproto.BallCoordinate {
	var ret []*kproto.BallCoordinate
	for _, v := range r.ClearPieces {
		ret = append(ret, &kproto.BallCoordinate{X: v.PosX, Y: v.PosY})
	}
	return ret
}

func (r *ResultInfo) SetIsAddAction(val bool) {
	r.IsAddAction = val
}

func (r *ResultInfo) OutNewPieceData() []*kproto.BallsCreations {
	var creations []*kproto.BallsCreations

	for _, v := range r.NewPieces {
		isContainer := false
		for ii, vv := range creations {
			if vv.BallsLineIndex == v.PosY {
				creations[ii].BallsTypes = append(creations[ii].BallsTypes, v.PType)
				isContainer = true
			}
		}
		if !isContainer {
			creations = append(creations, &kproto.BallsCreations{BallsLineIndex: v.PosY, BallsTypes: []int32{v.PType}})
		}
	}
	return creations
}

//英雄结果记录
type HeroResultInfo struct {
	NskillResult map[int32][]*kproto.HeroAtt   //普攻记数 {key=count 棋盘一次操作记数器}
	EnergyResult map[int32][]*EnergyResultInfo //一次下落后英雄能量记录
}

func NewHeroResultInfo() *HeroResultInfo {
	return &HeroResultInfo{NskillResult: make(map[int32][]*kproto.HeroAtt), EnergyResult: make(map[int32][]*EnergyResultInfo)}
}

func (h *HeroResultInfo) AddEnergyResult(count int32, val *EnergyResultInfo) {
	h.EnergyResult[count] = append(h.EnergyResult[count], val)
}

func (h *HeroResultInfo) OutEnergyResult(count int32) []*kproto.HeroEnergy {
	var ret []*kproto.HeroEnergy

	for _, v := range h.EnergyResult[count] {
		ret = append(ret, &kproto.HeroEnergy{UserId: v.UserId, Pos: v.Pos, Energy: v.Energy})
	}
	return ret
}

func (h *HeroResultInfo) AddNskillResult(count int32, val *kproto.HeroAtt) {
	h.NskillResult[count] = append(h.NskillResult[count], val)
}

func (h *HeroResultInfo) Clear() {
	for k := range h.EnergyResult {
		delete(h.EnergyResult, k)
	}

	for k := range h.NskillResult {
		delete(h.NskillResult, k)
	}
}

type EnergyResultInfo struct {
	Pos    int32
	Energy int32
	UserId string
}

func NewEnergyResultInfo(userid string, pos, energy int32) *EnergyResultInfo {
	return &EnergyResultInfo{UserId: userid, Pos: pos, Energy: energy}
}

type GameResultInfo struct {
	Winner     string
	State      int32 //结束类型 1.正常 2.掉线
	ResultType int32 //结束类型 0.正常 1.投降
}
