package main

import (
	"bytes"
	"c4_center/klog"
	"c4_center/kmongo"
	"c4_center/kmysql"
	"c4_center/kproto"
	"c4_log/config"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/protobuf/proto"
	"io/ioutil"
	"net/http"
	"reflect"
	"testing"
)

func TestLoginLog(t *testing.T) {
	//初始化配置
	config.Init("app.ini")
	//初始化logs
	klog.InitLog(config.LogsConfigInstant.Path, config.LogsConfigInstant.Level)
	//初始化mongo
	kmongo.Init(config.MongoConfigInstant.Mongo_DB, options.Client().ApplyURI(config.MongoConfigInstant.Mongo_addr))
	//初始化mysql
	kmysql.Init(config.MysqlConfigInstant.Mysql_addr)
	//初始化日志配置
	config.InitLogConfig()

	// 动态生成结构体
	//typ := reflect.StructOf([]reflect.StructField{
	//	{
	//		Name: "Id",
	//		Type: reflect.TypeOf(int(0)),
	//		//Tag:  `gorm:"primaryKey" json:"id"`,
	//	},
	//	{
	//		Name: "Accid",
	//		Type: reflect.TypeOf("0"),
	//		//Tag:  `gorm:"" json:"accid"`,
	//	},
	//	{
	//		Name: "PointId",
	//		Type: reflect.TypeOf(int(0)),
	//		//Tag:  `gorm:"" json:"pointid"`,
	//	},
	//	{
	//		Name: "DateTime",
	//		Type: reflect.TypeOf(int(0)),
	//		//Tag:  `gorm:"" json:"datetime"`,
	//	},
	//})

	typ := reflect.StructOf([]reflect.StructField{
		{
			Name: "Accid",
			Type: reflect.TypeOf("0"),
			Tag:  `gorm:"primaryKey" json:"accid"`,
		},
		{
			Name: "Coin",
			Type: reflect.TypeOf(int(0)),
			//Tag:  `gorm:"" json:"pointid"`,
		},
		{
			Name: "LastLoginTime",
			Type: reflect.TypeOf(int(0)),
			//Tag:  `gorm:"" json:"datetime"`,
		},
	})

	//生成对象
	v := reflect.New(typ).Elem()

	//设置对象数据
	//v.FieldByName("Id").Set(reflect.ValueOf(11))
	v.FieldByName("Accid").SetString("dsdaa")
	v.FieldByName("Coin").SetInt(1002)
	v.FieldByName("LastLoginTime").SetInt(100293817)
	//v.FieldByName("UserId").SetInt(100293817)

	//#event_name=xxx&Id=xxx&Accid=111&DataTime=xxx

	kmysql.InsertUpdate("log_player", v.Addr().Interface())
}

func TestSaveLoginLog(t *testing.T) {
	b, _ := proto.Marshal(&kproto.LOG_CLIENT_REQ{Userid: "aaaaaaaa", Data: "event_name=log_points&id=0&accid=asdfqwe&login_time=1000235545"})
	req, err := http.NewRequest("POST", "http://127.0.0.1:11001/log_client", bytes.NewBuffer(b))
	if err != nil {
		t.Fatal(err)
	}

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}

	body, _ := ioutil.ReadAll(resp.Body)

	m := &kproto.LOG_CLIENT_RESP{}
	proto.Unmarshal(body, m)

	t.Log(m)
}
