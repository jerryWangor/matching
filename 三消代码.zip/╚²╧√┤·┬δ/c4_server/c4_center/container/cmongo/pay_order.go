package cmongo

const ORDER_ID_LENGTH = 24

// 充值订单表
type PayOrder struct {
	ID           string `bson:"_id"`           // idx
	UserID       string `bson:"user_id"`       // 所属玩家ID
	Token        string `bson:"token"`         // 钱包地址
	OrderId      string `bson:"order_id"`      // 订单号
	HashData     string `bson:"hash_data"`     // 区块链交易hash
	Result       int32  `bson:"result"`        // 0 失败 1 成功
	ResultInfo   string `bson:"result_info"`   // 链上返回的信息
	ItemId       int32  `bson:"item_id"`       // 获得道具ID
	ItemNum      int64  `bson:"item_num"`      // 获得道具数量
	CurrencyType string `bson:"currency_type"` // 原始货币类型（BNB BSC ...）
	CurrencyNum  int64  `bson:"currency_num"`  // 原始货币数量（万分之一）
	IsSupple     int32  `bson:"is_supple"`     // 是否补单：0 不是 1 是
	PayTime      int64  `bson:"pay_time"`      // 充值时间
	DateTime     int64  `bson:"date_time"`     // 写入时间
}
