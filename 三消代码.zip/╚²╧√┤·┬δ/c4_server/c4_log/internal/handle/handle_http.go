package handle

import (
	"c4_center/khttp"
	"c4_center/klog"
	"c4_center/kproto"
	"github.com/sirupsen/logrus"
	"strings"
)

// 预留的客户端打点日志请求(Http)
func LogClientHandler(ctx khttp.Context) {
	var reqData kproto.LOG_CLIENT_REQ
	if ctx.Bind(&reqData) != nil {
		logrus.Error("packet error")
		ctx.Send(&kproto.LOG_CLIENT_RESP{Code: -1})
		return
	}

	// data的格式是：event_name=xxx&Accid=abvc&PointId=1001DateTime=12541254
	params := strings.Split(reqData.Data, "&")
	mname := ""
	m := make(map[string]interface{})
	for _, v := range params {
		cparam := strings.Split(v, "=")
		if len(cparam) < 2 {
			logrus.Error("data error")
			ctx.Send(&kproto.LOG_CLIENT_RESP{Code: -2})
			return
		}
		if cparam[0] == "event_name" {
			mname = cparam[1]
		} else {
			// 放入map
			m[cparam[0]] = cparam[1]
		}
	}

	logdata := &klog.LogData{
		Type:      klog.LogTypeInsert,
		ModelName: mname,
		Data:      m,
	}

	LogInsertDataChan <- logdata

	// 这里还可以直接写入数据库
	// xxxxx

	ctx.Send(&kproto.LOG_CLIENT_RESP{Code: 0})
}
