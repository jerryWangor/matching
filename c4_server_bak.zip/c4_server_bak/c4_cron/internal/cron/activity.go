package cron

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/utils"
	"github.com/robfig/cron/v3"
	"github.com/sirupsen/logrus"
	"sync"
)

type Activity struct {
	Type    int32
	EntryID cron.EntryID
	Cron    *cron.Cron
	Config  *game_config.ActivityData
	Once    sync.Once
}

func (a *Activity) Init() {
	logrus.Infof("活动初始化！-> %v", a.Type)
	a.Config = game_config.ActivityConfigInstant.GetInfo(a.Type)
}

func (a *Activity) Run() {
	logrus.Infof("活动检查中！-> %v", a.Type)
	sTime := utils.DateTimeToTimestamp(cmongo.DATETIME_FORMAT, a.Config.StartTime)
	eTime := utils.DateTimeToTimestamp(cmongo.DATETIME_FORMAT, a.Config.EndTime)
	nTime := utils.GetNowTime()

	// 未开启
	if sTime > nTime {
		logrus.Infof("活动未开启！-> %v", a.Type)
		return
	}

	// 已结束
	if eTime <= nTime {
		a.End()
		return
	}
	// 十秒之内，算开启
	if sTime >= (nTime - 10) {
		a.Begin()
		return
	}
	//if sTime >= nTime {
	//	a.Once.Do(a.Begin)
	//	return
	//}

	// 其他情况直接reset，包括中途重启
	a.Reset()
}

func (a *Activity) Begin() {
	logrus.Infof("活动开启！-> %v", a.Type)
	SendActivityState(a.Type, 1)
}

func (a *Activity) End() {
	logrus.Infof("活动结束！-> %v", a.Type)
	delete(AllCronData.ActivityEntryIds, a.Type)
	a.Cron.Remove(a.EntryID)
	SendActivityState(a.Type, 0)
}

// 活动重置
func (a *Activity) Reset() {
	logrus.Infof("重置活动奖励状态!-> %v", a.Type)
	// 给网关发送消息
	SendActivityState(a.Type, 2)
}

func (a *Activity) Change() {

}
