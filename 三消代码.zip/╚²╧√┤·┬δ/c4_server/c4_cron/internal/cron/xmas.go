package cron

import (
	"c4_cron/internal/service"

	"github.com/robfig/cron/v3"
	"github.com/sirupsen/logrus"
)

type Xmas struct {
	Id      int32
	EntryID cron.EntryID
	Cron    *cron.Cron
}

func (s *Xmas) Init() {
	logrus.Infof("圣诞活动初始化！-> %v", s.Id)
}

func (s *Xmas) Run() {
	logrus.Infof("圣诞活动刷新！-> %v", s.Id)
	s.Reset()
}

func (s *Xmas) Begin() {
	logrus.Infof("圣诞活动开启！-> %v", s.Id)
}

func (s *Xmas) End() {
	logrus.Infof("圣诞活动关闭！-> %v", s.Id)
	delete(AllCronData.RankEntryIds, s.Id)
	s.Cron.Remove(s.EntryID)
}

func (s *Xmas) Reset() {
	service.DeleteLimitHeroXmas()
}

func (s *Xmas) Change() {

}
