package game_config

type ItemData struct {
	ID                     int32    `tb_name:"模板ID"`
	Name                   int32    `tb_name:"道具名称"`
	Desc                   int32    `tb_name:"道具说明"`
	Quality                int32    `tb_name:"道具品质"`
	MainType               int32    `tb_name:"所属大类"`
	SubType                int32    `tb_name:"所属小类"`
	IsCanUsed              int32    `tb_name:"是否可使用"`
	AutoUse                int32    `tb_name:"是否自动使用"`
	IsConsum               int32    `tb_name:"使用后是否消耗"`
	LockTime               int32    `tb_name:"解锁时间"`
	DropId                 int32    `tb_name:"掉落ID"`
	ImprintId              int32    `tb_name:"印记ID"`
	Only                   int32    `tb_name:"是否唯一"`
	StackingLimit          int32    `tb_name:"堆叠上限"`
	Order                  int32    `tb_name:"道具排序"`
	Icon                   string   `tb_name:"道具图标"`
	ChestRewardShow        []string `tb_name:"宝箱奖励内容"`
	IsAutoUse              int32    `tb_name:"是否自动使用"`
	UnlockConsume_Diamonds string   `tb_name:"钻石直接打开消耗"`
	UnlockConsume_Keys     string   `tb_name:"钥匙直接打开消耗"`
}

var ItemConfigInstant *ItemConfig

type ItemConfig struct {
	ItemData []*ItemData
	Infos    map[int32]*ItemData //key == Id
}

func InitItemConfig(path string) {
	ItemConfigInstant = &ItemConfig{Infos: make(map[int32]*ItemData)}
	//加载
	LoadJsonFile(path+"/ItemData.json", ItemConfigInstant)
	//初始化
	ItemConfigInstant.InitIndex()
}

func (h *ItemConfig) InitIndex() {
	for i, _ := range h.ItemData {
		h.Infos[h.ItemData[i].ID] = h.ItemData[i]
	}
}

func (h *ItemConfig) GetInfo(tid int32) *ItemData {
	data, ok := h.Infos[tid]
	if !ok {
		return nil
	}
	return data
}
