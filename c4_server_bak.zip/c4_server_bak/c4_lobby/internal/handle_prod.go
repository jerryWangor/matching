package internal

import (
	"c4_center/cinternal"
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/utils"
	"c4_lobby/internal/item"
	"c4_lobby/internal/sign"
	"context"
	"fmt"
	"strconv"
	"time"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
)

//ball is contained in heroes
func ContainHeroBall(userid string, balls *APIBall, hs []*cmongo.Hero) bool {
	for _, v := range hs {
		if v.BallId == balls.Ballid {
			//设置状态为normal
			if v.State == cmongo.DELETE {
				kmongo.UpdateOne(context.TODO(), kmongo.HeroCollection, bson.M{"_id": v.ID}, bson.M{"$set": bson.M{"state": cmongo.NORMAL, "pos": 0}})
			}

			return true
		}
	}

	//hero has existed but info is wrong that another user has
	var hero cmongo.Hero
	kmongo.GetOne(context.TODO(), kmongo.HeroCollection, bson.M{"ball_id": balls.Ballid}, &hero)
	if len(hero.ID) > 0 {
		kmongo.UpdateOne(context.TODO(), kmongo.HeroCollection, bson.M{"_id": hero.ID}, bson.M{"$set": bson.M{"state": cmongo.NORMAL, "pos": 0, "user_id": userid}})
		return true
	}

	return false
}

//hero is not contained in balls
func NotContainHeroBall(h *cmongo.Hero, balls []*APIBall) {
	//ballid == 0 为本地生成英雄
	if h.BallId <= 0 {
		return
	}

	isContain := false
	for _, v := range balls {
		if v.Ballid == h.BallId {
			isContain = true
			break
		}
	}

	if !isContain {
		kmongo.UpdateOne(context.TODO(), kmongo.HeroCollection, bson.M{"_id": h.ID}, bson.M{"$set": bson.M{"state": cmongo.DELETE, "pos": 0}})
	}
}

//api 水晶人处理
func BallsProcess(userid, address string) {
	if len(address) <= 0 {
		return
	}

	//get heroes
	hs := cinternal.LoadHeroByUserId(userid)
	//get balls
	balls, err := GetBalls(address)
	if err != nil {
		logrus.Error(err)
		return
	}

	//水晶人是否在本地英雄列表中
	for k, v := range balls {
		// !contain -> change state to NORMAL & insert
		if !ContainHeroBall(userid, balls[k], hs) {

			cinternal.InsertHero(cinternal.GetInitHero(userid, v.Gene, v.Mutatedgene, v.Ballid, 0, 1))
		}
	}

	//本地英雄不在水晶人列表中 -> change state to DELETE
	for k := range hs {
		NotContainHeroBall(hs[k], balls)
	}
}

//get heroes
func GetHeroes(req *kproto.SendReq) (*kproto.SendResp, error) {
	var account cmongo.Account
	kmongo.GetOne(context.TODO(), kmongo.AccountCollection, &account, bson.M{"user_id": req.UserId})

	//api balls
	BallsProcess(req.UserId, account.Token)

	//get heroes
	hs := cinternal.LoadHeroByUserId(req.UserId)

	//all heroes info
	info := &kproto.LOBBY_HERO_RESP{}
	for _, v := range hs {
		if v.State == cmongo.DELETE {
			continue
		}

		info.Heroes = append(info.Heroes, cinternal.HeroData(v))
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_HERO_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//set hero pos
func SetHeroPos(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_HERO_POS_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	//将pos!=0的heroes 更新pos=0 state=0
	if !kmongo.UpdateMany(context.TODO(), kmongo.HeroCollection, bson.M{"user_id": req.UserId, "pos": bson.M{"$ne": 0}}, bson.M{"$set": bson.M{"pos": 0, "state": cmongo.NORMAL}}) {
		return nil, fmt.Errorf("update heroes pos error : -> userid : %v", req.UserId)
	}

	var code int32
	//其中一个不成功code = -1
	for _, v := range reqData.Pos {
		//位置判断
		if v.Pos < 1 || v.Pos > 6 {
			code = -1
			logrus.Infof("idx -> %v , pos -> %v is illegal", v.Idx, v.Pos)
			continue
		}

		//判断上阵英雄是否相同
		if IsContainerHeroGenDress(v.Idx) {
			code = -1
			logrus.Infof("idx gene -> %v is duplicate", v.Idx)
			continue
		}

		//更新位置
		if !kmongo.UpdateOne(context.TODO(), kmongo.HeroCollection, bson.M{"_id": v.Idx}, bson.M{"$set": bson.M{"pos": v.Pos, "state": cmongo.ATTACK}}) {
			code = -1
			logrus.Infof("idx -> %v not exist", v.Idx)
			continue
		}
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_HERO_POS_RESP_ID), &kproto.LOBBY_HERO_POS_RESP{Code: code})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//判断上阵英雄是否为相同英雄
func IsContainerHeroGenDress(idx string) bool {
	var h cmongo.Hero
	kmongo.GetOne(context.TODO(), kmongo.HeroCollection, &h, bson.M{"_id": idx})

	//数据
	var hs []*cmongo.Hero
	kmongo.Get(context.TODO(), kmongo.HeroCollection, &hs, bson.M{"user_id": h.UserID, "state": cmongo.ATTACK})
	if len(hs) <= 0 {
		return false
	}

	for _, v := range hs {
		if v.Gene[0] == h.Gene[0] {
			return true
		}
	}

	return false
}

//hero level up
func HeroLevelUp(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_HERO_LEVEL_UP_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	//查询英雄信息

	hs := cinternal.LoadHeroByIdx(reqData.Id)
	//英雄升级配置
	hsConf := game_config.HeroLevelUpConfigInstant.GetInfo(hs.ChessColor, hs.Level)
	if hsConf == nil {
		return nil, fmt.Errorf("hero config not found or hero is max level : -> userid : %v", req.UserId)
	}
	//判断是否最大等级
	maxLevel := game_config.HeroLevelUpConfigInstant.GetHeroMaxLevel(hs.ChessColor)
	if maxLevel == 0 || hs.Level >= maxLevel {
		return nil, fmt.Errorf("hero is max level : -> userid : %v", req.UserId)
	}

	needItems := make(map[int32]int64) //需要的道具数量
	affectIds := make([]int32, 0)      //受影响的道具ID
	consumeResp := make([]*kproto.ConsumeItemInfo, 0)
	//判断升级材料够不够
	for _, v := range hsConf.UpgradeConsume {

		if tid, num, err := utils.ParseItem(v); err == nil {
			needItems[tid] = num
			affectIds = append(affectIds, tid)
		}

	}

	//查询受影响得道具，判断数量
	items := item.LoadItemByUserTypeIds(req.UserId, affectIds)
	if items == nil {
		return nil, fmt.Errorf("consume mat not enough : -> userid : %v", req.UserId)
	}

	var flag bool
	for tid, num := range needItems {
		flag = false
		for _, v := range items {
			if v.TypeId == tid && v.Num >= num {
				flag = true
				break
			}
		}
		if !flag {
			return nil, fmt.Errorf("consume mat not enough : -> userid : %v", req.UserId)
		}
	}

	//通过校验，进行升级
	for _, v := range items {
		//更新道具信息
		consumeResp = append(consumeResp, &kproto.ConsumeItemInfo{Id: v.ID, Num: needItems[v.TypeId], TypeId: v.TypeId})

		err := item.ConsumeItemByIdx(req.UserId, v.ID, v.Num, needItems[v.TypeId])
		if err != nil {
			return nil, err
		}
	}

	//更新hero信息
	hs.Level++

	err := cinternal.ReplaceHero(hs)
	if err != nil {
		return nil, err
	}

	//encode
	info := &kproto.LOBBY_HERO_LEVEL_UP_RESP{}
	info.HeroId = hs.ID
	info.Level = hs.Level
	info.Consumes = consumeResp
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_HERO_LEVEL_UP_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//enter lobby
func GetEnterLobby(req *kproto.SendReq) (*kproto.SendResp, error) {

	info := &kproto.GATE_ENTER_LOBBY_RESP{}
	//encode
	packet, err := getPacket(uint32(kproto.MSG_GATE_ENTER_LOBBY_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//get activity
func GetActivity(req *kproto.SendReq) (*kproto.SendResp, error) {

	info := &kproto.LOBBY_ACTIVITY_RESP{}

	signData, err := getActivitySign(req)
	if err != nil {
		return nil, err
	}
	info.Data = append(info.Data, signData)
	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_ACTIVITY_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//get activity
func GetActivityAssign(req *kproto.SendReq) (*kproto.SendResp, error) {

	var reqData kproto.LOBBY_ACTIVITY_ASSIGN_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	info := &kproto.LOBBY_ACTIVITY_ASSIGN_RESP{}
	switch reqData.Type {
	case game_config.ActivityType_Sign:
		signData, err := getActivitySign(req)
		if err != nil {
			return nil, err
		}
		info.Data = signData
	default:

	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_ACTIVITY_ASSIGN_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 签到活动
func getActivitySign(req *kproto.SendReq) (*kproto.ACTIVITY_DATA, error) {

	signActData := &kproto.ACTIVITY_DATA{}
	// 查询签到状态和数据，先判断活动时间
	conf := game_config.ActivityConfigInstant.GetInfo(game_config.ActivityType_Sign)
	signSTime := utils.DateTimeToTimestamp(cmongo.DATETIME_FORMAT, conf.StartTime)
	signETime := utils.DateTimeToTimestamp(cmongo.DATETIME_FORMAT, conf.EndTime)
	nowTime := time.Now().Unix()
	if signSTime <= nowTime && nowTime <= signETime {
		days, err := utils.GetDaysBetween2Date(cmongo.DATETIME_FORMAT, conf.StartTime, time.Now().Format(cmongo.DATETIME_FORMAT))
		if err != nil {
			return nil, fmt.Errorf("time error : -> userid : %v", req.UserId)
		}
		signActData.Type = game_config.ActivityType_Sign
		signData := sign.LoadMonthSignByUserId(req.UserId, cmongo.TYPE_SIGN_ACTIVITY, signSTime)
		totalNum := int64(len(game_config.SignRewardConfigInstant.Infos)) // 总天数
		var key string
		// 不能超出最大天数
		if days >= totalNum {
			key = strconv.FormatInt(days-1, 10)
		} else {
			key = strconv.FormatInt(days, 10)
		}
		if signData != nil {
			// 查询玩家签到数据
			signActData.Data = append(signActData.Data, &kproto.ACTIVITY_VALUE_DATA{Key: key, Value: strconv.FormatInt(signData.Data, 10)})
			if utils.HasFlag(signData.Data, 1<<days) {
				signActData.State = 1
			}
		} else {
			signActData.Data = append(signActData.Data, &kproto.ACTIVITY_VALUE_DATA{Key: key, Value: "0"})
		}
	}
	return signActData, nil
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
