package cron

import (
	"c4_center/game_config"
	"c4_center/utils"
	"fmt"

	"github.com/robfig/cron/v3"
	"github.com/sirupsen/logrus"
)

type cronData struct {
	Cron             *cron.Cron
	ActivityEntryIds map[int32]ICron // 通过这个去热加载活动，开启，关闭，调整
	ShopEntryIds     map[int32]ICron
	RankEntryIds     map[int32]ICron
	Close            chan struct{}
}

var AllCronData *cronData

// 开启定时器
func OpenCron() {
	defer utils.HandleCrash()

	cron := cron.New(cron.WithSeconds())
	AllCronData = &cronData{
		Cron:             cron,
		ActivityEntryIds: make(map[int32]ICron),
		ShopEntryIds:     make(map[int32]ICron),
		RankEntryIds:     make(map[int32]ICron),
		Close:            make(chan struct{}),
	}

	// 开启活动定时器
	OpenActivity(cron)

	// 开启商店定时器
	OpenShop(cron)

	//圣诞活动
	OpenXmas(cron)

	// 定时心跳， 防止改时间失效
	cron.AddFunc("*/30 * * * * *", PrintTime)

	//启动计划任务
	cron.Start()

	//关闭计划任务, 但是不能关闭已经在执行中的任务.
	defer cron.Stop()

	select {
	case <-AllCronData.Close:
		// 关闭定时器
		logrus.Info("关闭定时器")
		return
	}
}

// 活动相关
func OpenActivity(cron *cron.Cron) {
	for k, v := range game_config.ActivityConfigInstant.Infos {
		if len(v.FreshTime) <= 0 {
			continue
		}
		activity := &Activity{Type: k, Cron: cron}
		entryId, err := cron.AddJob(v.FreshTime, activity)
		if err != nil {
			logrus.Errorf(fmt.Sprintf("activity open error -> %v", err))
			continue
		}
		activity.Init()
		activity.EntryID = entryId
		AllCronData.ActivityEntryIds[k] = activity
	}
}

// 商店相关
func OpenShop(cron *cron.Cron) {
	for k, v := range game_config.ShopTypeConfigInstant.Infos {
		if len(v.Refresh_Time) <= 0 {
			continue
		}
		shop := &Shop{Id: k, Cron: cron}
		entryId, err := cron.AddJob(v.Refresh_Time, shop)
		if err != nil {
			logrus.Errorf(fmt.Sprintf("shop open error -> %v", err))
			continue
		}
		shop.Init()
		shop.EntryID = entryId
		AllCronData.ShopEntryIds[k] = shop
	}
}

func OpenXmas(cron *cron.Cron) {
	xmas := &Xmas{Id: 1002, Cron: cron}
	entryId, err := cron.AddJob("0 0 0  * * *", xmas)
	if err != nil {
		logrus.Errorf(fmt.Sprintf("xmas open error -> %v", err))
		return
	}
	xmas.Init()
	xmas.EntryID = entryId
	AllCronData.RankEntryIds[1002] = xmas
}

func PrintTime() {
	logrus.Infof(utils.GetNowTimeString())
}

func Close() {
	AllCronData.Close <- struct{}{}
}
