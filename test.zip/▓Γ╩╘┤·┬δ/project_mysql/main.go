//package main
//
//import (
//	"fmt"
//	"github.com/jinzhu/gorm"
//	_ "github.com/jinzhu/gorm/dialects/mysql"
//)
//
//var Db *gorm.DB
//var err error
//
//type User struct {
//	Id   int    `gorm:"primary_key"`
//	Name string `gorm:"unique_key"`
//	Age  int    `gorm:"not_null"`
//}
//
//func main() {
//
//	//go func() {
//	//	time.Sleep(2 * time.Second)
//	//
//	//	fmt.Println("sadas")
//	//}()
//	//
//	//fmt.Println("dsadasdas")
//	//time.Sleep(5 * time.Second)
//	//return
//
//	dns := "root:warjary0416@tcp(127.0.0.1:3306)/c4_logs?charset=utf8mb4&parseTime=true"
//	db, err := gorm.Open("mysql", dns)
//	if err != nil {
//		fmt.Println(err)
//	}
//	db.DB().SetMaxIdleConns(10)
//	db.DB().SetMaxOpenConns(100)
//	db.SingularTable(true)
//
//	Db = db
//	fmt.Println("database connect success")
//
//	defer func() {
//		if err := recover(); err != nil {
//			fmt.Println(err)
//		}
//	}()
//
//	user := &User{Name: "jerry", Age: 18}
//	InsertOne("user", user)
//
//	//Delete("delete from user where id=?", 1)
//	//
//	//name = "Miles"
//	//age = 88
//	//id := 2
//	//Update("update user set name=?, age=? where id=?", name, age, id)
//	//
//	//QueryRow("select id, name, age from user where id>?", id)
//	//
//	//QueryRow("select id, name, age from user")
//
//}
//
//func InsertOne(table string, value interface{}) {
//	Db.Table(table).Create(value)
//}
//
//func Delete(table string, value interface{}) {
//	Db.Table(table).Delete(value)
//}
//
////
////func Update(esql string, params ...any) {
////
////	result, err := db.Exec(esql, params...)
////	if err != nil {
////		panic(err)
////	}
////
////	// RowsAffected returns the number of rows affected by an
////	// update, insert, or delete.
////	rowsAffected, err := result.RowsAffected()
////	if err != nil {
////		panic(err)
////	}
////
////	fmt.Printf("update affect rows:%d\n", rowsAffected)
////}
////
////// 单行查询，如果查询到多个结果，只返回第一行，查询不到结果就ErrNoRows错误。
////func QueryRow(esql string, params ...any) {
////	id := 1
////	row := db.QueryRow(esql, params...)
////
////	var user User
////	fmt.Println(row)
////
////	for _, v := range row {
////		Allproduct := &Product{}
////		common.DataToStructByTagSql(v, Allproduct)
////		productArray = append(productArray, Allproduct)
////	}
////
////	if err == sql.ErrNoRows {
////		log.Printf("not found data of the id:%d", id)
////	}
////
////	if err != nil {
////		panic(err)
////	}
////
////	fmt.Printf("user: %#v\n", user)
////}
////
//////根据结构体中sql标签映射数据到结构体中并且转换类型
////func DataToStructByTagSql(data map[string]string, obj interface{}) {
////	objValue := reflect.ValueOf(obj).Elem()
////	for i := 0; i < objValue.NumField(); i++ {
////		//获取sql对应的值
////		value := data[objValue.Type().Field(i).Tag.Get("sql")]
////		//获取对应字段的名称
////		name := objValue.Type().Field(i).Name
////		//获取对应字段类型
////		structFieldType := objValue.Field(i).Type()
////		//获取变量类型，也可以直接写"string类型"
////		val := reflect.ValueOf(value)
////		var err error
////		if structFieldType != val.Type() {
////			//类型转换
////			val, err = TypeConversion(value, structFieldType.Name()) //类型转换
////			if err != nil {
////
////			}
////		}
////		//设置类型值
////		objValue.FieldByName(name).Set(val)
////	}
////}
////
//////类型转换
////func TypeConversion(value string, ntype string) (reflect.Value, error) {
////	if ntype == "string" {
////		return reflect.ValueOf(value), nil
////	} else if ntype == "time.Time" {
////		t, err := time.ParseInLocation("2006-01-02 15:04:05", value, time.Local)
////		return reflect.ValueOf(t), err
////	} else if ntype == "Time" {
////		t, err := time.ParseInLocation("2006-01-02 15:04:05", value, time.Local)
////		return reflect.ValueOf(t), err
////	} else if ntype == "int" {
////		i, err := strconv.Atoi(value)
////		return reflect.ValueOf(i), err
////	} else if ntype == "int8" {
////		i, err := strconv.ParseInt(value, 10, 64)
////		return reflect.ValueOf(int8(i)), err
////	} else if ntype == "int32" {
////		i, err := strconv.ParseInt(value, 10, 64)
////		return reflect.ValueOf(int64(i)), err
////	} else if ntype == "int64" {
////		i, err := strconv.ParseInt(value, 10, 64)
////		return reflect.ValueOf(i), err
////	} else if ntype == "float32" {
////		i, err := strconv.ParseFloat(value, 64)
////		return reflect.ValueOf(float32(i)), err
////	} else if ntype == "float64" {
////		i, err := strconv.ParseFloat(value, 64)
////		return reflect.ValueOf(i), err
////	}
////
////	//else if .......增加其他一些类型的转换
////
////	return reflect.ValueOf(value), errors.New("未知的类型：" + ntype)
////}
////
////// 多行查询, 查询不到任何记录也不会报错。
////func Query(esql string, params ...any) {
////	id := 0
////	rows, err := db.Query(esql, params...)
////	if err != nil {
////		panic(err)
////	}
////	if err == sql.ErrNoRows {
////		log.Printf("not found data of id:%d\n", id)
////		return
////	}
////	defer rows.Close()
////
////	for rows.Next() {
////		var user User
////		err := rows.Scan(&user.Id, &user.Name, &user.Age)
////		if err != nil {
////			panic(err)
////		}
////		fmt.Printf("user: %#v\n", user)
////	}
////
////}
////
////func Transaction(db *sql.DB) {
////
////	// 开启事务
////	tx, err := db.Begin()
////
////	if err != nil {
////		panic(err)
////	}
////
////	result, err := tx.Exec("insert into user(name, age)values(?,?)", "Jack", 98)
////	if err != nil {
////		// 失败回滚
////		tx.Rollback()
////		panic(err)
////	}
////
////	fmt.Println("result", result)
////
////	exec, err := tx.Exec("update user set name=?, age=? where id=?", "Jack", 98, 1)
////	if err != nil {
////		// 失败回滚
////		tx.Rollback()
////		panic(err)
////	}
////	fmt.Println("exec", exec)
////
////	// 提交事务
////	err = tx.Commit()
////
////	if err != nil {
////		// 失败回滚
////		tx.Rollback()
////		panic(err)
////	}
////}

package main

import (
	"errors"
	"fmt"
	"reflect"
)

type Info struct {
	Name  string
	Price int `json:"price" from:"pri"`
}

func main() {
	info := Info{
		Name:  "name1",
		Price: 1,
	}
	err, sql := reflectSql(info)
	fmt.Println(err, sql) // <nil> insert into Info (Name,Price) values(name1,1)
}

func reflectSql(data interface{}) (error, string) {
	v := reflect.ValueOf(data)
	t := reflect.TypeOf(data)
	if t.Kind() != reflect.Struct {
		return errors.New("unsupported argument type"), ""
	}
	sql := "insert into " + t.Name()
	sqlEle := " ("
	sqlValue := " values("
	fieldNum := t.NumField()
	for i := 0; i < fieldNum; i++ {
		switch t.Field(i).Type.Kind() {
		case reflect.Int:
			if i == fieldNum-1 {
				sqlEle += t.Field(i).Name
				sqlValue += fmt.Sprintf("%d", v.Field(i).Int())
			} else {
				sqlEle += t.Field(i).Name + ","
				sqlValue += fmt.Sprintf("%d,", v.Field(i).Int())
			}
		case reflect.String:
			if i == fieldNum-1 {
				sqlEle += t.Field(i).Name
				sqlValue += v.Field(i).String()
			} else {
				sqlEle += t.Field(i).Name + ","
				sqlValue += v.Field(i).String() + ","
			}
		}
	}
	sqlEle += ")"
	sqlValue += ")"
	sql += sqlEle + sqlValue
	return nil, sql
}
