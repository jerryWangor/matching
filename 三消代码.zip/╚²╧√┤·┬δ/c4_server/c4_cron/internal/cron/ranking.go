package cron

import (
	"c4_center/container/cmongo"
	"c4_center/kredis"
	"c4_center/utils"
	"c4_cron/internal/service"
	"context"
	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"reflect"
	"strings"
	"time"
)

func SetScoreRanking() {
	logrus.Infof("刷新积分排行榜")
	// 从mongo中查询所有玩家的分数数据
	data, err := service.GetAllPlayerRankInfo()
	if err != nil {
		logrus.Error(err)
		return
	}

	// 写redis
	if err := kredis.ZRAdd(context.TODO(), cmongo.RANKING_REDIS_NAME, data); err != nil {
		logrus.Error(err)
		return
	}

	// 同时写一份mongo
	time.Sleep(50 * time.Microsecond)
	insertDatas := make([]interface{}, 0)
	dateTime := utils.GetHourZeroTimeStamp()
	rData := kredis.ZRangeWithScores(context.TODO(), cmongo.RANKING_REDIS_NAME, 0, cmongo.RANKING_SAVE_NUM-1)
	for k, val := range rData {
		insertData := &cmongo.PlayerRankingTmp{
			ID:       primitive.NewObjectID().Hex(),
			Type:     cmongo.RANKING_TYPE_SCORE,
			Rank:     int32(k + 1),
			Token:    val.Member.(string),
			Score:    int32(val.Score * -1),
			DateTime: dateTime,
		}
		insertDatas = append(insertDatas, reflect.ValueOf(insertData).Interface())
	}

	// 插入数据
	if err := service.InsertUpdateRanking(cmongo.RANKING_TYPE_SCORE, dateTime, insertDatas); err != nil {
		logrus.Error(err)
	}
}

func SetHeroLevelRanking() {
	logrus.Infof("刷新英雄等级排行榜")
	// 从mongo中查询所有玩家的分数数据
	data, err := service.GetPlayerRankInfoByHeroLevel()
	if err != nil {
		logrus.Error(err)
		return
	}

	// 写redis
	if err := kredis.ZRAddByRanking(context.TODO(), cmongo.RANKING_REDIS_NAME_HERO_LEVEL, data); err != nil {
		logrus.Error(err)
		return
	}

	// 同时写一份mongo
	time.Sleep(50 * time.Microsecond)
	insertDatas := make([]interface{}, 0)
	dateTime := utils.GetHourZeroTimeStamp()
	rData := kredis.ZRangeWithScores(context.TODO(), cmongo.RANKING_REDIS_NAME_HERO_LEVEL, 0, cmongo.RANKING_SHOW_NUM-1)
	for k, val := range rData {
		// 解析val.Member order_heroToken_gene_userToken
		arr := strings.Split(val.Member.(string), "_")

		insertData := &cmongo.PlayerRankingHeroLevel{
			ID:        primitive.NewObjectID().Hex(),
			Type:      cmongo.RANKING_TYPE_HERO_LEVEL,
			Rank:      int32(k + 1),
			Token:     arr[3],
			HeroLevel: int32(val.Score * -1),
			HeroToken: arr[1],
			DateTime:  dateTime,
		}
		insertDatas = append(insertDatas, reflect.ValueOf(insertData).Interface())
	}

	// 插入数据
	if err := service.InsertUpdateRanking(cmongo.RANKING_TYPE_HERO_LEVEL, dateTime, insertDatas); err != nil {
		logrus.Error(err)
	}
}
