package service

import (
	"c4_center/kmongo"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"strconv"
)

// 获取所有玩家的数据
func GetAllPlayerRankInfo() (map[string]float64, error) {

	data := make(map[string]float64)

	o1 := bson.D{{"$match", bson.D{{"rank_1.score", bson.D{{"$gt", 0}}}}}}
	o2 := bson.D{{"$lookup", bson.D{{"from", "account"}, {"localField", "user_id"}, {"foreignField", "user_id"}, {"as", "out_put_docs"}}}}
	o3 := bson.D{{"$match", bson.D{{"out_put_docs.token", bson.D{{"$ne", ""}}}, {"out_put_docs.0", bson.D{{"$exists", true}}}}}}
	o4 := bson.D{{"$project", bson.D{{"rank_1.score", 1}, {"out_put_docs.token", 1}}}}

	showInfoCursor, err := kmongo.PlayerRankInfoCollection.Aggregate(context.TODO(), mongo.Pipeline{o1, o2, o3, o4})
	if err != nil {
		return data, err
	}

	var showsWithInfo []bson.M
	if err = showInfoCursor.All(context.TODO(), &showsWithInfo); err != nil {
		return data, err
	}

	for _, v := range showsWithInfo {
		sStr := fmt.Sprintf("%v", v["rank_1"].(bson.M)["score"])
		token := fmt.Sprintf("%v", v["out_put_docs"].(bson.A)[0].(bson.M)["token"])
		sFloat, _ := strconv.ParseFloat(sStr, 64)
		data[token] = sFloat * -1
	}

	return data, nil
}

//func InsertPlayerRanking() {
//
//}
