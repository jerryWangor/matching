package config

import "c4_center/game_config"

func InitGameConfig() {
	//init
	game_config.InitItemConfig(GameConfigInstant.Path)
}
