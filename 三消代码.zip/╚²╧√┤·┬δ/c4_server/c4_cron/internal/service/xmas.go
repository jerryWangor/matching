package service

import (
	"c4_center/kmongo"
	"context"
	"errors"

	"go.mongodb.org/mongo-driver/bson"
)

// 更新某个商店ID的所有购买次数
func DeleteLimitHeroXmas() error {
	if !kmongo.DeleteMany(context.TODO(), kmongo.XmasLimitCollection, bson.M{}) {
		return errors.New("deleteLimitHeroXmas error")
	}
	return nil
}
