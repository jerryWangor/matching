package internal

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/utils"
	"c4_lobby/internal/item"
	"context"
	"fmt"
	"strconv"
	"strings"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

//rank reward
func ReceiveRankReward(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_RECEIVE_RANKREWARD_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	//配置读取错误
	config := game_config.PvPSegmentConfigInstant.GetInfo(reqData.Cid)
	if config == nil {
		return nil, fmt.Errorf("can not get config id -> %v", reqData.Cid)
	}

	//没有排位数据需写入
	var rankInfo cmongo.PlayerRankInfo
	kmongo.GetOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rankInfo, bson.M{"user_id": req.UserId})
	if len(rankInfo.ID) <= 0 {
		return nil, fmt.Errorf("can not get rank info -> userid: %v", req.UserId)
	}

	//积分检测
	if rankInfo.Rank_1.TopScore < config.Exp {
		return nil, fmt.Errorf("request rank exp -> %v, need rank exp -> %v", rankInfo.Rank_1.TopScore, config.Exp)
	}

	var code int32
	var itemData []*kproto.ItemInfo
	//领取
	if !utils.HasFlag(rankInfo.Rank_1.RankRewardFlag, 1<<reqData.Cid) {
		//update flag
		rankInfo.Rank_1.RankRewardFlag = utils.SetFlag(rankInfo.Rank_1.RankRewardFlag, 1<<reqData.Cid)
		//update mongo
		if !kmongo.UpdateOne(context.TODO(), kmongo.PlayerRankInfoCollection, bson.M{"user_id": req.UserId}, bson.M{"$set": bson.M{"rank_1.rank_reward_flag": rankInfo.Rank_1.RankRewardFlag}}) {
			code = -88
		} else {
			for _, v := range config.StarReward {
				tmpItem := InitItemByString(req.UserId, v)
				if tmpItem == nil {
					continue
				}

				if tmpItem.ItemConfig.StackingLimit == 0 {
					tmpItem.Num = AddItemUnlimit(tmpItem)
				} else {
					tmpItem.Num = AddItemLimit(tmpItem)
				}

				itemData = append(itemData, item.ItemData(tmpItem))
			}
		}
	} else {
		code = -89 //己领取
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_RECEIVE_RANKREWARD_RESP_ID), &kproto.LOBBY_RECEIVE_RANKREWARD_RESP{Code: code, Flag: rankInfo.Rank_1.RankRewardFlag, Items: itemData})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//get rank info
func RankInfo(req *kproto.SendReq) (*kproto.SendResp, error) {
	val := kproto.RankInfo{}

	//没有排位数据
	var rankInfo cmongo.PlayerRankInfo
	kmongo.GetOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rankInfo, bson.M{"user_id": req.UserId})
	if len(rankInfo.ID) <= 0 {
		//初始化&写入
		rankInfo.InitPlayerRankInfo(req.UserId)
		if !kmongo.InsertOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rankInfo) {
			return nil, fmt.Errorf("insert db error -> userid :%v", req.UserId)
		}
	}

	val.Score = rankInfo.Rank_1.Score
	val.TopScore = rankInfo.Rank_1.TopScore
	val.Win = rankInfo.Rank_1.Win
	val.Lose = rankInfo.Rank_1.Lose
	val.RankRewardFlag = rankInfo.Rank_1.RankRewardFlag

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_RANKREWARD_RESP_ID), &kproto.LOBBY_RANKREWARD_RESP{Info: &val})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//get ranking
func GetRanking(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_RANKING_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	allData := make([]*kproto.RankingData, 0)
	myData := &kproto.RankingData{Name: reqData.Token}

	if err := GetRankingFromRedis(&allData, myData, &reqData); err != nil {
		return nil, err
	}

	// // 如果redis没找到就从mongo中
	// if len(allData) <= 0 {
	// 	if err := GetRankingFromMongo(&allData, myData, &reqData); err != nil {
	// 		return nil, err
	// 	}
	// }

	//encode
	info := &kproto.LOBBY_RANKING_RESP{}
	// 根据活动时间来判断是否关闭
	conf := game_config.ActivityConfigInstant.GetInfo(game_config.ActivityId_RankingGrad)
	eTime := utils.DateTimeToTimestamp(cmongo.DATETIME_FORMAT, conf.EndTime)
	nTime := utils.GetNowTime()
	// 已关闭
	if eTime > nTime {
		info.Status = 1
	}
	info.AllData = allData
	info.MyData = myData
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_RANKING_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

func GetRankingFromRedis(allData *[]*kproto.RankingData, myData *kproto.RankingData, reqData *kproto.LOBBY_RANKING_REQ) error {
	// 从redis中取出N名
	rData := kredis.ZRangeWithScores(context.TODO(), cmongo.RANKING_REDIS_NAME, 0, cmongo.RANKING_SHOW_NUM-1)
	if len(rData) <= 0 {
		logrus.Errorf("redis not data")
	}
	for k, val := range rData {
		// 如果分数为0就continue
		if val.Score == 0 {
			continue
		}
		data := &kproto.RankingData{
			Name:  val.Member.(string),
			Rank:  int32(k + 1),
			Score: int32(val.Score * -1),
		}
		*allData = append(*allData, data)
	}

	// 查询自己的排名
	myRank := kredis.ZRank(context.TODO(), cmongo.RANKING_REDIS_NAME, reqData.Token)
	if myRank == -1 {
		// -1代表没有找到
		myData.Rank = 0
	} else {
		myData.Rank = int32(myRank) + 1
		// 查询自己的分数
		mMyData := kredis.ZRangeWithScores(context.TODO(), cmongo.RANKING_REDIS_NAME, myRank, myRank)
		myData.Score = int32(mMyData[0].Score * -1)
	}

	return nil
}

func GetRankingFromMongo(allData *[]*kproto.RankingData, myData *kproto.RankingData, reqData *kproto.LOBBY_RANKING_REQ) error {
	// 先查询最大的date_time，用最大的date_time查询数据
	findOp := options.FindOne()
	findOp.SetSort(bson.D{{"date_time", -1}})
	result := kmongo.PlayerRankingTmpCollection.FindOne(context.TODO(), bson.D{{"type", cmongo.RANKING_TYPE_SCORE}}, findOp)
	var lastOne cmongo.PlayerRankingTmp
	result.Decode(&lastOne)

	if lastOne.DateTime == 0 {
		return fmt.Errorf("mongo not data")
	}
	o1 := bson.D{{"$match", bson.D{{"date_time", utils.GetHourZeroTimeStamp()}}}}
	o2 := bson.D{{"$sort", bson.D{{"rank", 1}}}}
	o3 := bson.D{{"$limit", cmongo.RANKING_SHOW_NUM}}

	showInfoCursor, err := kmongo.PlayerRankingTmpCollection.Aggregate(context.TODO(), mongo.Pipeline{o1, o2, o3})
	if err != nil {
		return err
	}

	var showsWithInfo []bson.M
	if err = showInfoCursor.All(context.TODO(), &showsWithInfo); err != nil {
		return err
	}

	for _, val := range showsWithInfo {
		rank, _ := strconv.ParseInt(fmt.Sprintf("%v", val["rank"]), 10, 64)
		score, _ := strconv.ParseInt(fmt.Sprintf("%v", val["score"]), 10, 64)
		data := &kproto.RankingData{
			Name:  fmt.Sprintf("%v", val["token"]),
			Rank:  int32(rank),
			Score: int32(score),
		}
		*allData = append(*allData, data)
	}

	// 查询自己的
	mMyData := cmongo.PlayerRankingTmp{}
	kmongo.GetOne(context.TODO(), kmongo.PlayerRankingTmpCollection, &mMyData, bson.M{"token": reqData.Token})
	if len(mMyData.ID) <= 0 {
		logrus.Errorf("my data not found")
	}
	myData.Rank = mMyData.Rank
	myData.Score = mMyData.Score
	return nil
}

////get ranking by hero level
//func GetRankingHeroLevel(req *kproto.SendReq) (*kproto.SendResp, error) {
//	var reqData kproto.LOBBY_RANKING_REQ
//	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
//		return nil, err
//	}
//
//	allData := make([]*kproto.RankingHeroLevelData, 0)
//	myData := &kproto.RankingHeroLevelData{Name: reqData.Token}
//
//	if err := GetRankingHeroLevelFromRedis(&allData, myData, &reqData); err != nil {
//		return nil, err
//	}
//
//	//encode
//	info := &kproto.LOBBY_RANKING_HERO_LEVEL_RESP{}
//	info.AllData = allData
//	info.MyData = myData
//	packet, err := getPacket(uint32(kproto.MSG_LOBBY_RANKING_RESP_ID), info)
//	if err != nil {
//		return nil, err
//	}
//
//	return &kproto.SendResp{Packet: packet}, nil
//}
//
//func GetRankingHeroLevelFromRedis(allData *[]*kproto.RankingHeroLevelData, myData *kproto.RankingHeroLevelData, reqData *kproto.LOBBY_RANKING_REQ) error {
//	// 从redis中取出N名
//	rData := kredis.ZRangeWithScores(context.TODO(), cmongo.RANKING_REDIS_NAME_HERO_LEVEL, 0, cmongo.RANKING_SHOW_NUM-1)
//	if len(rData) <= 0 {
//		logrus.Errorf("redis not data")
//	}
//	for k, val := range rData {
//		// 解析val.Member order_heroToken_gene_userToken
//		arr := strings.Split(val.Member.(string), "_")
//		heroToken, _ := strconv.Atoi(arr[1])
//		data := &kproto.RankingHeroLevelData{
//			Name:      arr[3],
//			Rank:      int32(k + 1),
//			HeroToken: int32(heroToken),
//			HeroLevel: int32(val.Score * -1),
//		}
//		*allData = append(*allData, data)
//	}
//
//	// 查询自己的排名
//	myRank := kredis.ZRank(context.TODO(), cmongo.RANKING_REDIS_NAME_HERO_LEVEL, reqData.Token)
//	if myRank == -1 {
//		// -1代表没有找到
//		myData.Rank = 0
//	} else {
//		myData.Rank = int32(myRank) + 1
//		// 查询自己的分数
//		mMyData := kredis.ZRangeWithScores(context.TODO(), cmongo.RANKING_REDIS_NAME_HERO_LEVEL, myRank, myRank)
//		arr := strings.Split(mMyData[0].Member.(string), "_")
//		heroToken, _ := strconv.Atoi(arr[1])
//		myData.HeroToken = int32(heroToken)
//		myData.HeroLevel = int32(mMyData[0].Score * -1)
//	}
//
//	return nil
//}

//字符串初始化道具
func InitItemByString(uid, itemStr string) *cmongo.Item {
	//split
	itemInfo := strings.Split(itemStr, "*")
	if len(itemInfo) <= 0 {
		return nil
	}

	itemId, _ := strconv.ParseInt(itemInfo[0], 10, 32)
	itemNum, _ := strconv.ParseInt(itemInfo[1], 10, 32)

	return item.GetInitItem(uid, int32(itemId), itemNum)
}

//初始化道具
func InitItem(uid string, tid int32, num int64) (*cmongo.Item, error) {
	ret := &cmongo.Item{ID: primitive.NewObjectID().Hex(), UserID: uid, TypeId: tid, Num: num}
	//道具配置
	ret.ItemConfig = game_config.ItemConfigInstant.GetInfo(ret.TypeId)
	if ret.ItemConfig == nil {
		return nil, fmt.Errorf("cannot get config . type_id -> %v", ret.TypeId)
	}

	//设置大类小类，方便后面的宝箱插槽查询
	ret.MainType = ret.ItemConfig.MainType
	ret.SubType = ret.ItemConfig.SubType

	//num != nil
	if ret.Num <= 0 {
		return nil, fmt.Errorf("item num can not be nil -> %v", tid)
	}

	return ret, nil
}

//无数量限制堆叠 (return : 实际写入数量)
func AddItemUnlimit(item *cmongo.Item) int64 {
	var tmp cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &tmp, bson.M{"user_id": item.UserID, "type_id": item.TypeId})

	//无数据写入,有数量更新
	if len(tmp.ID) > 0 {
		kmongo.UpdateOne(context.TODO(), kmongo.ItemCollection, bson.M{"_id": tmp.ID}, bson.M{"$set": bson.M{"num": tmp.Num + item.Num}})
	} else {
		kmongo.InsertOne(context.TODO(), kmongo.ItemCollection, item)
	}

	return item.Num
}

//有数量限制堆叠(return : 实际写入数量)
func AddItemLimit(item *cmongo.Item) int64 {
	var tmp []*cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &tmp, bson.M{"user_id": item.UserID, "type_id": item.TypeId})

	totalNum := item.Num //总数量
	lastNum := item.Num  //剩余数量
	if len(tmp) <= 0 {
		lastNum = InsertOrUpdateLimitNum(item, lastNum, true)
	} else {
		for k := range tmp {
			lastNum = InsertOrUpdateLimitNum(tmp[k], lastNum, false)
		}
	}

	//剩余数量循环写入
	for lastNum > 0 {
		lastNum = InsertOrUpdateLimitNum(item, lastNum, true)
	}

	return totalNum - lastNum
}

//写入&更新物品数据-> (int64 : 返回剩余数量)
func InsertOrUpdateLimitNum(item *cmongo.Item, maxNum int64, isInsert bool) int64 {
	if isInsert {
		item.Num = 0
	}

	//装载量
	load := utils.Min64(int64(item.ItemConfig.StackingLimit)-item.Num, maxNum)
	//剩余量
	last := maxNum - load

	//更新装载数量
	item.Num += load

	if isInsert {
		//宝箱类需要检测是否能获取
		if item.MainType == game_config.MainType_Box && item.SubType == game_config.SubType_BoxGrade {
			item.Index = GetBoxIndex(item.UserID)
			if item.Index < 0 {
				return 0
			}
		}

		//更新ID
		item.ID = primitive.NewObjectID().Hex()
		//写入
		kmongo.InsertOne(context.TODO(), kmongo.ItemCollection, item)
	} else {
		//更新
		kmongo.UpdateOne(context.TODO(), kmongo.ItemCollection, bson.M{"_id": item.ID}, bson.M{"$set": bson.M{"num": item.Num}})
	}

	return last
}

//得到宝箱槽索引
func GetBoxIndex(uid string) int32 {
	// 判断是否有空槽
	bs := item.LoadBoxSlotByUserId(uid)
	if len(bs) >= int(cmongo.MAX_BOX_SLOT_INDEX+1) {
		return -1
	} else {
		hasIndexMap := make(map[int32]int32)
		for k := range bs {
			hasIndexMap[bs[k].Index] = bs[k].Index
		}
		//循环判断哪个是空槽
		for i := cmongo.MIN_BOX_SLOT_INDEX; i <= cmongo.MAX_BOX_SLOT_INDEX; i++ {
			_, ok := hasIndexMap[i]
			if !ok {
				return i
			}
		}
	}

	// 没有空槽返回-1
	return -1
}
