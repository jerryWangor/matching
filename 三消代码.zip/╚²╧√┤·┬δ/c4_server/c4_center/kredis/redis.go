package kredis

import (
	"c4_center/container/credis"
	"context"
	"time"

	"github.com/go-redis/redis/v8"
)

var (
	Client *redis.Client
)

//string
func Init(opt *redis.Options) {
	ctx, cancel := context.WithTimeout(context.TODO(), time.Second*5)
	defer cancel()

	Client = redis.NewClient(opt)
	if result := Client.Ping(ctx); result.Err() != nil {
		panic(result.Err())
	}
}

func GetStr(ctx context.Context, key string) (string, error) {
	return Client.Get(ctx, key).Result()
}

func SetStr(ctx context.Context, key, val string, expiration time.Duration) error {
	return Client.Set(ctx, key, val, expiration).Err()
}

// list
func RPush(ctx context.Context, key string, values ...interface{}) error {
	return Client.RPush(ctx, key, values).Err()
}

func LPop(ctx context.Context, key string) string {
	return Client.LPop(ctx, key).String()
}

//set
func SAdd(ctx context.Context, key string, members ...interface{}) error {
	return Client.SAdd(ctx, key, members...).Err()
}

func SRem(ctx context.Context, key string, members ...interface{}) error {
	return Client.SRem(ctx, key, members...).Err()
}

func SPop(ctx context.Context, key string) string {
	return Client.SPop(ctx, key).String()
}

// hash
func HSet(ctx context.Context, key string, members ...interface{}) error {
	return Client.HSet(ctx, key, members...).Err()
}

func HMSet(ctx context.Context, key string, members ...interface{}) error {
	return Client.HMSet(ctx, key, members...).Err()
}

func HMGet(ctx context.Context, key string, members ...string) []interface{} {
	return Client.HMGet(ctx, key, members...).Val()
}

func HGetAll(ctx context.Context, key string) map[string]string {
	return Client.HGetAll(ctx, key).Val()
}

func HExists(ctx context.Context, key string, members string) bool {
	return Client.HExists(ctx, key, members).Val()
}

func HDel(ctx context.Context, key string, members ...string) (int64, error) {
	return Client.HDel(ctx, key, members...).Result()
}

// zset
func ZAdd(ctx context.Context, key string, members ...*redis.Z) error {
	return Client.ZAdd(ctx, key, members...).Err()
}

func ZRAdd(ctx context.Context, key string, data map[string]float64) error {
	for m, s := range data {
		z := redis.Z{
			Score:  s,
			Member: m,
		}
		if err := ZAdd(ctx, key, &z); err != nil {
			return err
		}
	}
	return nil
}

func ZRAddByRanking(ctx context.Context, key string, data []credis.Ranking) error {
	for _, s := range data {
		z := redis.Z{
			Score:  s.Score,
			Member: s.Member,
		}
		if err := ZAdd(ctx, key, &z); err != nil {
			return err
		}
	}
	return nil
}

func ZRem(ctx context.Context, key string) error {
	return Client.Del(ctx, key).Err()
}

func ZRange(ctx context.Context, key string, start int64, stop int64) []string {
	return Client.ZRange(ctx, key, start, stop).Val()
}

func ZRevRange(ctx context.Context, key string, start int64, stop int64) []string {
	return Client.ZRevRange(ctx, key, start, stop).Val()
}

func ZRangeWithScores(ctx context.Context, key string, start int64, stop int64) []redis.Z {
	return Client.ZRangeWithScores(ctx, key, start, stop).Val()
}

func ZRank(ctx context.Context, key string, member string) int64 {
	zrank := Client.ZRank(ctx, key, member)
	if zrank.Err() != nil {
		return -1
	}
	return zrank.Val()
}
