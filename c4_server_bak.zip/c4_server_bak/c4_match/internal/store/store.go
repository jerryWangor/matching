package store

import (
	"sync"
	"time"
)

type Store interface {
	GetName() string
	Add(user *User)
	Remove(userid string)
	Get(id string) *User
	Range(f func(key, value any) bool)
}

type MemoryStore struct {
	Users *sync.Map
}

func NewInMemoryStore() Store {
	return &MemoryStore{
		Users: &sync.Map{},
	}
}

func (i *MemoryStore) Add(user *User) {
	user.JoinTime = time.Now()
	i.Users.Store(user.ID, user)
}

func (i *MemoryStore) Remove(userid string) {
	i.Users.Delete(userid)
}

func (i *MemoryStore) Get(id string) *User {
	ret, _ := i.Users.Load(id)
	return ret.(*User)
}

func (i *MemoryStore) Range(f func(key, value any) bool) {
	i.Users.Range(f)
}

func (i *MemoryStore) GetName() string {
	return "MemoryStore"
}
