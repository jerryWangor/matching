package internal

import (
	"c4_center/game_config"
	"c4_match/config"
	"c4_match/internal/rules"
	"c4_match/internal/store"
	"fmt"
	"reflect"
	"testing"
)

func TestMatchMaking(t *testing.T) {
	//初始化配置
	config.GameConfigInstant = &config.GameConfig{Path: "../../c4_json"}
	//初始化游戏配置
	config.InitGameConfig()
	//watch
	go game_config.WatchGameConfig(config.GameConfigInstant.Path, config.InitGameConfig)

	//初始化匹配池
	for _, v := range game_config.MatchRuleConfigInstant.Infos {
		New(&Options{ID: v.ID, Store: store.NewInMemoryStore(), Service: NewRespServer(100), Rule: rules.NewScoreMatchRule(v.ID)})
	}

	MatchMakingPoolInstant.Start()

	MatchMakingPoolInstant.Get(2).AddUser(store.InitBot("aaa"))
	MatchMakingPoolInstant.Get(2).AddUser(store.InitBot("bbb"))

	select {}
}

func TestStruct(t *testing.T) {
	// use of StructOf method
	typ := reflect.StructOf([]reflect.StructField{
		{
			Name: "Height",
			Type: reflect.TypeOf(float64(0)),
			Tag:  `json:"tag"`,
		},
		{
			Name: "Name",
			Type: reflect.TypeOf("abc"),
			Tag:  `json:"name"`,
		},
	})

	fmt.Println(typ)
}
