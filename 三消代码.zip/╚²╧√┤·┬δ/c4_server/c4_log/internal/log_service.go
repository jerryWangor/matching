package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"context"
	"fmt"
)

var Codec ktcp.Codec

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

type LogService struct {
	kproto.UnimplementedLogServiceServer
}

func (l *LogService) LogRpc(ctx context.Context, req *kproto.SendReq) (*kproto.SendResp, error) {
	switch req.Packet.MsgId {
	case uint32(kproto.LOG_MSG_SERVER_REQ_ID):
		return CheckData(req)
		//case uint32(kproto.LOG_MSG_CLIENT_POINT_ID):
		//	return ClientPointCheck(req)
	}

	return nil, fmt.Errorf("msg -> %v not found, please check", req.Packet.MsgId)
}
