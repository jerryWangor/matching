package game_config

type SkillEffectData struct {
	soundStartTime         []int32      `tb_name:"音效时间轴"`
	soundName              []string     `tb_name:"音效资源"`
	effectsTypeDisplay     []EffectType `tb_name:"效果类型表现"`
	effectsStartTime       []float32    `tb_name:"效果开始时间"`
	effectsStayTime        []float32    `tb_name:"效果持续时间"`
	shootsIDs              []string     `tb_name:"发射物id"`
	shootsStartTime        []float32    `tb_name:"发射物开始时间"`
	shootsStayTime         []float32    `tb_name:"发射物持续时间"`
	partilcesIDs           []string     `tb_name:"特效id"`
	particlesStartTime     []float32    `tb_name:"特效开始时间"`
	particlesStayTime      []float32    `tb_name:"特效持续时间"`
	Id                     int32        `tb_name:"效果ID"`
	EffectType             int32        `tb_name:"效果类型"`
	EffectParam            []int32      `tb_name:"效果参数"`
	SkillScope             int32        `tb_name:"效果范围"`
	Targe                  int32        `tb_name:"目标类型"`
	TargetType             int32        `tb_name:"目标子类"`
	TargetParam            int32        `tb_name:"目标数量"`
	Duration               int32        `tb_name:"持续时间(回合)"`
	Interval               int32        `tb_name:"间隔时间(回合)"`
	TriggerType            int32        `tb_name:"生效时机类型"`
	AfterEffectTriggerRate []int32      `tb_name:"后续效果触发几率（万分比）"`
	AfterEffectId          []int32      `tb_name:"后续效果Id"`
	SkillType              int32        `tb_name:"技能归属"`
}

var SkillEffectConfigInstant *SkillEffectConfig

type SkillEffectConfig struct {
	SkillEffectData []*SkillEffectData
	Infos           map[int32]*SkillEffectData
}

func InitSkillEffectConfig(path string) {
	SkillEffectConfigInstant = &SkillEffectConfig{Infos: make(map[int32]*SkillEffectData)}
	//加载
	LoadJsonFile(path+"/SkillEffectData.json", SkillEffectConfigInstant)
	//初始化
	SkillEffectConfigInstant.InitIndex()
}

func (s *SkillEffectConfig) InitIndex() {
	for i, v := range s.SkillEffectData {
		s.Infos[v.Id] = s.SkillEffectData[i]
	}
}

func (s *SkillEffectConfig) GetInfo(id int32) *SkillEffectData {
	return s.Infos[id]
}
