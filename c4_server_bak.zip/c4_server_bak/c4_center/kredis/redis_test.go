package kredis

import (
	"context"
	"testing"

	"github.com/go-redis/redis/v8"
)

func TestMongo(t *testing.T) {

	Init(&redis.Options{
		Addr:     "192.168.1.45:6379",
		Password: "",
		DB:       0,
		PoolSize: 100,
	})

	if err := SetStr(context.TODO(), "1", "2", 0); err != nil {
		t.Fatal(err)
	}

	str, err := GetStr(context.TODO(), "1")
	if err != nil {
		t.Fatal(err)
	}

	t.Log(str)
}
