package main

import (
	"c4_center/game_config"
	"c4_center/klog"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/ktcp"
	"c4_center/registry/etcd"
	"c4_room/config"
	"c4_room/internal"
	"c4_room/internal/room"
	"c4_room/internal/router"
	"c4_room/room_registry"
	"net"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/grpc"
)

func main() {
	//初始化配置
	config.Init("app.ini")
	//初始化logs
	klog.InitLog(config.LogsConfigInstant.Path, config.LogsConfigInstant.Level)
	//初始化游戏配置
	config.InitGameConfig()

	//watch
	go game_config.WatchGameConfig(config.GameConfigInstant.Path, config.InitGameConfig)

	//初始化mongo
	kmongo.Init(config.MongoConfigInstant.Mongo_DB, options.Client().ApplyURI(config.MongoConfigInstant.Mongo_addr))

	//初始化redis
	kredis.Init(&redis.Options{
		Addr:     config.RedisConfigInstant.Redis_addr,
		Password: config.RedisConfigInstant.Redis_pswd,
		DB:       config.RedisConfigInstant.Redis_DB,
		PoolSize: config.RedisConfigInstant.Redis_poolSize,
	})

	//初始化etcd
	room_registry.InitRoomRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second,
		DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))

	//注册etcd服务
	if err := room_registry.EtcdClient.Register(config.GrpcServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := room_registry.EtcdClient.Register(config.TcpServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	//启动rpc服务
	lis, err := net.Listen("tcp", config.GrpcConfigInstant.Grpc_addr)
	if err != nil {
		logrus.Fatalf("failed to listen: %v", err)
	}

	var opts []grpc.ServerOption
	grpcServer := grpc.NewServer(opts...)
	kproto.RegisterRoomServiceServer(grpcServer, &internal.RoomService{})
	// grpcServer.Serve(lis)
	go func() { grpcServer.Serve(lis) }()
	logrus.Infof("server start : %v.", lis.Addr().String())

	//启动tcp服务
	ktcp.SetLogger(logrus.StandardLogger())
	s := ktcp.NewServer(
		&ktcp.ServerOption{
			SocketReadBufferSize:  1024 * 1024,
			SocketWriteBufferSize: 1024 * 1024,
			ReadTimeout:           time.Minute * 5,
			WriteTimeout:          time.Minute * 5,
			RespQueueSize:         0,
			Packer:                ktcp.NewDefaultPacker(),
			Codec:                 &ktcp.ProtobufCodec{},
			AsyncRouter:           false,
		})

	s.OnSessionCreate = func(sess ktcp.Session) {
		logrus.Infof("connection session created: %v", sess.ID())
	}
	s.OnSessionClose = func(sess ktcp.Session) {
		if sess.Flag() != 0 {
			logrus.Infof("same account connection -> %v", sess.ID().(string))
			return
		}

		userid := sess.ID().(string)
		//remove roomid
		roomid := room.PlayerManagerInstant.GetRoom(userid)
		room.PlayerManagerInstant.RemovePlayer(roomid)
		//remove room player session
		if room := room.SrManagerInstant.GetRoom(roomid); room != nil {
			if player := room.Table.GetPlayer(userid); player != nil {
				player.SetSession(nil)
			}
		}
		//remove session
		room.Sessions.RemoveSession(userid)

		logrus.Warnf("connection session closed: %v", sess.ID())
	}

	//set middlewares
	s.Use(router.RecoverMiddleware())
	//set routes
	s.AddRoute(uint32(kproto.MSG_BATTLE_ENTER_ROOM_REQ_ID), router.EnterRoom)
	s.AddRoute(uint32(kproto.MSG_BATTLE_REENTER_ROOM_REQ_ID), router.ReEnterRoom)
	s.AddRoute(uint32(kproto.MSG_BATTLE_MOVE_REQ_ID), router.Move)
	s.AddRoute(uint32(kproto.MSG_BATTLE_USE_SKILL_REQ_ID), router.UseSkill)
	s.AddRoute(uint32(kproto.MSG_BATTLE_HEARTBEAT_REQ_ID), router.HeartBeat)
	s.AddRoute(uint32(kproto.MSG_BATTLE_AUTO_REQ_ID), router.SetAuto)
	s.AddRoute(uint32(kproto.MSG_BATTLE_SURRENDER_REQ_ID), router.Surrender)

	go func() {
		if err := s.Serve(config.TcpConfigInstant.Tcp_addr); err != nil {
			logrus.Errorf("serve err: %s", err)
		}
	}()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh

	s.Stop()
	grpcServer.Stop()
	logrus.Infof("server stopped.")
}
