package config

import (
	"c4_center/registry"

	"github.com/sirupsen/logrus"
	"gopkg.in/ini.v1"
)

var (
	GrpcConfigInstant   *GrpcConfig               = &GrpcConfig{}
	EtcdConfigInstant   *EtcdConfig               = &EtcdConfig{}
	MongoConfigInstant  *MongoConfig              = &MongoConfig{}
	RedisConfigInstant  *RedisConfig              = &RedisConfig{}
	LogsConfigInstant   *LogsConfig               = &LogsConfig{}
	GameConfigInstant   *GameConfig               = &GameConfig{}
	HttpConfigInstant   *HttpConfig               = &HttpConfig{}
	WalletconfigInstant *WalletConfig             = &WalletConfig{}
	GrpcServiceInstant  *registry.ServiceInstance = &registry.ServiceInstance{}
	HttpServiceInstant  *registry.ServiceInstance = &registry.ServiceInstance{}
)

type EtcdConfig struct {
	Etcd_endpoint []string
}

type GrpcConfig struct {
	Grpc_addr string
}

type HttpConfig struct {
	Http_addr string
}

type MongoConfig struct {
	Mongo_DB   string
	Mongo_addr string
}

type LogsConfig struct {
	Path  string
	Level logrus.Level
}

type GameConfig struct {
	Path string
}

type WalletConfig struct {
	Domain string
}

type RedisConfig struct {
	Redis_addr     string
	Redis_pswd     string
	Redis_DB       int
	Redis_poolSize int
}

func Init(path string) {
	cfg, err := ini.Load(path)
	if err != nil {
		logrus.Fatal(err)
	}

	cfg, err = ini.Load(cfg.Section("").Key("app_mode").String())
	if err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("etcd").MapTo(EtcdConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("grpc").MapTo(GrpcConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("http").MapTo(HttpConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("mongo").MapTo(MongoConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("redis").MapTo(RedisConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("wallet").MapTo(WalletconfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("game-config").MapTo(GameConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("logs").MapTo(LogsConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("grpc-service-instant").MapTo(GrpcServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("http-service-instant").MapTo(HttpServiceInstant); err != nil {
		logrus.Fatal(err)
	}
}
