package buildsql

import "testing"

func TestBuildUser(t *testing.T) {
	
}
