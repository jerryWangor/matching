package internal

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kproto"
	"c4_center/utils"
	"c4_lobby/internal/condition"
	"c4_lobby/internal/item"
	"c4_lobby/internal/shop"
	"fmt"
	"github.com/sirupsen/logrus"
)

// get shop data
func GetShop(req *kproto.SendReq) (*kproto.SendResp, error) {

	// 从redis查询该玩家所有商店限购数据
	allShopItems := shop.GetAllShopItemBuyLimit(req.UserId)

	// 先循环所有商店
	var data []*kproto.SHOP_DATA
	for shopId, shopConf := range game_config.ShopTypeConfigInstant.Infos {
		if shopConf.Switch == 0 {
			continue
		}
		shopData := &kproto.SHOP_DATA{Id: shopId}
		// 如果有瓶颈的话存redis
		//next_refresh_time, err := kredis.GetStr(context.TODO(), "shop:"+fmt.Sprintf("%v", shopId)+":next_refresh_time")
		shopData.NEXT_REFRESH_TIME = utils.GetNextRefreshTime(shopConf.Refresh_Time)
		itemInfo := game_config.ShopItemConfigInstant.GetShopItemsByOrder(shopId)
		for orderId, items := range itemInfo {
			itemData := &kproto.SHOP_ITEM_DATA{Id: 0, LimitNum: 0, BuyNum: 0}
			item := GetItemByOrderId(req.UserId, items)
			itemData.Id = item.ID
			itemData.LimitNum = item.Person_Limit
			if val, ok := allShopItems[shopId][orderId]; ok {
				itemData.BuyNum = val.BuyNum
			}
			shopData.Items = append(shopData.Items, itemData)
		}
		data = append(data, shopData)
	}

	//encode
	info := &kproto.LOBBY_SHOP_RESP{}
	info.Data = data
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_SHOP_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 根据orderId 获取item
func GetItemByOrderId(userId string, items []*game_config.ShopItem) *game_config.ShopItem {
	var item *game_config.ShopItem
	// 如果道具是多个，说明需要用条件，权重等等取出一个，目前只考虑条件
	if len(items) > 1 {
		// 用orderId查询出当前的itemId
		for k, v := range items {
			if condition.CheckCondition(userId, v.Conditional_ID) {
				item = items[k]
				break
			}
		}
	}
	// 如果循环完了没找到就用第一个
	if item == nil {
		item = items[0]
	}
	return item
}

// shop buy
func ShopBuy(req *kproto.SendReq) (*kproto.SendResp, error) {

	var reqData kproto.LOBBY_SHOP_BUY_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	// 获取商店配置
	shopItemConf := game_config.ShopItemConfigInstant.GetItem(reqData.ShopId, reqData.ItemId)
	if shopItemConf == nil {
		return nil, fmt.Errorf("shop item not found : -> shop_id: %v, item_id: %v", reqData.ShopId, reqData.ItemId)
	}

	// 判断当前商品的条件
	if len(shopItemConf.Conditional_ID) > 0 && !condition.CheckCondition(req.UserId, shopItemConf.Conditional_ID) {
		return nil, fmt.Errorf("conditions not met")
	}

	getItemsResp := make([]*kproto.ItemInfo, 0)        //获得的道具返回信息
	conItemsResp := make([]*kproto.ConsumeItemInfo, 0) //消耗的道具返回信息

	// 根据PID判断是充值还是内购
	if len(shopItemConf.Product_ID) > 0 {
		return nil, fmt.Errorf("this is pay item : -> shop_id: %v, item_id: %v", reqData.ShopId, reqData.ItemId)
	}

	if err := ShopBuyInternal(req.UserId, shopItemConf, &getItemsResp, &conItemsResp); err != nil {
		return nil, err
	}

	//encode
	info := &kproto.LOBBY_SHOP_BUY_RESP{}
	info.GetItems = getItemsResp
	info.ConItems = conItemsResp
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_SHOP_BUY_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 商店内部购买
func ShopBuyInternal(userId string, shopItemConf *game_config.ShopItem, getItemsResp *[]*kproto.ItemInfo, conItemsResp *[]*kproto.ConsumeItemInfo) error {
	// 判断限购次数
	hasData := false
	shopItems := shop.GetShopItemBuyLimit(userId, shopItemConf.ShopID, shopItemConf.Order)
	// 如果是空就说明还没购买过
	if shopItems == nil {
		shopItems = shop.InitShopBuyLimit(userId, shopItemConf)
	} else {
		hasData = true
		if shopItemConf.Person_Limit > 0 {
			if shopItems.BuyNum >= shopItemConf.Person_Limit {
				return fmt.Errorf("out of limit num : -> shop_id: %v, item_id: %v", shopItemConf.ShopID, shopItemConf.ID)
			}
		}
	}

	// 消耗
	if err := ShopBuyConsumeItems(userId, shopItems, shopItemConf, conItemsResp); err != nil {
		return err
	}

	// 获得
	if err := ShopBuyGetItems(userId, shopItemConf, getItemsResp); err != nil {
		return err
	}

	// 把限购数据更新到mongo
	if shopItemConf.Person_Limit > 0 {
		shopItems.BuyNum++
		if hasData {
			if err := shop.UpdateShopItemBuyLimit(shopItems); err != nil {
				logrus.Warn(err)
			}
		} else {
			if err := shop.InsertShopItemBuyLimit(shopItems); err != nil {
				logrus.Warn(err)
			}
		}
	}

	return nil
}

// 商店购买先消耗道具
func ShopBuyConsumeItems(userId string, shopItems *cmongo.ShopBuyLimit, shopItemConf *game_config.ShopItem, conItemsResp *[]*kproto.ConsumeItemInfo) error {
	// 不是免费的话就判断购买货币是否充足，先判断梯度计价
	useStr := shopItemConf.Current_Consumer
	if useStr == "free" {
		return nil
	}
	if shopItemConf.Grad_Price > 0 {
		// 查询阶梯价格
		nextNum := shopItems.BuyNum + 1
		lqInfo := game_config.LadderQuotationConfigInstant.GetInfo(shopItemConf.Grad_Price)
		for _, q := range lqInfo {
			if q.BuyCountMin <= nextNum && nextNum <= q.BuyCountMax {
				useStr = q.Consume
				break
			}
		}
	}

	conTid, conNum, err := utils.ParseItem(useStr)
	if err != nil {
		return err
	}
	conInfo := item.LoadItemByUserTypeId(userId, conTid)
	if conInfo == nil || conInfo.Num < conNum {
		return fmt.Errorf("item num not enough : -> user_id: %v, item_id: %v", userId, conTid)
	}

	// 先消耗道具
	if err = item.ConsumeItemByIdx(conInfo.UserID, conInfo.ID, conInfo.Num, conNum); err != nil {
		return err
	}
	*conItemsResp = append(*conItemsResp, &kproto.ConsumeItemInfo{Id: conInfo.ID, TypeId: conInfo.TypeId, Num: conNum})

	return nil
}

// 商店购买获得道具
func ShopBuyGetItems(userId string, shopItemConf *game_config.ShopItem, getItemsResp *[]*kproto.ItemInfo) error {
	// 再获得道具
	getTid, getNum, err := utils.ParseItem(shopItemConf.Item_Info)
	if err != nil {
		return err
	}
	// 判断获得道具是否可以自动开启
	getConf := game_config.ItemConfigInstant.GetInfo(getTid)
	if getConf.IsAutoUse == 1 {
		if err = AutoUseItem(userId, getNum, getConf, getItemsResp); err != nil {
			return err
		}
	} else {
		itemInfo := item.GetInitItem(userId, getTid, getNum)
		*getItemsResp = append(*getItemsResp, &kproto.ItemInfo{Id: itemInfo.ID, TypeId: itemInfo.TypeId, Num: itemInfo.Num})
		if _, err = item.InsertUpdateItem(itemInfo); err != nil {
			return err
		}
	}

	return nil
}

// 自动使用道具（开宝箱）
func AutoUseItem(userId string, num int64, itemConf *game_config.ItemData, getItemsResp *[]*kproto.ItemInfo) error {
	if itemConf.DropId > 0 {
		var i int64
		for i = 0; i < num; i++ {
			if err := getItemDrop(userId, itemConf, getItemsResp); err != nil {
				return err
			}
		}
	}
	return nil
}
