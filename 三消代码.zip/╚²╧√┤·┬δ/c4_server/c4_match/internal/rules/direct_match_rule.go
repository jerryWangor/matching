package rules

import "c4_match/internal/store"

type DirectMatchRule struct{}

func (r DirectMatchRule) Match(user1, user2 *store.User) bool {
	return true
}

func (r DirectMatchRule) GetName() string {
	return "Direct"
}

func NewDirectMatchRule() DirectMatchRule {
	return DirectMatchRule{}
}
