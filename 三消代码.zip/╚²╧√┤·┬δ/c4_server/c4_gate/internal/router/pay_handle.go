package router

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_gate/gate_registry"
	"c4_gate/internal"
	"context"
	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"time"
)

// get order
func PayGetOrder(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_PAY_GET_ORDER_RESP_ID), &kproto.PAY_GET_ORDER_RESP{Code: -1})
		return
	}

	err := PayRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_PAY_GET_ORDER_RESP_ID), &kproto.PAY_GET_ORDER_RESP{Code: -2})
	}
}

// callback
func PayCallBack(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_PAY_CALLBACK_RESP_ID), &kproto.PAY_CALLBACK_RESP{Code: -1})
		return
	}

	err := PayRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_PAY_CALLBACK_RESP_ID), &kproto.PAY_CALLBACK_RESP{Code: -2})
	}
}

// check await order
func PayCheckAwaitOrder(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_PAY_CHECK_AWAIT_ORDER_RESP_ID), &kproto.PAY_CHECK_AWAIT_ORDER_RESP{Code: -1})
		return
	}

	err := PayRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_PAY_CHECK_AWAIT_ORDER_RESP_ID), &kproto.PAY_CHECK_AWAIT_ORDER_RESP{Code: -2})
	}
}

func PayRpc(kctx ktcp.Context) error {
	//get grpc service
	service, err := gate_registry.EtcdClient.GetServiceInDiscovery(gate_registry.PAY_SERVICE)
	if err != nil {
		return err
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return err
	}

	defer conn.Close()

	//client
	client := kproto.NewPayServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*30)
	defer cancel()

	//request
	resp, err := client.PayRpc(ctx, &kproto.SendReq{UserId: kctx.Session().ID().(string), Packet: &kproto.Packet{MsgId: kctx.Request().ID().(uint32), Data: kctx.Request().Data()}})
	if err != nil {
		return err
	}

	//respone
	kctx.SetResponseMessage(ktcp.NewMessage(resp.Packet.MsgId, resp.Packet.Data))
	return nil
}
