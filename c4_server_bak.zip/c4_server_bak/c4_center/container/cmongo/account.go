package cmongo

import "time"

type Account struct {
	ID           string    `bson:"_id"`           //idx
	UserID       string    `bson:"user_id"`       //用户名
	NickName     string    `bosn:"nick_name"`     //昵称
	Password     string    `bson:"pswd"`          //密码
	Platform     string    `bson:"platform"`      //平台
	Token        string    `bson:"token"`         //平台凭证
	RegisterTime time.Time `bson:"register_time"` //注册时间
	LoginTime    time.Time `bson:"login_time"`    //登陆时间
	LogoutTime   time.Time `bson:"logout_time"`   //登出时间
}
