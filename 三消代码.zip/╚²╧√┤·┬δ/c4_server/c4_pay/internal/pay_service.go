package internal

import (
	"c4_center/kproto"
	"c4_center/utils"
	"c4_pay/internal/handle/rpc"
	"context"
	"fmt"
)

type PayService struct {
	kproto.UnimplementedPayServiceServer
}

func (p *PayService) PayRpc(ctx context.Context, req *kproto.SendReq) (*kproto.SendResp, error) {
	f := func() (*kproto.SendResp, error) {
		defer utils.HandleCrash()

		switch req.Packet.MsgId {
		case uint32(kproto.MSG_PAY_GET_ORDER_REQ_ID):
			return rpc.GetOrder(req)
		case uint32(kproto.MSG_PAY_CALLBACK_REQ_ID):
			return rpc.CallBack(req)
		case uint32(kproto.MSG_PAY_CHECK_AWAIT_ORDER_REQ_ID):
			return rpc.CheckAwaitOrder(req)
		case uint32(kproto.MSG_PAY_ORDER_CHECK_REQ_ID):
			return rpc.OrderCheck(req)
		case uint32(kproto.MSG_PAY_ORDER_SUPPLE_REQ_ID):
			return rpc.OrderSupple(req)
		default:
			return nil, fmt.Errorf("msg -> %v not handle in lobby service", req.Packet.MsgId)
		}
	}

	return f()
}
