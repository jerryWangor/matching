package test

import (
	"bytes"
	"encoding/json"
	"fmt"
	"testing"
)

var ch chan int

func TestA(t *testing.T) {
	//var b interface{}
	//str := "hello world"
	//b = str[0]
	//switch b.(type) {
	//case byte:
	//	fmt.Println("byte")
	//default:
	//	fmt.Println("asdsa")
	//}

	//ch = make(chan int, 10)
	//go func() {
	//	ch <- 1
	//}()
	//
	//data, ok := <-ch
	//if ok {
	//	fmt.Println(data)
	//}
	//
	////fmt.Println(<-ch)
	//close(ch)
	//data, ok = <-ch
	//if ok {
	//	fmt.Println(data)
	//}
	//ch <- 2

	var data = []byte(`{"status": 200}`)
	var result struct {
		Status uint64 `json:"status"`
	}

	if err := json.NewDecoder(bytes.NewReader(data)).Decode(&result); err != nil {
		fmt.Println("error:", err)
		return
	}

	fmt.Printf("result => %+v", result) //prints: result => {Status:200}

}

//func TestAK(t *testing.T) {
//	t.Log("AK")
//}
//func TestB(t *testing.T) {
//	t.Log("B")
//}
//func TestC(t *testing.T) {
//	t.Log("C")
//}

func Benchmark_Add(b *testing.B) {
	var n int
	for i := 0; i < b.N; i++ {
		n++
	}
}
