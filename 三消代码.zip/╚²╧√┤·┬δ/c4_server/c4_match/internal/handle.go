package internal

import (
	"c4_center/container/cmongo"
	"c4_center/container/credis"
	"c4_center/khttp"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_match/internal/store"
	"context"
	"encoding/json"
	"fmt"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
)

func AddUser(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.MATCH_REQUEST_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	sessStr, err := kredis.GetStr(context.Background(), req.UserId)
	if err != nil {
		return nil, fmt.Errorf("do not have session of userid : %s;", req.UserId)
	}

	var sessData credis.SessionInfo
	if json.Unmarshal([]byte(sessStr), &sessData) != nil {
		return nil, fmt.Errorf("session unmarshal err of userid : %s;", req.UserId)
	}

	//己经在房间判断
	if len(sessData.RoomID) > 0 {
		//encode
		packet, err := getPacket(uint32(kproto.MSG_MATCH_REQUEST_RESP_ID), &kproto.MATCH_REQUEST_RESP{Code: 99, RoomId: sessData.RoomID, RoomAddr: sessData.RoomTcpAddress})
		if err != nil {
			return nil, err
		}

		logrus.Infof("%v has been in room -> %v", req.UserId, sessData.RoomID)
		return &kproto.SendResp{Packet: packet}, nil
	}

	if kmongo.Count(context.TODO(), kmongo.HeroCollection, bson.M{"user_id": req.UserId, "state": cmongo.ATTACK}) <= 0 {
		return nil, fmt.Errorf("do not have any attack heroes->%v", req.UserId)
	}

	//同名英雄判断
	if HasSameHero(req.UserId) {
		return nil, fmt.Errorf("has same hero  -> %v", req.UserId)
	}

	//匹配池类型判断
	matchMaking := MatchMakingPoolInstant.Get(reqData.Type)
	if matchMaking == nil {
		return nil, fmt.Errorf("cannot get match type -> %v", reqData.Type)
	}

	//add user to matchmaking
	matchMaking.AddUser(store.InitUser(req.UserId, reqData.Type))

	//encode
	packet, err := getPacket(uint32(kproto.MSG_MATCH_REQUEST_RESP_ID), &kproto.MATCH_REQUEST_RESP{})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//是否同名重复英雄
func HasSameHero(userId string) bool {
	//数据
	var hs []*cmongo.Hero
	kmongo.Get(context.TODO(), kmongo.HeroCollection, &hs, bson.M{"user_id": userId, "state": cmongo.ATTACK})

	for _, v := range hs {
		count := 0
		for _, vv := range hs {
			if v.Gene[0] == vv.Gene[0] {
				count++
			}

			if count >= 2 {
				return true
			}
		}
	}

	return false
}

func MatchCancel(req *kproto.SendReq) (*kproto.SendResp, error) {
	for _, v := range MatchMakingPoolInstant {
		v.RemoveUser(req.UserId)
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_MATCH_CANCEL_RESP_ID), &kproto.MATCH_CANCEL_RESP{})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

func NotFound(ctx khttp.Context) {
	// panic("11111111111111111")
	// fmt.Fprintln(ctx.ResponseWriter(), "not found.")
	logrus.Errorf("cant find router for url: %s", ctx.Request().URL)
}
