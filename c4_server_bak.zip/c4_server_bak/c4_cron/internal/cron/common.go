package cron

import (
	"c4_center/game_config"
	"c4_center/kproto"
	"c4_cron/cron_registry"
	"c4_cron/internal"
	"c4_cron/internal/service"
	"context"
	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"time"
)

const (
	ShopClose = iota
	ShopOpen
	ShopReset
	ShopChange
)

type ICron interface {
	Init()
	Run()    // cron run
	Begin()  // begin
	End()    // end
	Reset()  // reset reward
	Change() // reset reward
}

// 发送活动状态
func SendActivityState(t int32, state int32) {
	packet, _ := getPacket(uint32(kproto.MSG_GATE_ACTIVITY_NOTICE_ASYNC_RESP_ID), &kproto.GATE_ACTIVITY_NOTICE_ASYNC_RESP{Type: t, State: state})
	SendAllGate(packet)
}

// 发送商店状态
func SendShopState(t int32, state int32, nextTime int64) {
	// 更新mongo中的商店限购数据
	if err := service.DeleteBuyLimitByShopId(t); err != nil {
		logrus.Error(err)
		return
	}

	data := &kproto.GATE_SHOP_NOTICE_ASYNC_RESP{Id: t, State: state, Data: &kproto.SHOP_DATA{Id: t, NEXT_REFRESH_TIME: nextTime}}
	switch state {
	case ShopClose:
	case ShopOpen:
	case ShopReset:
		// 解析数据，把商店的数据初始化发给每个在线玩家
		shopData := game_config.ShopItemConfigInstant.GetShopItems(t)
		for _, v := range shopData {
			data.Data.Items = append(data.Data.Items, &kproto.SHOP_ITEM_DATA{Id: v.ID, BuyNum: 0, LimitNum: v.Person_Limit})
		}
	case ShopChange:
		// xxx
	}
	packet, _ := getPacket(uint32(kproto.MSG_GATE_SHOP_NOTICE_ASYNC_RESP_ID), data)
	SendAllGate(packet)
}

func SendAllGate(packet *kproto.Packet) {

	service, err := cron_registry.EtcdClient.GetAllServiceInDiscovery(cron_registry.GATE_SERVICE)
	if err != nil {
		logrus.Error(err)
		return
	}
	// 循环所有的网关服务
	for _, s := range service {
		//fmt.Println(s.Endpoints[0])
		conn, err := grpc.DialContext(context.Background(), s.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
		if err != nil {
			logrus.Error(err)
		}

		//client
		client := kproto.NewGateServiceClient(conn)

		//client timeout
		ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)

		//encode
		if _, err = client.GateRpc(ctx, &kproto.SendReq{UserId: "", Packet: packet}); err != nil {
			logrus.Error(err)
		}

		conn.Close()
		cancel()
	}
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := internal.Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
