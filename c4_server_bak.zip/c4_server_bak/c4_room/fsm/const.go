package fsm

type (
	//BusinessName Distinguish between different businesses
	BusinessName string
	State        int
	EventName    string
)
