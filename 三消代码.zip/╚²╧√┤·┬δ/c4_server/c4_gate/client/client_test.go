package client

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"math/rand"
	"net"
	"testing"
	"time"
)

// func TestClient(t *testing.T) {
// 	conn, err := net.Dial("tcp", "127.0.0.1:9000")
// 	if err != nil {
// 		panic(err)
// 	}

// 	packer := &ktcp.DefaultPacker{}
// 	codec := &ktcp.ProtobufCodec{}

// 	go func() {
// 		// for {
// 		req := &kproto.GATE_CONN_REQ{
// 			Userid:  "aaa",
// 			Session: "ab344eb3-8a98-4bdc-8d9f-925ce4dbb206",
// 		}
// 		data, err := codec.Encode(req)
// 		if err != nil {
// 			panic(err)
// 		}

// 		packedMsg, err := packer.Pack(ktcp.NewMessage(uint32(kproto.MSG_GATE_CONN_REQ_ID), data))
// 		if err != nil {
// 			panic(err)
// 		}
// 		if _, err := conn.Write(packedMsg); err != nil {
// 			panic(err)
// 		}
// 		logrus.Infof("send | id: %d; size: %d; data: %s", kproto.MSG_GATE_CONN_REQ_ID, len(data), req.String())
// 		time.Sleep(time.Second)
// 		// }
// 	}()

// 	i := 0
// 	for {
// 		msg, err := packer.Unpack(conn)
// 		if err != nil {
// 			panic(err)
// 		}
// 		var respData kproto.GATE_CONN_RESP
// 		if err := codec.Decode(msg.Data(), &respData); err != nil {
// 			panic(err)
// 		}
// 		i += 1
// 		logrus.Infof("recv | id: %d; size: %d; data: %s; count: %d", msg.ID(), len(msg.Data()), respData.String(), i)
// 	}

// }

var Packer = &ktcp.DefaultPacker{}
var Codec = &ktcp.ProtobufCodec{}

func SendPacket(conn net.Conn, msgId uint32, val interface{}) {
	data, err := Codec.Encode(val)
	if err != nil {
		panic(err)
	}

	packedMsg, err := Packer.Pack(ktcp.NewMessage(msgId, data))
	if err != nil {
		panic(err)
	}
	if _, err := conn.Write(packedMsg); err != nil {
		panic(err)
	}
}

func TestRoomClient(t *testing.T) {
	conn, err := net.Dial("tcp", "127.0.0.1:7001")
	if err != nil {
		panic(err)
	}

	rand.Seed(time.Now().Unix())
	go func() {

		SendPacket(conn, uint32(kproto.MSG_GATE_CONN_REQ_ID), &kproto.GATE_CONN_REQ{Userid: "aaaa", Session: "eyJVc2VySUQiOiJhYWFhIiwiU2Vzc2lvbiI6Ijc4MmM0Mzg4LTNlMTMtNGY4Mi1iMjdlLTI4Y2UxYWQ3MTRjNyIsIkdhdGVHcnBjUGF0aCI6IiJ9"})
		time.Sleep(5 * time.Second)

		SendPacket(conn, uint32(kproto.MSG_LOBBY_HERO_REQ_ID), &kproto.LOBBY_HERO_REQ{})
		time.Sleep(5 * time.Second)

		// for {
		// 	req := &kproto.BATTLE_ENTER_ROOM_REQ{
		// 		UserId: fmt.Sprintf("%v:%v", "aaa", rand.Int31()),
		// 		RoomId: "ab344eb3-8a98-4bda-8d9f-925ce4dbb206",
		// 		Bot:    1,
		// 	}
		// 	data, err := codec.Encode(req)
		// 	if err != nil {
		// 		panic(err)
		// 	}

		// 	packedMsg, err := packer.Pack(ktcp.NewMessage(uint32(kproto.MSG_BATTLE_ENTER_ROOM_REQ_ID), data))
		// 	if err != nil {
		// 		panic(err)
		// 	}
		// 	if _, err := conn.Write(packedMsg); err != nil {
		// 		panic(err)
		// 	}
		// 	logrus.Infof("send | id: %d; size: %d; data: %s", kproto.MSG_BATTLE_ENTER_ROOM_REQ_ID, len(data), req.String())
		// 	time.Sleep(time.Second * 5)
		// }

		// func() {
		// 	// swap
		// 	req := &kproto.BATTLE_MOVE_REQ{
		// 		MSource: &kproto.BallCoordinate{X: 3, Y: 6},
		// 		MTar:    &kproto.BallCoordinate{X: 4, Y: 6},
		// 	}

		// 	data, err := codec.Encode(req)
		// 	if err != nil {
		// 		panic(err)
		// 	}

		// 	packedMsg, err := packer.Pack(ktcp.NewMessage(uint32(kproto.MSG_BATTLE_MOVE_REQ_ID), data))
		// 	if err != nil {
		// 		panic(err)
		// 	}
		// 	if _, err := conn.Write(packedMsg); err != nil {
		// 		panic(err)
		// 	}
		// 	time.Sleep(time.Second * 5)
		// }()

		// func() {
		// 	// swap
		// 	req := &kproto.BATTLE_MOVE_REQ{
		// 		MSource: &kproto.BallCoordinate{X: 2, Y: 6},
		// 		MTar:    &kproto.BallCoordinate{X: 3, Y: 6},
		// 	}

		// 	data, err := codec.Encode(req)
		// 	if err != nil {
		// 		panic(err)
		// 	}

		// 	packedMsg, err := packer.Pack(ktcp.NewMessage(uint32(kproto.MSG_BATTLE_MOVE_REQ_ID), data))
		// 	if err != nil {
		// 		panic(err)
		// 	}
		// 	if _, err := conn.Write(packedMsg); err != nil {
		// 		panic(err)
		// 	}
		// 	time.Sleep(time.Second)
		// }()
	}()

	select {}
	// i := 0
	// for {
	// 	msg, err := packer.Unpack(conn)
	// 	if err != nil {
	// 		panic(err)
	// 	}

	// 	if msg.ID().(uint32) == 1006 {
	// 		var respData kproto.BATTLE_ENTER_ROOM_RESP
	// 		if err := codec.Decode(msg.Data(), &respData); err != nil {
	// 			panic(err)
	// 		}
	// 		i += 1
	// 		logrus.Infof("recv | id: %d; size: %d; data: %s; count: %d", msg.ID(), len(msg.Data()), respData.String(), i)
	// 	}

	// 	if msg.ID().(uint32) == 1007 {
	// 		var respData kproto.BATTLE_BOARD_RESP
	// 		if err := codec.Decode(msg.Data(), &respData); err != nil {
	// 			panic(err)
	// 		}
	// 		i += 1
	// 		logrus.Infof("recv | id: %d; size: %d; data: %s; count: %d", msg.ID(), len(msg.Data()), respData.String(), i)

	// 	}

	// 	if msg.ID().(uint32) == 1003 {
	// 		var respData kproto.BATTLE_MOVE_RESP
	// 		if err := codec.Decode(msg.Data(), &respData); err != nil {
	// 			panic(err)
	// 		}
	// 		i += 1
	// 		logrus.Infof("recv | id: %d; size: %d; data: %s; count: %d", msg.ID(), len(msg.Data()), respData.String(), i)
	// 	}

	// 	if msg.ID().(uint32) == 1008 {
	// 		var respData kproto.BATTLE_MOVE_ASYN_RESP
	// 		if err := codec.Decode(msg.Data(), &respData); err != nil {
	// 			panic(err)
	// 		}
	// 		i += 1
	// 		logrus.Infof("recv | id: %d; size: %d; data: %s; count: %d", msg.ID(), len(msg.Data()), respData.String(), i)
	// 	}

	// 	if msg.ID().(uint32) == 1004 {
	// 		var respData kproto.BATTLE_ELIMINATE_RESP
	// 		if err := codec.Decode(msg.Data(), &respData); err != nil {
	// 			panic(err)
	// 		}
	// 		i += 1
	// 		logrus.Infof("recv | id: %d; size: %d; data: %s; count: %d", msg.ID(), len(msg.Data()), respData.String(), i)
	// 	}
	// }

}
