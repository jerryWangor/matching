package utils

import (
	"crypto/rand"
	"fmt"
	"github.com/sirupsen/logrus"
	"math"
	"math/big"
	mrand "math/rand"
	"os"
	"time"
)

// ------------------------------------- 随机数 -----------------------------------------

// r 概率 min 最小 max 最大
func GetRandItemNum(r int32, min int64, max int64) int64 {
	if r <= 0 {
		return 0
	}
	if r == MaxRandPro {
		return GetRangeRandNum(min, max)
	} else {
		rnum := GetRangeRandNum(1, MaxRandPro)
		if rnum <= int64(r) {
			return GetRangeRandNum(min, max)
		} else {
			return 0
		}
	}
}

func GetRangeRandNum(min, max int64) int64 {
	if min == max {
		return min
	}
	if min > max {
		logrus.Warn("the min is greater than max!")
		min, max = max, min
	}

	if min < 0 {
		f64Min := math.Abs(float64(min))
		i64Min := int64(f64Min)
		result, _ := rand.Int(rand.Reader, big.NewInt(max+1+i64Min))

		return result.Int64() - i64Min
	} else {
		result, _ := rand.Int(rand.Reader, big.NewInt(max-min+1))
		return min + result.Int64()
	}
}

//生成24位订单号
//前面17位代表时间精确到毫秒，中间3位代表进程id，最后4位代表序号
func GetOrderId() string {
	t := time.Now()
	s := t.Format("20060102150405")
	m := t.UnixNano()/1e6 - t.UnixNano()/1e9*1e3
	ms := sup(m, 3)
	p := os.Getpid() % 1000
	ps := sup(int64(p), 3)
	//i := atomic.AddInt64(&num, int64(rand.Intn(10000)))
	i := int64(mrand.Intn(10000))
	r := i % 10000
	rs := sup(r, 4)
	return fmt.Sprintf("%s%s%s%s", s, ms, ps, rs)
}

//对长度不足n的数字前面补0
func sup(i int64, n int) string {
	m := fmt.Sprintf("%d", i)
	for len(m) < n {
		m = fmt.Sprintf("0%s", m)
	}
	return m
}
