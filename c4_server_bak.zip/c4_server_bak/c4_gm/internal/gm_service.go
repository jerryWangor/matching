package internal

import (
	"c4_center/kproto"
	"context"
)

type GmService struct {
	kproto.UnimplementedGmServiceServer
}

func (l *GmService) GmRpc(context.Context, *kproto.SendReq) (*kproto.SendResp, error) {
	return &kproto.SendResp{}, nil
}
