package match3

import (
	"fmt"
	"math"
	"math/rand"
	"time"

	"golang.org/x/exp/slices"
)

type Board struct {
	Row           int32
	Column        int32
	Pieces        [][]*Piece
	DeadCheckFunc []func(p *Piece) bool

	//回调
	NewPieceInvoke           func(piece []Piece)
	ClearPieceInvoke         func(piece Piece)
	SwapInvoke               func(sx, sy, dx, dy int32)
	ShuffleInvoke            func(sx, sy, dx, dy int32)
	ShuffleBeforeInvoke      func()
	OneOpeartionBeforeInvoke func() //一次操作开始(消除,下落,生成新棋子)
	OneOpeartionAfterInvoke  func() //一次操作完成
}

func NewBoard(row, column int32) *Board {
	ret := &Board{Column: column, Row: row}
	ret.Pieces = make([][]*Piece, row)

	for i := range ret.Pieces {
		ret.Pieces[i] = make([]*Piece, column)
	}

	ret.InitDeadCheckFunc()
	return ret
}

func (b *Board) InitBoard() {
	for i := 0; i < int(b.Row); i++ {
		for j := 0; j < int(b.Column); j++ {
			b.Pieces[i][j] = b.GetNewPiece(int32(i), int32(j))
		}
	}

	// b.Pieces[0][0].PType = 4
	// b.Pieces[0][1].PType = 1
	// b.Pieces[0][2].PType = 2
	// b.Pieces[0][3].PType = 5
	// b.Pieces[0][4].PType = 1
	// b.Pieces[0][5].PType = 2
	// b.Pieces[0][6].PType = 4
	// b.Pieces[0][7].PType = 1

	// b.Pieces[1][0].PType = 1
	// b.Pieces[1][1].PType = 3
	// b.Pieces[1][2].PType = 3
	// b.Pieces[1][3].PType = 2
	// b.Pieces[1][4].PType = 4
	// b.Pieces[1][5].PType = 3
	// b.Pieces[1][6].PType = 5
	// b.Pieces[1][7].PType = 2

	// b.Pieces[2][0].PType = 5
	// b.Pieces[2][1].PType = 5
	// b.Pieces[2][2].PType = 4
	// b.Pieces[2][3].PType = 1
	// b.Pieces[2][4].PType = 1
	// b.Pieces[2][5].PType = 5
	// b.Pieces[2][6].PType = 4
	// b.Pieces[2][7].PType = 3

	// b.Pieces[3][0].PType = 4
	// b.Pieces[3][1].PType = 5
	// b.Pieces[3][2].PType = 2
	// b.Pieces[3][3].PType = 5
	// b.Pieces[3][4].PType = 3
	// b.Pieces[3][5].PType = 2
	// b.Pieces[3][6].PType = 1
	// b.Pieces[3][7].PType = 5

	// b.Pieces[4][0].PType = 2
	// b.Pieces[4][1].PType = 3
	// b.Pieces[4][2].PType = 3
	// b.Pieces[4][3].PType = 2
	// b.Pieces[4][4].PType = 4
	// b.Pieces[4][5].PType = 3
	// b.Pieces[4][6].PType = 4
	// b.Pieces[4][7].PType = 3

	// b.Pieces[5][0].PType = 5
	// b.Pieces[5][1].PType = 3
	// b.Pieces[5][2].PType = 4
	// b.Pieces[5][3].PType = 5
	// b.Pieces[5][4].PType = 4
	// b.Pieces[5][5].PType = 2
	// b.Pieces[5][6].PType = 1
	// b.Pieces[5][7].PType = 4

	// b.Pieces[6][0].PType = 4
	// b.Pieces[6][1].PType = 2
	// b.Pieces[6][2].PType = 1
	// b.Pieces[6][3].PType = 2
	// b.Pieces[6][4].PType = 5
	// b.Pieces[6][5].PType = 3
	// b.Pieces[6][6].PType = 2
	// b.Pieces[6][7].PType = 5 //5

	// b.Pieces[7][0].PType = 5
	// b.Pieces[7][1].PType = 1
	// b.Pieces[7][2].PType = 5
	// b.Pieces[7][3].PType = 3
	// b.Pieces[7][4].PType = 1
	// b.Pieces[7][5].PType = 4
	// b.Pieces[7][6].PType = 4
	// b.Pieces[7][7].PType = 2
	////////////////////////////////////////
	// b.Pieces[7][0].PType = 5
	// b.Pieces[6][0].PType = 5
	// b.Pieces[5][1].PType = 5
}

//判断左,左左 & 下,下下是否同色
func (b *Board) GetNewPiece(i, j int32) *Piece {
	var except []int32

	left := b.GetPiece(i+LEFT.DirX, j+LEFT.DirY)
	leftleft := b.GetPiece(i+LEFT.DirX+LEFT.DirX, j+LEFT.DirY+LEFT.DirY)

	if left != nil && leftleft != nil && left.PType == leftleft.PType {
		except = append(except, left.PType)
	}

	down := b.GetPiece(i+DOWN.DirX, j+DOWN.DirY)
	downdown := b.GetPiece(i+DOWN.DirX+DOWN.DirX, j+DOWN.DirY+DOWN.DirY)
	if down != nil && downdown != nil && down.PType == downdown.PType {
		except = append(except, down.PType)
	}

	return NewPiece(int32(i), int32(j), b.GetRandomTypeExcept(except, RTYPES))
}

func (b *Board) IsDead() bool {
	for w := range b.Pieces {
		for h := range b.Pieces[w] {
			for _, v := range b.DeadCheckFunc {
				if v(b.Pieces[w][h]) {
					return false
				}
			}
		}
	}
	return true
}

func (b *Board) GetAutoMovePiece(index int, pi *Piece) (int32, int32) {
	switch index {
	case 0:
		return pi.PosX, pi.PosY + 1
	case 1:
		return pi.PosX, pi.PosY - 1
	case 2:
		return pi.PosX - 1, pi.PosY
	case 3:
		return pi.PosX + 1, pi.PosY
	case 4:
		return pi.PosX, pi.PosY + 1
	case 5:
		return pi.PosX, pi.PosY - 1
	case 6:
		return pi.PosX - 1, pi.PosY
	case 7:
		return pi.PosX + 1, pi.PosY
	case 8:
		return pi.PosX, pi.PosY + 1
	case 9:
		return pi.PosX, pi.PosY - 1
	case 10:
		return pi.PosX, pi.PosY - 1
	case 11:
		return pi.PosX, pi.PosY + 1
	case 12:
		return pi.PosX - 1, pi.PosY
	case 13:
		return pi.PosX + 1, pi.PosY
	case 14:
		return pi.PosX + 1, pi.PosY
	case 15:
		return pi.PosX - 1, pi.PosY
	}
	return -1, -1
}

func (b *Board) AutoMove(ptype int32, match bool) (*Piece, int32, int32) {
	for w := range b.Pieces {
		for h := range b.Pieces[w] {
			for k, v := range b.DeadCheckFunc {
				pi := b.Pieces[w][h]
				if v(pi) {
					tx, ty := b.GetAutoMovePiece(k, pi)
					if tx == -1 || ty == -1 {
						return nil, tx, ty
					}

					if match {
						if ptype == pi.PType {
							return pi, tx, ty
						}
					} else {
						return pi, tx, ty
					}
				}
			}
		}
	}
	return b.AutoMove(ptype, false)
}

func (b *Board) GetRandomTypeExcept(except []int32, ts []int32) int32 {
	var rest []int32

	for i := range ts {
		if slices.Contains(except, ts[i]) {
			continue
		}

		rest = append(rest, ts[i])
	}

	return rest[rand.Intn(len(rest))]
}

func (b *Board) GetPiece(x, y int32) *Piece {
	if b.CoordsInGrid(x, y) {
		return b.Pieces[x][y]
	}
	return nil
}

func (b *Board) SwapAuto(sx, sy, dx, dy int32) bool {
	if !b.SwapManual(sx, sy, dx, dy) {
		return false
	}

	//回调
	b.SwapInvoke(sx, sy, dx, dy)

	count := 1
	//循环消除
	for b.CanMatch() {
		//消除开始回调
		b.OneOpeartionBeforeInvoke()
		// fmt.Printf("----------------消除次数:%v--------------\n", count)

		//消除
		b.ClearMatches()
		// fmt.Println("消除后棋盘")
		// b.Print()

		//下落
		b.FallDown()
		// fmt.Println("下落后棋盘")
		// b.Print()

		//生成
		b.AutoCreateNewPiece()
		// fmt.Println("创建新棋子后棋盘")
		// b.Print()

		//消除结束回调
		b.OneOpeartionAfterInvoke()
		count++
	}

	//死局判定
	if b.IsDead() {
		b.ShuffleBeforeInvoke()
		b.Shuffle()
	}

	return true
}

func (b *Board) SwapManual(sx, sy, dx, dy int32) bool {
	if math.Abs(float64(sx-dx+sy-dy)) != 1 {
		return false
	}

	src := b.GetPiece(sx, sy)
	dst := b.GetPiece(dx, dy)

	if src == nil || dst == nil {
		return false
	}

	//修改方块数据
	dst.PosX, dst.PosY = sx, sy
	src.PosX, src.PosY = dx, dy
	//换位
	b.Pieces[sx][sy] = dst
	b.Pieces[dx][dy] = src

	//回滚
	if !b.CanMatch() {
		dst.PosX, dst.PosY = dx, dy
		src.PosX, src.PosY = sx, sy

		b.Pieces[sx][sy] = src
		b.Pieces[dx][dy] = dst
		return false
	}

	return true
}

func (b *Board) CoordsInGrid(x, y int32) bool {
	return x >= 0 && y >= 0 && x < b.Row && y < b.Column
}

func (b *Board) NeightbourOf(piece *Piece, direction *Direction) *Piece {
	return b.GetPiece(piece.RelativeCoordinates(direction, 1))
}

func (b *Board) GetMatches() []*Piece {
	var matches []*Piece

	for w := range b.Pieces {
		for h := range b.Pieces[w] {
			//去重
			tmp := b.DeepMatchingNeighbours(b.Pieces[w][h])
			for i := range tmp {
				if !slices.Contains(matches, tmp[i]) {
					matches = append(matches, tmp[i])
				}
			}
		}
	}

	return matches
}

func (b *Board) CanMatch() bool {
	return len(b.GetMatches()) > 0
}

func (b *Board) SetClearInvoke(f func(piece Piece)) {
	b.ClearPieceInvoke = f
}

func (b *Board) SetNewInvoke(f func(piece []Piece)) {
	b.NewPieceInvoke = f
}

func (b *Board) SetSwapInvoke(f func(sx, sy, dx, dy int32)) {
	b.SwapInvoke = f
}

func (b *Board) SetShuffleInvoke(f func(sx, sy, dx, dy int32)) {
	b.ShuffleInvoke = f
}

func (b *Board) SetShuffleBeforeInvoke(f func()) {
	b.ShuffleBeforeInvoke = f
}

func (b *Board) SetOneOpeartionBeforeInvoke(f func()) {
	b.OneOpeartionBeforeInvoke = f
}

func (b *Board) SetOneOpeartionAfterInvoke(f func()) {
	b.OneOpeartionAfterInvoke = f
}

func (b *Board) ClearMatches() {
	for _, v := range b.GetMatches() {
		//己清除棋子回调
		b.ClearPieceInvoke(*v)
		v.PType = 0
	}
}

func (b *Board) DeepMatchingNeighbours(piece *Piece) (ret []*Piece) {
	src := b.MatchingNeighbours(piece)

	var row, col []*Piece
	for i := range src {
		if src[i].PosX == piece.PosX && b.CheckIntrval(false, piece, src[i]) {
			row = append(row, src[i])
		}

		if src[i].PosY == piece.PosY && b.CheckIntrval(true, piece, src[i]) {
			col = append(col, src[i])
		}
	}

	if len(row) > 2 {
		ret = append(ret, row...)
	}

	if len(col) > 2 {
		ret = append(ret, col...)
	}

	return
}

func (b *Board) CheckIntrval(checkX bool, start *Piece, end *Piece) bool {
	f := func(horzizontal bool, startIndex, endIndex int32) bool {
		if startIndex > endIndex {
			startIndex, endIndex = endIndex, startIndex
		}

		for i := startIndex + 1; i < endIndex; i++ {
			var tmp *Piece

			if horzizontal {
				tmp = b.GetPiece(i, start.PosY)
			} else {
				tmp = b.GetPiece(start.PosX, i)
			}

			if tmp == nil || tmp.PType != start.PType {
				return false
			}
		}
		return true
	}

	if checkX {
		return f(checkX, start.PosX, end.PosX)
	} else {
		return f(checkX, start.PosY, end.PosY)
	}
}

func (b *Board) MatchingNeighbours(piece *Piece) []*Piece {
	var ret []*Piece

	var rc func(piece *Piece)

	rc = func(piece *Piece) {
		if slices.Contains(ret, piece) {
			return
		}

		ret = append(ret, piece)
		dirs := []*Piece{b.GetPiece(piece.RelativeCoordinates(UP, 1)), b.GetPiece(piece.RelativeCoordinates(DOWN, 1)), b.GetPiece(piece.RelativeCoordinates(LEFT, 1)), b.GetPiece(piece.RelativeCoordinates(RIGHT, 1))}
		for i := range dirs {
			if dirs[i] != nil && piece.PType == dirs[i].PType {
				rc(dirs[i])
			}
		}
	}

	rc(piece)

	return ret
}

func (b *Board) FallDown() {
	for i := 0; i < int(b.Column); i++ {
		var drop []*Piece

		for j := 0; j < int(b.Row); j++ {
			if b.Pieces[j][i].PType != 0 {
				drop = append(drop, b.Pieces[j][i])
			}
		}

		for k := 0; k < len(drop); k++ {
			if drop[k].PosX == int32(k) {
				continue
			}

			b.Pieces[drop[k].PosX][drop[k].PosY] = NewPiece(0, 0, 0)
			drop[k].PosX = int32(k)
			b.Pieces[drop[k].PosX][drop[k].PosY] = drop[k]
		}
	}
}

func (b *Board) AutoCreateNewPiece() {
	for i := 0; i < int(b.Column); i++ {
		var drop []Piece

		for j := 0; j < int(b.Row); j++ {
			if b.Pieces[j][i].PType == 0 {
				n := NewPiece(int32(j), int32(i), RTYPES[rand.Intn(len(RTYPES))])
				b.Pieces[j][i] = n
				drop = append(drop, *n)
			}
		}

		//新生成棋子回调
		b.NewPieceInvoke(drop)
	}
}

//判断左,左左 & 下,下下是否同色
func (b *Board) ShuffleGetNewPiece(i, j int32, ts []*Piece) int {
	var except []int32

	left := b.GetPiece(i+LEFT.DirX, j+LEFT.DirY)
	leftleft := b.GetPiece(i+LEFT.DirX+LEFT.DirX, j+LEFT.DirY+LEFT.DirY)
	if left != nil && leftleft != nil && left.PType == leftleft.PType {
		except = append(except, left.PType)
	}

	down := b.GetPiece(i+DOWN.DirX, j+DOWN.DirY)
	downdown := b.GetPiece(i+DOWN.DirX+DOWN.DirX, j+DOWN.DirY+DOWN.DirY)
	if down != nil && downdown != nil && down.PType == downdown.PType {
		except = append(except, down.PType)
	}

	for i := range ts {
		if b.ContainsPieceType(except, ts[i]) {
			continue
		}
		return i
	}

	return 0
}

func (b *Board) Shuffle() {
	var ts []*Piece

	for ri := range b.Pieces {
		for ci := range b.Pieces[ri] {
			ts = append(ts, b.Pieces[ri][ci])
			b.Pieces[ri][ci] = nil
		}
	}

	//乱序
	ShuffleSlice(ts)

	for i := 0; i < int(b.Row); i++ {
		for j := 0; j < int(b.Column); j++ {
			//随机一个符合规则的下标
			index := b.ShuffleGetNewPiece(int32(i), int32(j), ts)
			//回调
			b.ShuffleInvoke(ts[index].PosX, ts[index].PosY, int32(i), int32(j))
			// b.ShuffleInfo.Coors = append(b.ShuffleInfo.Coors, &kproto.ShuffleCoordinate{Src: &kproto.BallCoordinate{X: ts[index].PosX, Y: ts[index].PosY}, Dst: &kproto.BallCoordinate{X: int32(i), Y: int32(j)}})
			//改变原有x,y
			ts[index].PosX, ts[index].PosY = int32(i), int32(j)
			b.Pieces[i][j] = ts[index]
			//移除己使用的piece
			ts = append(ts[:index], ts[index+1:]...)
		}
	}
}

func (b *Board) ContainsPieceType(elems []int32, v *Piece) bool {
	for _, s := range elems {
		if v.PType == s {
			return true
		}
	}
	return false
}

func (b *Board) Print() {
	fmt.Print("   ")
	for i := 0; i < int(b.Column); i++ {
		fmt.Printf(" {%v}", i)
	}

	fmt.Println()
	for i := 0; i < int(b.Column); i++ {
		fmt.Print("-----")
	}
	fmt.Println()
	for i := b.Row - 1; i >= 0; i-- {
		fmt.Printf("{%v}  ", i)
		for j := 0; j < int(b.Column); j++ {
			fmt.Printf("%v | ", b.Pieces[i][j].PType)
			// fmt.Printf("%v:%v->%v | ", b.Pieces[i][j].PosX, b.Pieces[i][j].PosY, b.Pieces[i][j].PType)
		}
		fmt.Println()
	}
	fmt.Println()
}

func ShuffleSlice[T any](slice []T) {
	r := rand.New(rand.NewSource(time.Now().Unix()))
	for len(slice) > 0 {
		n := len(slice)
		randIndex := r.Intn(n)
		slice[n-1], slice[randIndex] = slice[randIndex], slice[n-1]
		slice = slice[:n-1]
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////

func (b *Board) InitDeadCheckFunc() {
	f := func(i, j, x, y int32, piece *Piece) bool {
		p1 := b.GetPiece(i, j)
		p2 := b.GetPiece(x, y)
		return piece != nil && p1 != nil && p2 != nil && p1.PType == p2.PType && p1.PType == piece.PType
	}

	// type 1
	//    x
	// #  o
	//    x
	//
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+1, p.PosY+1, p.PosX-1, p.PosY+1, p)
	})

	// type 2
	//    x
	//    o  #
	//    x
	//
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+1, p.PosY-1, p.PosX-1, p.PosY-1, p)
	})

	// type 3
	//     #
	//  x  o  x
	//
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX-1, p.PosY-1, p.PosX-1, p.PosY+1, p)
	})

	// type 4
	//
	//  x  o  x
	//     #
	//
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+1, p.PosY-1, p.PosX+1, p.PosY+1, p)
	})
	// type 5
	//
	//  #  o  x  x
	//
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX, p.PosY+2, p.PosX, p.PosY+3, p)
	})

	// type 6
	//
	//  x  x  o  #
	//
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX, p.PosY-2, p.PosX, p.PosY-3, p)
	})

	// type 7
	//   #
	//   o
	//   x
	//   x
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX-2, p.PosY, p.PosX-3, p.PosY, p)
	})

	// type 8
	//    x
	//    x
	// 	  o
	//    #
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+2, p.PosY, p.PosX+3, p.PosY, p)
	})

	// type 9
	//    x
	//    x
	// #  o
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+1, p.PosY+1, p.PosX+2, p.PosY+1, p)
	})

	// type 10
	//    x
	//    x
	//	  o  #
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+1, p.PosY-1, p.PosX+2, p.PosY-1, p)
	})

	// type 11
	//    o  #
	//    x
	//    x
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX-1, p.PosY-1, p.PosX-2, p.PosY-1, p)
	})

	// type 12
	//   #  o
	//      x
	//      x
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX-1, p.PosY+1, p.PosX-2, p.PosY+1, p)
	})

	// type 13
	//   #
	//   o  x  x
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX-1, p.PosY+1, p.PosX-1, p.PosY+2, p)
	})

	// type 14
	//
	//   o  x  x
	//   #
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+1, p.PosY+1, p.PosX+1, p.PosY+2, p)
	})

	// type 15
	//   x  x  o
	//         #
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX+1, p.PosY-1, p.PosX+1, p.PosY-2, p)
	})

	// type 16
	//         #
	//   x  x  o
	b.DeadCheckFunc = append(b.DeadCheckFunc, func(p *Piece) bool {
		return f(p.PosX-1, p.PosY-1, p.PosX-1, p.PosY-2, p)
	})

}
