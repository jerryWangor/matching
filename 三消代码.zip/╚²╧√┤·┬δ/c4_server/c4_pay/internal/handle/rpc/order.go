package rpc

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kproto"
	"c4_center/utils"
	"c4_pay/internal/service"
	"encoding/json"
	"fmt"
	"github.com/sirupsen/logrus"
	"strconv"
	"strings"
)

// get order
func GetOrder(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.PAY_GET_ORDER_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	// 获取商店配置
	shopItemConf := game_config.ShopItemConfigInstant.GetItem(reqData.ShopId, reqData.ItemId)
	if shopItemConf == nil {
		return nil, fmt.Errorf("shop item not found : -> shop_id: %v, item_id: %v", reqData.ShopId, reqData.ItemId)
	}
	// 根据product_id判断是不是充值物品
	if len(shopItemConf.Product_ID) == 0 {
		return nil, fmt.Errorf("shop item is not pay item : -> shop_id: %v, item_id: %v", reqData.ShopId, reqData.ItemId)
	}

	getTid, getNum, err := utils.ParseItem(shopItemConf.Item_Info)
	if err != nil {
		return nil, err
	}
	_, conNum, err := utils.ParseItem(shopItemConf.Current_Consumer)
	if err != nil {
		return nil, err
	}

	// 查询钱包地址
	account := service.GetAccount(req.UserId)
	if account == nil {
		return nil, fmt.Errorf("account is nil")
	}

	// 每个用户每隔五秒才能生成一个新订单
	orderId := utils.GetOrderId()
	// 判断orderId是否存在，防止连续点击
	hasOrder := service.GetPayOrder(orderId)
	if hasOrder != nil {
		return nil, fmt.Errorf("order exists")
	}

	payOrder := service.InitPayOrder(req.UserId, account.Token, orderId, getTid, getNum, CurrencyType, conNum)
	if err := service.InsertPayOrder(payOrder); err != nil {
		return nil, err
	}

	//encode
	info := &kproto.PAY_GET_ORDER_RESP{}
	info.OrderId = orderId
	packet, err := getPacket(uint32(kproto.MSG_PAY_GET_ORDER_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 客户端回调发货
func CallBack(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.PAY_CALLBACK_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	// 检查参数
	if err := checkParams(reqData.OrderId, reqData.HashData); err != nil {
		return nil, err
	}

	// 查询充值订单
	order := service.GetPayOrder(reqData.OrderId)
	if err := checkOrderCondition(order, reqData.HashData); err != nil {
		return nil, err
	}

	getItemsResp := make([]*kproto.ItemInfo, 0) //获得的道具返回信息
	order.HashData = reqData.HashData
	if err := verifyOrderAndSave(order, false); err != nil {
		// 判断是链上检查失败，需要给客户端返回获取空道具
		if err.Error() != "check_fail" {
			return nil, err
		}
	} else {
		if err := sendReward(req.UserId, order, &getItemsResp); err != nil {
			return nil, err
		}
	}

	//encode
	info := &kproto.PAY_CALLBACK_RESP{}
	info.GetItems = getItemsResp
	packet, err := getPacket(uint32(kproto.MSG_PAY_CALLBACK_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 登录游戏检查有没有没完成的充值订单（暂时没用到了）
func CheckAwaitOrder(req *kproto.SendReq) (*kproto.SendResp, error) {
	return nil, nil
	getItemsResp := make([]*kproto.ItemInfo, 0) //获得的道具返回信息

	// 查询支付成功但没有完成的订单
	orders := service.GetPayOrderByAwait(req.UserId)
	for i, _ := range orders {
		// 验证订单
		if err := verifyOrderAndSave(orders[i], false); err != nil {
			return nil, err
		}
		// 发货
		if err := sendReward(req.UserId, orders[i], &getItemsResp); err != nil {
			return nil, err
		}
	}

	//encode
	info := &kproto.PAY_CHECK_AWAIT_ORDER_RESP{}
	info.GetItems = getItemsResp
	packet, err := getPacket(uint32(kproto.MSG_PAY_CHECK_AWAIT_ORDER_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 订单检查
func OrderCheck(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.PAY_ORDER_CHECK_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	// 检查参数
	if err := checkParams(reqData.OrderId, reqData.HashData); err != nil {
		return nil, err
	}

	order := service.GetPayOrder(reqData.OrderId)
	if err := checkOrderCondition(order, reqData.HashData); err != nil {
		return nil, err
	}

	// 检查链上数据
	order.HashData = reqData.HashData
	if f, _ := verifyOrderStatus(order); !f {
		return nil, fmt.Errorf("hash data not in bsc chain")
	}

	info := &kproto.PAY_ORDER_CHECK_RESP{}
	info.Msg = "this order can be supplement"
	packet, err := getPacket(uint32(kproto.MSG_PAY_ORDER_CHECK_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 订单补单
func OrderSupple(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.PAY_ORDER_SUPPLE_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	// 检查参数
	if err := checkParams(reqData.OrderId, reqData.HashData); err != nil {
		return nil, err
	}

	order := service.GetPayOrder(reqData.OrderId)
	if err := checkOrderCondition(order, reqData.HashData); err != nil {
		return nil, err
	}

	// 补单发货
	getItemsResp := make([]*kproto.ItemInfo, 0) //获得的道具返回信息

	order.HashData = reqData.HashData
	if err := verifyOrderAndSave(order, true); err != nil {
		return nil, err
	}
	if err := sendReward(order.UserID, order, &getItemsResp); err != nil {
		return nil, err
	}

	//encode
	info := &kproto.PAY_ORDER_CHECK_RESP{}
	info.Msg = "supplement success"
	packet, err := getPacket(uint32(kproto.MSG_PAY_ORDER_SUPPLE_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 去链上验证订单状态并保存
func verifyOrderAndSave(order *cmongo.PayOrder, isSupple bool) error {

	f, str := verifyOrderStatus(order)
	if f {
		order.ResultInfo = str
		order.Result = 1
		order.PayTime = utils.GetNowTime()

		// 补单
		if isSupple {
			order.IsSupple = SuppleSuccess
		}
	} else {
		return fmt.Errorf("check_fail")
	}

	// 保存订单
	if err := service.UpdatePayOrder(order); err != nil {
		return err
	}

	return nil
}

// 检查订单hash是否成功写入链上
func verifyOrderStatus(order *cmongo.PayOrder) (bool, string) {
	// 查询用户最近充值成功的记录
	result, err := getBSCAccountTxList(order.Token)
	if err != nil {
		logrus.Error(err)
		return false, ""
	}

	// 循环判断是否在成功充值列表中，判断标准：from=自己的token  to=钱包充值到的地址  value=充值金额
	if result.Status == "1" && result.Message == "OK" {
		for _, i := range result.Result {
			valueInt, _ := strconv.ParseInt(i.Value, 10, 64)
			value := valueInt / GWeiInternal
			if i.Hash == order.HashData && strings.ToLower(i.From) == strings.ToLower(order.Token) && strings.ToLower(i.To) == strings.ToLower(QBTargetAddress) && value == order.CurrencyNum {
				rJson, _ := json.Marshal(i)
				return true, string(rJson)
			}
		}
	}

	return false, ""
}

// 发货
func sendReward(userId string, order *cmongo.PayOrder, getItemsResp *[]*kproto.ItemInfo) error {
	if order.Result == 1 {
		item := service.GetInitItem(userId, order.ItemId, order.ItemNum)
		num, err := service.InsertUpdateItem(item)
		if err != nil {
			return err
		}
		*getItemsResp = append(*getItemsResp, &kproto.ItemInfo{TypeId: item.TypeId, Num: num})
	}
	return nil
}

// 补单时内部检查订单状态
func checkOrderCondition(order *cmongo.PayOrder, hashData string) error {
	if order == nil {
		return fmt.Errorf("order not exist")
	}
	// 判断是否发货
	if order.Result == PaySuccess {
		return fmt.Errorf("this order is success")
	}
	// 判断是否补单
	if order.IsSupple == SuppleSuccess {
		return fmt.Errorf("this order has been supplement")
	}
	// 判断订单的hashdata是不是等于传入的hashdata
	if len(order.HashData) > 0 && order.HashData != hashData {
		return fmt.Errorf("hash data error -> %v -- %v", order.HashData, hashData)
	}
	// 先查询历史订单里面是否有相同的hashdata（不是自己的或者该hash订单已经完成）
	hasOrder := service.GetPayOrderByHashData(hashData)
	if hasOrder != nil {
		if hasOrder.Result == PaySuccess {
			return fmt.Errorf("this hashdata order is successed")
		}
		if hasOrder.Token == order.Token {
			// 如果是自己的订单并且orderid不相等
			if hasOrder.OrderId != order.OrderId {
				return fmt.Errorf("this hashdata has been used")
			}
		} else {
			// 如果hashdata已经被别人用过了
			return fmt.Errorf("this hashdata has been used")
		}
	}

	return nil
}

func checkParams(orderId string, hashData string) error {
	if len(orderId) != cmongo.ORDER_ID_LENGTH {
		return fmt.Errorf("order id error -> %v", orderId)
	}
	if len(hashData) == 0 {
		return fmt.Errorf("hash data error -> %v", hashData)
	}
	return nil
}
