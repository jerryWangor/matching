package gm_registry

import (
	"c4_center/registry"
	"c4_center/registry/discovery"
	"c4_center/registry/etcd"
	"context"
	"fmt"
	"math/rand"

	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
)

var (
	PAY_SERVICE  string = "pay-grpc"
	GATE_SERVICE string = "gate-grpc"
	ROOM_SERVICE string = "room-grpc"
	EtcdClient   *GmRegistry
)

type GmRegistry struct {
	ctx       context.Context
	client    *etcd.Registry
	discovery *discovery.Discovery
}

func InitGmRegistry(config clientv3.Config, opts ...etcd.Option) {
	cli, err := clientv3.New(config)
	if err != nil {
		logrus.Fatal(err)
	}

	EtcdClient = &GmRegistry{ctx: context.TODO(), client: etcd.New(cli, opts...), discovery: discovery.NewDiscovery()}
}

func (g *GmRegistry) Register(service *registry.ServiceInstance) error {
	return g.client.Register(g.ctx, service)
}

func (g *GmRegistry) Deregister(service *registry.ServiceInstance) error {
	return g.client.Deregister(g.ctx, service)
}

func (g *GmRegistry) getService(name string) (*registry.ServiceInstance, error) {
	infos, err := g.client.GetService(g.ctx, name)
	if err != nil {
		return nil, err
	}

	if len(infos) <= 0 {
		return nil, fmt.Errorf("service of %s :  is empty", name)
	}

	return infos[rand.Intn(len(infos))], nil
}

func (g *GmRegistry) GetServiceInDiscovery(name string) (*registry.ServiceInstance, error) {
	node := g.discovery.PickNode(name)
	if node == nil {
		logrus.Errorf("cannot get service ->  %v", name)
		return g.getService(name)
	}
	return node, nil
}

//-------------------------------------------get all by name ------------------------------------------
func (g *GmRegistry) getAllServicesByName(name string) ([]*registry.ServiceInstance, error) {
	infos, err := g.client.GetService(g.ctx, name)
	if err != nil {
		return nil, err
	}

	if len(infos) <= 0 {
		return nil, fmt.Errorf("service of %s :  is empty", name)
	}

	return infos, nil
}

func (g *GmRegistry) GetAllServicesInDiscovery(name string) ([]*registry.ServiceInstance, error) {
	node := g.discovery.GetAllNode(name)
	if node == nil {
		logrus.Errorf("cannot get service ->  %v", name)
		return g.getAllServicesByName(name)
	}
	return node, nil
}

func (g *GmRegistry) Watch(name string) {
	w, err := g.client.Watch(g.ctx, name)
	if err != nil {
		logrus.Fatal(err)
		return
	}

	//init
	res, err := w.Next()
	if err != nil {
		logrus.Fatal(err)
		return
	}

	g.discovery.RefreshNode(name, res...)

	//loop watch
	go func() {
		for {
			res, err := w.Next()
			if err != nil {
				logrus.Error(err)
				return
			}

			g.discovery.RefreshNode(name, res...)
		}
	}()
}
