package condition

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kmongo"
	"c4_center/kredis"
	"c4_center/utils"
	"context"
	"fmt"
	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"strconv"
	"time"
)

// 检查条件
func CheckCondition(userId string, ids []int32) bool {
	flag := false
	// 查询条件类型
	for i := 0; i < len(ids); i++ {
		// 判断条件类型
		cInfo := game_config.ConditionalOfShelfConfigInstant.GetConditionalOfShelfs(ids[i])
		switch cInfo.ConditionalType {
		case game_config.ConditionaType_Grade:
			flag = CheckGrade(userId, cInfo)
		}

		if !flag {
			break
		}
	}

	return flag
}

// 检查段位等级
func CheckGrade(userId string, cInfo *game_config.ConditionalOfShelfData) bool {
	// 从条件表里面查询
	min, max, err := utils.ParseMinMax(cInfo.ConditionalParameters)
	if err != nil {
		logrus.Error(err)
		return false
	}

	// 从redis中查询是否存在
	grade, _ := kredis.GetStr(context.TODO(), userId+"_Grade")
	var gradeId int64
	if grade == "" {
		// 查询玩家段位等级
		var rankInfo cmongo.PlayerRankInfo
		kmongo.GetOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rankInfo, bson.M{"user_id": userId})
		if len(rankInfo.ID) <= 0 {
			logrus.Error("can not get rank info -> userid: %v", userId)
			return false
		}
		gradeId = int64(game_config.PvPSegmentConfigInstant.GetNowInfo(rankInfo.Rank_1.Score).Grad)
		if err := kredis.SetStr(context.TODO(), userId+"_Grade", fmt.Sprintf("%v", gradeId), 5*time.Second); err != nil {
			return false
		}
	} else {
		gradeId, _ = strconv.ParseInt(grade, 10, 64)
	}

	if min <= gradeId && gradeId <= max {
		return true
	}

	return false
}
