package battle

import (
	"c4_center/game_config"
	"math/rand"

	"golang.org/x/exp/slices"
)

//获取目标heros
func GetTargetHeros(effectId int32, srcHero *BattleHero, srcHeros, dstHeros []*BattleHero) []*BattleHero {
	effect := game_config.SkillEffectConfigInstant.GetInfo(effectId)
	ret := &ScopeHero{}
	//大类
	setScopeBig(ret, effect.Targe, srcHero, srcHeros, dstHeros)
	//小类
	setScopeSmall(ret, effect.TargetType, effect.TargetParam)
	//范围
	setScope(ret, effect.SkillScope)

	return ret.final
}

//得到效果值
func GetEffectValue(effectId int32, src, dst *BattleHero) int32 {
	effect := game_config.SkillEffectConfigInstant.GetInfo(effectId)
	if effect == nil {
		return 0
	}

	switch effect.EffectType {
	case 1, 2, 3:
		return getValue(effectId, src, dst)
	}
	return 0
}

//伤害数值=伤害来源属性数值 * 技能伤害系数
func getValue(effectId int32, src, dst *BattleHero) int32 {
	effect := game_config.SkillEffectConfigInstant.GetInfo(effectId)

	var baseValue int32
	//属性来源 1.施法方 2.目标方
	switch effect.EffectParam[1] {
	case 1: //施法方
		baseValue = getBaseValue(effect.EffectParam[2], src)
	case 2: //目标
		baseValue = getBaseValue(effect.EffectParam[2], dst)
	}

	return int32(float64(baseValue) * getValCoe(effectId))
}

//伤害来源属性数值
func getBaseValue(pid int32, hero *BattleHero) int32 {
	switch pid {
	case 1:
		return hero.GetMaxHP() //生命上限
	case 3:
		return hero.CurHp //当前生命
	case 5:
		return hero.GetMaxHP() - hero.CurHp //己损失生命
	case 7:
		return hero.GetAttack() //攻击力
	case 9:
		return hero.CurShield //当前护盾
	}
	return 0
}

//技能系数
func getValCoe(effectId int32) float64 {
	effect := game_config.SkillEffectConfigInstant.GetInfo(effectId)
	//加成方式 1.固定值 2.万分比
	switch effect.EffectParam[0] {
	case 1:
		return float64(effect.EffectParam[3])
	case 2:
		return float64(effect.EffectParam[3]) / float64(ratio)
	}
	return 0
}

type ScopeHero struct {
	small []*BattleHero //小类筛选
	big   []*BattleHero //大类筛选
	final []*BattleHero //最终目标
	all   []*BattleHero //双方所有英雄
}

func (s *ScopeHero) AddAll(hero ...*BattleHero) {
	s.all = append(s.all, hero...)
}

func (s *ScopeHero) AddBig(hero ...*BattleHero) {
	s.big = append(s.big, hero...)
}
func (s *ScopeHero) AddBigExcept(except *BattleHero, heros ...*BattleHero) {
	for i := range heros {
		if heros[i].ID == except.ID {
			continue
		}
		s.AddBig(heros[i])
	}
}

func (s *ScopeHero) AddSmall(pos ...*BattleHero) {
	s.small = append(s.small, pos...)
}

//srcHero  攻击发出者
//srcHeros 攻击发出方所有英雄
//dstHeros 防守方所有英雄
//btype    目标大类
//1.自己 2.己方 3.己方(不含自己) 4.敌方 5.全体 6.继承前置效果目标 7.最近攻击自己的目标 8.最近自己攻击的目标
func setScopeBig(ret *ScopeHero, btype int32, srcHero *BattleHero, srcHeros, dstHeros []*BattleHero) {
	ret.AddAll(srcHeros...)
	ret.AddAll(dstHeros...)

	switch btype {
	case 1:
		ret.AddBig(srcHero)
	case 2:
		ret.AddBig(srcHeros...)
	case 3:
		ret.AddBigExcept(srcHero, srcHeros...)
	case 4:
		ret.AddBig(dstHeros...)
	case 5:
		ret.AddBig(srcHeros...)
		ret.AddBig(dstHeros...)
	case 6:
	case 7:
	case 8:
	}
}

//stype    目标小类
//num      目标数量
//1.随机  2.前排随机 3.后排随机 4.生命最低 5.攻击最高 6.职业1 7.职业2 8.职业3 9.职业4 10.站位最小
func setScopeSmall(ret *ScopeHero, stype, num int32) {
	for i := 1; i <= int(num); i++ {
		if len(ret.big) <= 0 {
			continue
		}

		switch stype {
		case 1:
			setRandHero(ret)
		case 2:
			setRandPos(ret, []int32{1, 2, 3})
		case 3:
			setRandPos(ret, []int32{4, 5, 6})
		case 4:
			setLowestHpHero(ret)
		case 5:
			setBestAttHero(ret)
		case 6:
			setRandHeroByType(ret, game_config.Vocation_Tank)
		case 7:
			setRandHeroByType(ret, game_config.Vocation_Mage)
		case 8:
			setRandHeroByType(ret, game_config.Vocation_Ranger)
		case 9:
			setRandHeroByType(ret, game_config.Vocation_Support)
		case 10:
			setMinPos(ret)
		}
	}

	//默认小类型查找
	if stype != 10 && len(ret.small) <= 0 {
		setScopeSmall(ret, 10, num)
	}

}

//stype 1.单体 2.十字 3.周围
//效果范围
func setScope(ret *ScopeHero, stype int32) {
	for i, v := range ret.small {
		var s []int32

		//根据效果目标的位置来获取范围位置
		switch stype {
		case 1: //单体
			ret.final = append(ret.final, ret.small[i])
		case 2: //十字
			s = getCrossScope(v.Pos)
		case 3: //周围
			s = getAroundScope(v.Pos)
		}

		//将所选择位置英雄放和队列. 效果目标的位置的hero和范围选取hero的userid必须一致
		for ii, vv := range ret.all {
			if slices.Contains(s, vv.Pos) && v.UserID == vv.UserID {
				ret.final = append(ret.final, ret.all[ii])
			}
		}
	}

}

//十字范围
func getCrossScope(pos int32) []int32 {
	var ret []int32

	if pos <= 3 {
		ret = append(ret, 1, 2, 3, pos+3)
	}

	if pos > 3 {
		ret = append(ret, 4, 5, 6, pos-3)
	}

	return ret
}

//周围范围
func getAroundScope(pos int32) []int32 {
	var ret []int32

	switch pos {
	case 1, 4:
		ret = append(ret, 1, 2, 4, 5)
	case 2, 5:
		ret = append(ret, 1, 2, 3, 4, 5, 6)
	case 3, 6:
		ret = append(ret, 2, 3, 5, 6)
	}
	return ret
}

//随机
func setRandHero(ret *ScopeHero) {
	//随机对象增加至small,并将big内对应对象移除
	index := rand.Intn(len(ret.big))
	ret.AddSmall(ret.big[index])
	ret.big = append(ret.big[:index], ret.big[index+1:]...)
}

//前排随机/后排随机
func setRandPos(ret *ScopeHero, pos []int32) {
	var poslist []int
	for i, v := range ret.big {
		if slices.Contains(pos, v.Pos) {
			poslist = append(poslist, i)
		}
	}

	if len(poslist) <= 0 {
		return
	}

	//随机
	index := poslist[rand.Intn(len(poslist))]
	ret.AddSmall(ret.big[index])
	ret.big = append(ret.big[:index], ret.big[index+1:]...)
}

//生命最低
func setLowestHpHero(ret *ScopeHero) {
	var hp float64
	var index int

	for i, v := range ret.big {
		if hp == 0 || float64(v.CurHp)/float64(v.GetMaxHP()) < hp {
			hp = float64(v.CurHp) / float64(v.GetMaxHP())
			index = i
		}
	}

	ret.AddSmall(ret.big[index])
	ret.big = append(ret.big[:index], ret.big[index+1:]...)
}

//攻击最高
func setBestAttHero(ret *ScopeHero) {
	var att int32
	var index int

	for i, v := range ret.big {
		if v.GetAttack() > att {
			att = v.GetAttack()
			index = i
		}
	}
	ret.AddSmall(ret.big[index])
	ret.big = append(ret.big[:index], ret.big[index+1:]...)
}

//职业ID随机
func setRandHeroByType(ret *ScopeHero, htype int32) {
	var heroType []int
	for i, v := range ret.big {
		if v.HeroConfig.Vocation == htype {
			heroType = append(heroType, i)
		}
	}

	if len(heroType) <= 0 {
		return
	}

	//随机
	index := heroType[rand.Intn(len(heroType))]
	ret.AddSmall(ret.big[index])
	ret.big = append(ret.big[:index], ret.big[index+1:]...)
}

//最小站位
func setMinPos(ret *ScopeHero) {
	var pos int32
	var index int

	for i, v := range ret.big {
		if pos == 0 || v.Pos < pos {
			pos = v.Pos
			index = i
		}
	}
	ret.AddSmall(ret.big[index])
	ret.big = append(ret.big[:index], ret.big[index+1:]...)
}
