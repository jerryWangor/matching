package sign

import (
	"c4_center/container/cmongo"
	"c4_center/kmongo"
	"c4_center/utils"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
)

//获取用户本月签到数据
func LoadMonthSignByUserId(uid string, t cmongo.TypeSign, datetime int64) *cmongo.Sign {
	var ret cmongo.Sign
	kmongo.GetOne(context.TODO(), kmongo.SignCollection, &ret, bson.M{"user_id": uid, "type": t, "date_time": datetime})
	if len(ret.ID) <= 0 {
		return nil
	}
	return &ret
}

// 用户今天是否签到
func UserHasSign(uid string) bool {
	datetime := utils.GetZeroTimeStamp()
	var ret cmongo.Sign
	kmongo.GetOne(context.TODO(), kmongo.SignCollection, &ret, bson.M{"user_id": uid, "date_time": datetime})
	if len(ret.ID) > 0 {
		return true
	}
	return false
}

//用户第一次签到
func InsertSign(i *cmongo.Sign) error {
	if !kmongo.InsertOne(context.TODO(), kmongo.SignCollection, i) {
		return fmt.Errorf("insert sign error. -> user_id: %v", i.UserID)
	}
	return nil
}

//用户更新签到
func UpdateSign(i *cmongo.Sign) error {
	if !kmongo.UpdateOne(context.TODO(), kmongo.SignCollection, bson.M{"user_id": i.UserID, "_id": i.ID}, bson.M{"$set": bson.M{"data": i.Data}}) {
		return fmt.Errorf("insert sign error. -> user_id: %v", i.UserID)
	}
	return nil
}
