package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/utils"
	"context"
	"fmt"
)

var Codec ktcp.Codec

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

type LobbyService struct {
	kproto.UnimplementedLobbyServiceServer
}

func (l *LobbyService) LobbyRpc(ctx context.Context, req *kproto.SendReq) (*kproto.SendResp, error) {
	f := func() (*kproto.SendResp, error) {
		defer utils.HandleCrash()

		switch req.Packet.MsgId {
		case uint32(kproto.MSG_GATE_ENTER_LOBBY_REQ_ID):
			return GetEnterLobby(req)
		case uint32(kproto.MSG_LOBBY_ACTIVITY_REQ_ID):
			return GetActivity(req)
		case uint32(kproto.MSG_LOBBY_ACTIVITY_ASSIGN_REQ_ID):
			return GetActivityAssign(req)
		case uint32(kproto.MSG_LOBBY_HERO_REQ_ID):
			return GetHeroes(req)
		case uint32(kproto.MSG_LOBBY_HERO_POS_REQ_ID):
			return SetHeroPos(req)
		case uint32(kproto.MSG_LOBBY_GM_REQ_ID):
			return GmOrder(req)
		case uint32(kproto.MSG_LOBBY_ITEM_LIST_REQ_ID):
			return GetItems(req)
		case uint32(kproto.MSG_LOBBY_ITEM_USE_REQ_ID):
			return ItemUse(req)
		case uint32(kproto.MSG_LOBBY_BOX_SLOT_UNLOCK_REQ_ID):
			return BoxSlotUnlock(req)
		case uint32(kproto.MSG_LOBBY_HERO_LEVEL_UP_REQ_ID):
			return HeroLevelUp(req)
		case uint32(kproto.MSG_LOBBY_SIGN_IN_REQ_ID):
			return SignIn(req)
		case uint32(kproto.MSG_LOBBY_RECEIVE_RANKREWARD_REQ_ID):
			return ReceiveRankReward(req)
		case uint32(kproto.MSG_LOBBY_RANKREWARD_REQ_ID):
			return RankInfo(req)
		case uint32(kproto.MSG_LOBBY_SHOP_REQ_ID):
			return GetShop(req)
		case uint32(kproto.MSG_LOBBY_SHOP_BUY_REQ_ID):
			return ShopBuy(req)
		case uint32(kproto.MSG_LOBBY_RANKING_REQ_ID):
			return GetRanking(req)
		default:
			return nil, fmt.Errorf("msg -> %v not handle in lobby service", req.Packet.MsgId)
		}
	}

	return f()
}
