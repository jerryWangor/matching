package config

import "c4_center/game_config"

func InitLogConfig() {
	game_config.InitLogTableConfig(GameConfigInstant.Path)
}
