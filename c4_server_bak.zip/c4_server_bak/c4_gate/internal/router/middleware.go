package router

import (
	"c4_center/ktcp"
	"runtime/debug"

	"github.com/sirupsen/logrus"
)

func RecoverMiddleware() ktcp.MiddlewareFunc {
	return func(next ktcp.HandlerFunc) ktcp.HandlerFunc {
		return func(c ktcp.Context) {
			defer func() {
				if r := recover(); r != nil {
					logrus.WithField("sid", c.Session().ID()).Errorf("PANIC | %+v | %s", r, debug.Stack())
				}
			}()
			next(c)
		}
	}
}
