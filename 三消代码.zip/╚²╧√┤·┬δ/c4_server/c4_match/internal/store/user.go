package store

import (
	"c4_center/container/cmongo"
	"c4_center/kmongo"
	"context"
	"time"

	"go.mongodb.org/mongo-driver/bson"
)

type User struct {
	ID        string                 `json:"id"`
	Bot       bool                   `json:"bot"`        //是否为机器人
	Score     float64                `json:"score"`      //rank score
	MatchArea int32                  `json:"match_area"` //跨范围次数记录
	ConLose   int32                  `json:"con_lose"`   //连输次数
	JoinTime  time.Time              `json:"join_time"`
	Fields    map[string]interface{} `json:"fields"`
}

func InitUser(userid string, matchType int32) *User {
	ret := &User{ID: userid, MatchArea: 1}

	switch matchType {
	case cmongo.MATCH_TYPE_1:
		var rank cmongo.PlayerRankInfo
		kmongo.GetOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rank, bson.M{"user_id": userid})
		if len(rank.ID) > 0 {
			ret.Score = float64(rank.Rank_1.Score)
			ret.ConLose = rank.Rank_1.ConLose
		}
	default:
	}

	return ret
}

func InitBot(userid string) *User {
	return &User{ID: userid, MatchArea: 1, Bot: true}
}

func (u *User) AddMatchArea(max int32) {
	if u.MatchArea < max {
		u.MatchArea++
	}
}
