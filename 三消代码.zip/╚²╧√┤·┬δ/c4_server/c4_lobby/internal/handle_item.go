package internal

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kproto"
	"c4_center/utils"
	"c4_lobby/internal/item"
	"fmt"
	"time"
)

//get items
func GetItems(req *kproto.SendReq) (*kproto.SendResp, error) {
	//get items
	hs := item.LoadItemByUserId(req.UserId)

	//all items info
	info := &kproto.LOBBY_ITEM_LIST_RESP{}
	for k, v := range hs {
		if v.Num == 0 {
			continue
		}

		info.Items = append(info.Items, item.ItemData(hs[k]))
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_ITEM_LIST_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//itemuse
func ItemUse(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_ITEM_USE_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	//判断玩家是否有足够的道具数量
	info := item.LoadItemByUserIdx(req.UserId, reqData.Id)
	info.ItemConfig = game_config.ItemConfigInstant.GetInfo(info.TypeId)
	if info == nil || info.Num < reqData.Num {
		return nil, fmt.Errorf("not have enough num : -> user_id: %v, type_id: %v", req.UserId, reqData.TypeId)
	}
	//判断道具是否可以使用
	if info.ItemConfig == nil {
		return nil, fmt.Errorf("item config not found : -> user_id: %v, type_id: %v", req.UserId, reqData.TypeId)
	}
	if info.ItemConfig.IsCanUsed == 0 {
		return nil, fmt.Errorf("item can not use : -> user_id: %v, type_id: %v", req.UserId, reqData.TypeId)
	}

	getItemsResp := make([]*kproto.ItemInfo, 0)        //获得的道具返回信息
	useItemsResp := make([]*kproto.ConsumeItemInfo, 0) //消耗的道具返回信息

	// 宝箱槽位检查（包括钥匙和钻石开启宝箱）
	if info.ItemConfig.MainType == game_config.MainType_Box && info.ItemConfig.SubType == game_config.SubType_BoxGrade {
		err := ItemBoxCheck(req, &reqData, info, &useItemsResp)
		if err != nil {
			return nil, err
		}
	}

	// 先消耗使用的这个道具
	if err := item.ConsumeItemByIdx(req.UserId, info.ID, info.Num, reqData.Num); err != nil {
		return nil, err
	}
	useItemsResp = append(useItemsResp, &kproto.ConsumeItemInfo{Id: info.ID, TypeId: info.TypeId, Num: reqData.Num})

	//判断是否有掉落ID
	if info.ItemConfig.DropId > 0 {
		// 循环数量进行掉落道具，理论上数量只有1个
		var i int64
		for i = 0; i < reqData.Num; i++ {
			if err := getItemDrop(req.UserId, info.ItemConfig, &getItemsResp); err != nil {
				return nil, err
			}
		}
	} else {
		// 没有掉落ID，说明是加经验 加buff等等
	}

	rinfo := &kproto.LOBBY_ITEM_USE_RESP{}
	rinfo.Items = getItemsResp
	rinfo.Consumes = useItemsResp
	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_ITEM_USE_RESP_ID), rinfo)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

// 宝箱开启检查，或使用钥匙钻石开启
func ItemBoxCheck(req *kproto.SendReq, reqData *kproto.LOBBY_ITEM_USE_REQ, info *cmongo.Item, conItemsResp *[]*kproto.ConsumeItemInfo) error {

	conStr := ""
	switch reqData.BoxOpenType {
	case cmongo.OPEN_BOX_NORMAL: // 解锁开启
		if info.UnlockTime == 0 || info.UnlockTime > utils.GetNowTime() {
			return fmt.Errorf("item must be unlock : -> user_id: %v, type_id: %v", req.UserId, reqData.TypeId)
		}
		return nil
	case cmongo.OPEN_BOX_KEYS: // 钥匙开启
		conStr = info.ItemConfig.UnlockConsume_Keys
	case cmongo.OPEN_BOX_DIAMONDS: // 钻石开启
		conStr = info.ItemConfig.UnlockConsume_Diamonds
	}

	if err := getItemBoxOpenConsume(conItemsResp, conStr, req, info); err != nil {
		return err
	}

	return nil
}

// 获取宝箱开启需要消耗材料的数量
func getItemBoxOpenConsume(conItemsResp *[]*kproto.ConsumeItemInfo, conStr string, req *kproto.SendReq, info *cmongo.Item) error {
	tid, num, err := utils.ParseItem(conStr)
	if err != nil {
		return err
	}

	// 根据已解锁时间求出需要钥匙的数量
	conNum := num
	var extraNum int64 = 0
	numForOne := int64(info.ItemConfig.LockTime) / num
	if info.UnlockTime > 0 {
		diffTime := info.UnlockTime - utils.GetNowTime()
		if diffTime < 0 {
			return fmt.Errorf("item can open, not keys to open: -> user_id: %v, type_id: %v", req.UserId, info.TypeId)
		}
		if diffTime < info.UnlockTime && diffTime%numForOne != 0 {
			extraNum = 1
		}
		conNum = diffTime/numForOne + extraNum
		//fmt.Println(diffTime, numForOne, conNum)
	}
	// 不能超过num
	if conNum > num {
		conNum = num
	}

	// 判断钥匙数量是否足够
	conInfo := item.LoadItemByUserTypeId(req.UserId, tid)
	if conInfo == nil || conInfo.Num < conNum {
		return fmt.Errorf("item key num not enough : -> user_id: %v", req.UserId)
	}

	// 扣除消耗道具
	*conItemsResp = append(*conItemsResp, &kproto.ConsumeItemInfo{Id: conInfo.ID, TypeId: conInfo.TypeId, Num: conNum})
	if err := item.ConsumeItemByIdx(conInfo.UserID, conInfo.ID, conInfo.Num, conNum); err != nil {
		return err
	}

	return nil
}

// 获取掉落物品
func getItemDrop(userId string, itemConf *game_config.ItemData, getItemsResp *[]*kproto.ItemInfo) error {
	// 从掉落表查询掉落配置
	mainDrop := game_config.MainDropConfigInstant.GetInfo(itemConf.DropId)
	if mainDrop == nil {
		return fmt.Errorf("item main drop not found : -> user_id: %v, type_id: %v, dropid: %v", userId, itemConf.ID, itemConf.DropId)
	}

	getItems := make(map[int32]int64) //用一个map来保存使用道具后获得的道具列表
	// 判断掉落类型
	switch mainDrop.DropType {
	case game_config.DropType_Independent: //独立掉落
		dropItemIndep(mainDrop, getItems)
	case game_config.DropType_Random: //权重掉落
		dropItemWeight(mainDrop, getItems)
	case game_config.DropType_Optional: //自选道具
		dropItemChoose(mainDrop, getItems)
	}

	// 先处理获得的道具
	if len(getItems) > 0 {
		for tid, v := range getItems {
			itemInfo := item.GetInitItem(userId, tid, v)
			*getItemsResp = append(*getItemsResp, &kproto.ItemInfo{Id: itemInfo.ID, TypeId: itemInfo.TypeId, Num: v})
			if _, err := item.InsertUpdateItem(itemInfo); err != nil {
				return err
			}
		}
	}

	return nil
}

// 独立掉落
func dropItemIndep(mainDrop *game_config.MainDropData, getItems map[int32]int64) {
	//道具ID*最少数量-最大数量*万分之概率
	for _, v := range mainDrop.DropItems {
		if tid, min, max, r, err := utils.ParseItemRand(v); err == nil {
			num := utils.GetRandItemNum(int32(r), min, max)
			if num > 0 {
				getItems[tid] = num
			}
		}
	}
}

// 权重掉落
func dropItemWeight(mainDrop *game_config.MainDropData, getItems map[int32]int64) {
	var wTotalNum int64 = 0 // 权重总数量
	tmpItemsMap := make(map[int64]struct {
		Min int64
		Max int64
		Tid int32
	})
	//道具ID*最少数量-最大数量*权重
	for _, v := range mainDrop.DropItems {
		if tid, min, max, r, err := utils.ParseItemRand(v); err == nil {
			wTotalNum += r
			tmpItemsMap[wTotalNum] = struct {
				Min int64
				Max int64
				Tid int32
			}{Min: min, Max: max, Tid: tid}
		}
	}

	if wTotalNum == 0 {
		return
	}
	weight := utils.GetRangeRandNum(1, wTotalNum)
	for k, v := range tmpItemsMap {
		if weight <= k {
			if num := utils.GetRangeRandNum(v.Min, v.Max); num > 0 {
				getItems[v.Tid] = num
			}
			break
		}
	}
}

// 自选掉落
func dropItemChoose(mainDrop *game_config.MainDropData, getItems map[int32]int64) {

}

//boxslot unlock
func BoxSlotUnlock(req *kproto.SendReq) (*kproto.SendResp, error) {

	var reqData kproto.LOBBY_BOX_SLOT_UNLOCK_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	//读取所有宝箱信息，判断有没有其他在解锁或者等待开启的宝箱
	hasBox := false
	var bs *cmongo.Item
	bss := item.LoadBoxSlotByUserId(req.UserId)
	for k, v := range bss {
		if v.ID == reqData.Id {
			hasBox = true
			bs = bss[k]
		}
		if v.UnlockTime > 0 {
			return nil, fmt.Errorf("has boxslot unlocking or unopen -> user_id: %v type_id: %v", req.UserId, v.TypeId)
		}
	}
	//如果没有传入的宝箱
	if !hasBox {
		return nil, fmt.Errorf("boxslot not found -> id: %v", reqData.Id)
	}

	//设置解锁时间，更新mongo
	itemInfo := item.ItemInit{Item: bs}
	if err := itemInfo.LoadItemConfig(); err != nil {
		return nil, fmt.Errorf("item config not found -> type_id: %v", itemInfo.TypeId)
	}
	//解析格式
	now := time.Now()
	bs.UnlockTime = now.Add(time.Duration(itemInfo.ItemConfig.LockTime) * time.Second).Unix()

	if err := item.UpdateBoxSlotUnlockTimeByIdx(bs.ID, bs.UnlockTime); err != nil {
		return nil, fmt.Errorf("boxslot set unlocktime error -> id: %v", reqData.Id)
	}

	info := &kproto.LOBBY_BOX_SLOT_UNLOCK_RESP{}
	info.Item = item.ItemData(bs)

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_BOX_SLOT_UNLOCK_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}
