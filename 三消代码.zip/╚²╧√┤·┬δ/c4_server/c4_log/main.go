package main

import (
	"c4_center/game_config"
	"c4_center/khttp"
	"c4_center/klog"
	"c4_center/kmongo"
	"c4_center/kmysql"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/ktcp"
	"c4_center/registry/etcd"
	"c4_log/config"
	"c4_log/internal"
	"c4_log/internal/handle"
	"c4_log/log_registry"
	"net"
	"os"
	"os/signal"
	"syscall"
	"time"

	redisv8 "github.com/go-redis/redis/v8"
	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/grpc"
)

func main() {
	//初始化配置
	config.Init("app.ini")
	//初始化logs
	klog.InitLog(config.LogsConfigInstant.Path, config.LogsConfigInstant.Level)
	//初始化mongo
	kmongo.Init(config.MongoConfigInstant.Mongo_DB, options.Client().ApplyURI(config.MongoConfigInstant.Mongo_addr))
	//初始化mysql
	kmysql.Init(config.MysqlConfigInstant.Mysql_addr)
	//初始化日志配置
	config.InitLogConfig()

	//watch
	go game_config.WatchGameConfig(config.GameConfigInstant.Path, config.InitLogConfig)

	//初始化redis
	kredis.Init(&redisv8.Options{
		Addr:     config.RedisConfigInstant.Redis_addr,
		Password: config.RedisConfigInstant.Redis_pswd,
		DB:       config.RedisConfigInstant.Redis_DB,
		PoolSize: config.RedisConfigInstant.Redis_poolSize,
	})

	//初始化etcd
	log_registry.InitLogRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))

	//注册etcd服务
	if err := log_registry.EtcdClient.Register(config.GrpcServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := log_registry.EtcdClient.Register(config.HttpServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	//监听所需etcd服务
	//log_registry.EtcdClient.Watch(login_registry.GATE_SERVICE)

	//启动rpc服务
	lis, err := net.Listen("tcp", config.GrpcConfigInstant.Grpc_addr)
	if err != nil {
		logrus.Fatalf("failed to listen: %v", err)
	}

	var opts []grpc.ServerOption
	grpcServer := grpc.NewServer(opts...)
	kproto.RegisterLogServiceServer(grpcServer, &internal.LogService{})
	go func() { grpcServer.Serve(lis) }()

	//启动http服务
	server := khttp.NewServer(&khttp.HttpServerOption{
		Router: khttp.NewRouter(&ktcp.ProtobufCodec{}),
	})
	server.NotFoundHandler(internal.NotFound)
	server.Use(khttp.RecoverMiddleware())
	server.AddRoute("/log_client", handle.LogClientHandler)

	go server.Serve(config.HttpConfigInstant.Http_addr)

	// 开启日志写入协程
	handle.Init()
	go handle.LogLoop()

	// 开启定时器（每24小时自动建表）
	go handle.TickerLoop()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh

	grpcServer.Stop()
	handle.Close()
	logrus.Infof("server stopped.")
}
