package game_config

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"time"

	"github.com/fsnotify/fsnotify"
	"github.com/sirupsen/logrus"
)

func LoadJsonFile(path string, val interface{}) {
	data, err := ioutil.ReadFile(path)
	if err != nil {
		logrus.Fatalf("load json file error ->  %v\n", err)
	}

	err = json.Unmarshal(data, val)
	if err != nil {
		logrus.Fatalf("unmarshal json  error ->  %v\n", err)
	}
}

func WatchGameConfig(path string, f func()) {
	// Create new watcher.
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		log.Fatal(err)
	}
	defer watcher.Close()

	// Start listening for events.
	go func() {
		var (
			timer     *time.Timer
			lastEvent fsnotify.Event
		)
		timer = time.NewTimer(time.Millisecond)
		<-timer.C // timer should be expired at first
		for {
			select {
			case event, ok := <-watcher.Events:
				if !ok {
					return
				}
				lastEvent = event
				timer.Reset(time.Millisecond * 100)
			case err, ok := <-watcher.Errors:
				if !ok {
					return
				}
				logrus.Error(err)
			case <-timer.C:
				if lastEvent.Op&fsnotify.Write == fsnotify.Write {
					logrus.Infoln("modify file : " + lastEvent.Name)
					f()
				} else if lastEvent.Op&fsnotify.Create == fsnotify.Create {
				} else if lastEvent.Op&fsnotify.Remove == fsnotify.Remove {
				}
				if err != nil {
					logrus.Error(err)
				}
			}
		}
	}()

	// Add a path.
	err = watcher.Add(path)
	if err != nil {
		log.Fatal(err)
	}

	// Block main goroutine forever.
	<-make(chan struct{})
}
