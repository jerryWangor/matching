package game_config

type ConditionalOfShelfData struct {
	ID                    int32  `tb_name:"条件ID"`
	ConditionalType       int32  `tb_name:"条件类型"`
	ConditionalParameters string `tb_name:"条件参数"`
}

var ConditionalOfShelfConfigInstant *ConditionalOfShelfConfig

type ConditionalOfShelfConfig struct {
	ConditionalOfShelfData []*ConditionalOfShelfData
	Infos                  map[int32]*ConditionalOfShelfData //key == Id
}

func InitConditionalOfShelfConfig(path string) {
	ConditionalOfShelfConfigInstant = &ConditionalOfShelfConfig{Infos: make(map[int32]*ConditionalOfShelfData)}
	//加载
	LoadJsonFile(path+"/ConditionalOfShelfData.json", ConditionalOfShelfConfigInstant)
	//初始化
	ConditionalOfShelfConfigInstant.InitIndex()
}

func (h *ConditionalOfShelfConfig) InitIndex() {
	for i, _ := range h.ConditionalOfShelfData {
		h.Infos[h.ConditionalOfShelfData[i].ID] = h.ConditionalOfShelfData[i]
	}
}

func (h *ConditionalOfShelfConfig) GetConditionalOfShelfs(id int32) *ConditionalOfShelfData {
	data, ok := h.Infos[id]
	if !ok {
		return nil
	}
	return data
}
