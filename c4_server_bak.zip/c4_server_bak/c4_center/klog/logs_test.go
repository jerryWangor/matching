package klog

import (
	"fmt"
	"math/rand"
	"testing"

	"github.com/sirupsen/logrus"
)

func TestLogs(t *testing.T) {
	InitLog("./logs/room_log", 4)
	logrus.Info("11")

	for i := 0; i < 100; i++ {
		fmt.Println(rand.Intn(5))
	}
}
