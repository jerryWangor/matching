package game_config

type PvPSegmentData struct {
	Id         int32    `tb_name:"总星级"`
	Name       string   `tb_name:"段位名"`
	Grad       int32    `tb_name:"段位Id"`
	Star       int32    `tb_name:"段内星级"`
	Exp        int32    `tb_name:"积分"`
	ResetStar  int32    `tb_name:"重置后星级"`
	Color      string   `tb_name:"段位颜色"`
	StarReward []string `tb_name:"段位星级奖励"`
	WinReward  string   `tb_name:"战斗胜利金币奖励"`
	LoseReward string   `tb_name:"战斗失败金币奖励"`
}

var PvPSegmentConfigInstant *PvPSegmentConfig

type PvPSegmentConfig struct {
	PvPSegmentData []*PvPSegmentData
	Infos          map[int32]*PvPSegmentData
}

func InitPvPSegmentConfig(path string) {
	PvPSegmentConfigInstant = &PvPSegmentConfig{Infos: make(map[int32]*PvPSegmentData)}
	//加载
	LoadJsonFile(path+"/PvPSegmentData.json", PvPSegmentConfigInstant)
	//初始化
	PvPSegmentConfigInstant.InitIndex()
}

func (s *PvPSegmentConfig) InitIndex() {
	for i, v := range s.PvPSegmentData {
		s.Infos[v.Id] = s.PvPSegmentData[i]
	}
}

func (s *PvPSegmentConfig) GetInfo(id int32) *PvPSegmentData {
	return s.Infos[id]
}

func (s *PvPSegmentConfig) GetMinInfo(score int32) *PvPSegmentData {
	count := 0

	for count < len(s.PvPSegmentData)-1 {
		if s.PvPSegmentData[count].Exp >= score {
			break
		}

		count++
	}

	return s.PvPSegmentData[count]
}

func (s *PvPSegmentConfig) GetNowInfo(score int32) *PvPSegmentData {
	count := 0

	if score > 0 {
		for count < len(s.PvPSegmentData) {
			if s.PvPSegmentData[count].Exp > score {
				count--
				break
			}
			count++
		}
	}
	if count >= len(s.PvPSegmentData) {
		count--
	}
	return s.PvPSegmentData[count]
}
