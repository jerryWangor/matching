package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"github.com/sirupsen/logrus"
)

var Codec ktcp.Codec

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

func SendShopState(req *kproto.SendReq) (*kproto.SendResp, error) {
	var respData kproto.GATE_SHOP_NOTICE_ASYNC_RESP
	if err := Codec.Decode(req.Packet.Data, &respData); err != nil {
		return nil, err
	}

	logrus.Info("通知客户端商店状态：", respData.Id)
	for _, v := range Sessions.GetAllSessions() {
		v.AllocateContext().SetResponseMessage(ktcp.NewMessage(req.Packet.MsgId, req.Packet.Data)).Send()
	}

	return &kproto.SendResp{}, nil
}
