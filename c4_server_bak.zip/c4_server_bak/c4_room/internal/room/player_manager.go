package room

import "sync"

var PlayerManagerInstant *PlayerManager

type PlayerManager struct {
	rmap map[string]string
	sync.Mutex
}

func init() {
	PlayerManagerInstant = &PlayerManager{
		rmap: make(map[string]string),
	}
}

func (r *PlayerManager) SetPlayerRoom(userid, roomid string) {
	r.Lock()
	defer r.Unlock()

	r.rmap[userid] = roomid
}

func (r *PlayerManager) RemovePlayer(userid string) {
	r.Lock()
	defer r.Unlock()

	delete(r.rmap, userid)
}

func (r *PlayerManager) GetRoom(userid string) string {
	r.Lock()
	defer r.Unlock()

	return r.rmap[userid]
}

func (r *PlayerManager) GetSize() int {
	r.Lock()
	defer r.Unlock()
	return len(r.rmap)
}
