package main

import (
	"c4_center/klog"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/registry/etcd"
	"c4_pay/config"
	"c4_pay/pay_registry"
	"context"
	"fmt"
	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"testing"
	"time"
)

var Codec ktcp.Codec
var PayGrpc = "pay-grpc"

var userId = "wangjin"

func InitConfig() {
	//初始化配置
	config.Init("app.ini")
	//初始化游戏配置
	config.InitGameConfig()
	//初始化logs
	klog.InitLog(config.LogsConfigInstant.Path, config.LogsConfigInstant.Level)
	//初始化mongo
	kmongo.Init(config.MongoConfigInstant.Mongo_DB, options.Client().ApplyURI(config.MongoConfigInstant.Mongo_addr))

	Codec = &ktcp.ProtobufCodec{}
}

func TestGrpcGetOrder(t *testing.T) {

	InitConfig()

	//初始化etcd
	pay_registry.InitPayRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	pay_registry.EtcdClient.Watch(PayGrpc)

	service, err := pay_registry.EtcdClient.GetServiceInDiscovery(PayGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewPayServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.PAY_GET_ORDER_REQ{
		ShopId: 4,
		ItemId: 407,
	}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_PAY_GET_ORDER_REQ_ID), info)
	resp, err := client.PayRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.PAY_GET_ORDER_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Code)
	fmt.Println(respData.OrderId)
}

func TestGrpcCallBack(t *testing.T) {

	InitConfig()

	//初始化etcd
	pay_registry.InitPayRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	pay_registry.EtcdClient.Watch(PayGrpc)

	service, err := pay_registry.EtcdClient.GetServiceInDiscovery(PayGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewPayServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.PAY_CALLBACK_REQ{
		OrderId:  "202212090957295983085439",
		HashData: "0xde85d1d5fc43d6f92a3918be711dbddefaf03dd86e3f2c94fad1e4f2ea9eba12",
	}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_PAY_CALLBACK_REQ_ID), info)
	resp, err := client.PayRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.PAY_CALLBACK_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Code)
	fmt.Println(respData.GetItems)
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
