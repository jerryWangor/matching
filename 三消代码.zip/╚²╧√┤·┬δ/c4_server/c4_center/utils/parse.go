package utils

import (
	"fmt"
	"strconv"
	"strings"
)

// 解析101*100这种格式的数据
func ParseItem(str string) (int32, int64, error) {
	var tid, num int64
	darr := strings.Split(str, "*")
	if len(darr) < 2 {
		return int32(tid), num, fmt.Errorf("parse error : -> %v", str)
	}
	tid, _ = strconv.ParseInt(darr[0], 10, 32)
	num, _ = strconv.ParseInt(darr[1], 10, 64)

	return int32(tid), num, nil
}

// 解析101*100-200*10000这种格式的数据
func ParseItemRand(str string) (int32, int64, int64, int64, error) {
	var tid, min, max, rand int64
	darr := strings.Split(str, "*")
	//这里判断有没有-
	if len(darr) > 2 && strings.Contains(darr[1], "-") {
		narr := strings.Split(darr[1], "-")
		min, _ = strconv.ParseInt(narr[0], 10, 64)
		max, _ = strconv.ParseInt(narr[1], 10, 64)
		rand, _ = strconv.ParseInt(darr[2], 10, 32)
		tid, _ = strconv.ParseInt(darr[0], 10, 32)
	} else {
		return int32(tid), min, max, rand, fmt.Errorf("parse error : -> %v", str)
	}

	return int32(tid), min, max, rand, nil
}

// 解析 1-2 这种
func ParseMinMax(str string) (int64, int64, error) {
	var min, max int64
	darr := strings.Split(str, "-")
	if len(darr) < 2 {
		return min, max, fmt.Errorf("parse error : -> %v", str)
	}
	min, _ = strconv.ParseInt(darr[0], 10, 64)
	max, _ = strconv.ParseInt(darr[1], 10, 64)

	return min, max, nil
}
