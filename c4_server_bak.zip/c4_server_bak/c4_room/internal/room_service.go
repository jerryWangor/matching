package internal

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/utils"
	"c4_room/config"
	"c4_room/internal/room"
	"context"
	"fmt"

	"github.com/sirupsen/logrus"
)

var Codec ktcp.Codec

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

type RoomService struct {
	kproto.UnimplementedRoomServiceServer
}

func (r *RoomService) RoomCreateRpc(ctx context.Context, req *kproto.SendReq) (*kproto.SendResp, error) {
	f := func() (*kproto.SendResp, error) {
		defer utils.HandleCrash()

		logrus.Infof("room rpc ->>> msg: %v", req.Packet.MsgId)
		switch req.Packet.MsgId {
		case uint32(kproto.MSG_MATCH_CREATE_ROOM_REQ_ID):
			return CreateRoom(req)
		case uint32(kproto.MSG_BATTLE_ONLINE_REQ_ID):
			return GetOnline(req)
		default:
			return nil, fmt.Errorf("msg -> %v not handle in room service", req.Packet.MsgId)
		}

	}

	return f()
}

func GetOnline(req *kproto.SendReq) (*kproto.SendResp, error) {
	packet, err := getPacket(uint32(kproto.MSG_BATTLE_ONLINE_RESP_ID), &kproto.BATTLE_ONLINE_RESP{Num: room.Sessions.Size()})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

func SetPlayer(rm *room.TableFsm, user *kproto.MatchUser) bool {
	//add bot
	if user.Bot {
		return AddBot(rm, user)
	}

	//设置玩家对应
	room.PlayerManagerInstant.SetPlayerRoom(user.UserId, rm.Table.ID)
	//生成玩家
	player, err := room.InitPlayer(user.UserId, rm.Table)
	//生成玩家失败
	if err != nil {
		logrus.Error(err)
		return false
	}

	//设置玩家
	rm.Table.SetPlayer(rm.Ctx, player)
	return true
}

//add bot
func AddBot(rm *room.TableFsm, user *kproto.MatchUser) bool {
	player, err := room.InitBot(user, rm.Table)
	//生成玩家失败
	if err != nil {
		logrus.Error(err)
		return false
	}

	//设置玩家
	rm.Table.SetPlayer(rm.Ctx, player)
	//player loop
	player.PlayerAction()

	return true
}

func CreateRoom(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.MATCH_CREATE_ROOM_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	//check
	if room.SrManagerInstant.GetRoom(reqData.RoomId) != nil {
		return nil, fmt.Errorf("room -> %v has created", reqData.RoomId)
	}

	//init room
	table := room.NewTable(reqData.RoomId, reqData.MatchType, 500)
	rm := room.NewTableFsm(table)
	//set player
	if !SetPlayer(rm, reqData.Player1) || !SetPlayer(rm, reqData.Player2) {
		return nil, fmt.Errorf("create room error because set player")
	}

	//record
	room.SrManagerInstant.CreateRoom(rm)
	//start
	go rm.Loop()

	//encode
	packet, err := getPacket(uint32(kproto.MSG_MATCH_CREATE_ROOM_RESP_ID), &kproto.MATCH_CREAT_ROOM_RESP{Address: config.TcpServiceInstant.Endpoints[0]})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
