package game_config

type RobotParametersData struct {
	Exp           int32 `tb_name:"段位积分"`
	MoveTimes_Min int32 `tb_name:"最小移动棋子次数"`
	MoveTimes_Max int32 `tb_name:"最大移动棋子次数"`
}

var RobotParametersConfigInstant *RobotParametersConfig

type RobotParametersConfig struct {
	RobotParametersData []*RobotParametersData
	Infos               map[int32]*RobotParametersData
}

func InitRobotParametersConfig(path string) {
	RobotParametersConfigInstant = &RobotParametersConfig{Infos: make(map[int32]*RobotParametersData)}
	//加载
	LoadJsonFile(path+"/RobotParametersData.json", RobotParametersConfigInstant)
	//初始化
	RobotParametersConfigInstant.InitIndex()
}

func (s *RobotParametersConfig) InitIndex() {
	for i, v := range s.RobotParametersData {
		s.Infos[v.Exp] = s.RobotParametersData[i]
	}
}

func (s *RobotParametersConfig) GetMinInfo(exp int32) *RobotParametersData {
	count := 0

	for count < len(s.RobotParametersData)-1 {
		if s.RobotParametersData[count].Exp >= exp {
			break
		}

		count++
	}

	return s.RobotParametersData[count]
}
