package main

import (
	"fmt"
	"sync"
)

func main() {
	m := &sync.Map{}
	m.LoadOrStore("key1", "v1")
	m.LoadOrStore("key2", "v2")
	m.LoadOrStore("key3", "v3")

	var count int
	m.Range(func(key, value any) bool {
		count++
		fmt.Println(key, value)
		return true
	})

	fmt.Println(count)
}
