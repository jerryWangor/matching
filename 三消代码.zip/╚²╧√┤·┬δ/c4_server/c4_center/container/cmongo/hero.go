package cmongo

import (
	"c4_center/game_config"
)

type HeroState int32

const DELETE HeroState = -1 //删除
const NORMAL HeroState = 0  //闲置
const ATTACK HeroState = 1  //上阵
const DEATH HeroState = 2   //阵亡

type Hero struct {
	ID         string    `bson:"_id"`         //idx
	UserID     string    `bson:"user_id"`     //所属玩家ID
	Grade      int32     `bson:"grade"`       //星级
	Level      int32     `bson:"level"`       //等级
	Gene       string    `bson:"gene"`        //基因
	GeneMask   string    `bson:"gene_mask"`   //变异
	Pos        int32     `bson:"pos"`         //位置{1-6}
	State      HeroState `bson:"state"`       //英雄状态{-1.删除 0.闲置 1.出战 2.阵亡}
	ChessColor int32     `bson:"chess_color"` //棋子颜色
	NSkill     int32     `bson:"nskill"`      //`tb_name:"普攻Id"`
	USkill     int32     `bson:"uskill"`      //`tb_name:"必杀技Id"`
	PSkill_1   int32     `bson:"pskill_1"`    //`tb_name:"被动技能1"`
	PSkill_2   int32     `bson:"pskill_2"`    //`tb_name:"被动技能2"`
	PSkill_3   int32     `bson:"pskil_3"`     //`tb_name:"被动技能3"`
	BallId     int32     `bson:"ball_id"`     //水晶人ID
	Token      int32     `bson:"token"`       //英雄token (<=0 kida)
	XmasPoint  int32     `bson:"xmas_point"`  //活动点数

	CurHp             int32                                  `bson:"-"` //当前血量
	CurShield         int32                                  `bson:"-"` //当前护盾
	CurEnergy         int32                                  `bson:"-"` //当前能量
	HeroAttrConfig    *game_config.HeroAttrData              `bson:"-"` //属性配置
	HeroConfig        *game_config.HeroData                  `bson:"-"` //基础配置
	XmasConfig        *game_config.ChristmasDropData         `bson:"-"` //圣诞掉落配置
	SkillConfig       map[int32]*game_config.SkillData       `bson:"-"` //技能配置 key = skill_id
	SkillEffectConfig map[int32]*game_config.SkillEffectData `bson:"-"` //技能效果配置key = effect_id
}
