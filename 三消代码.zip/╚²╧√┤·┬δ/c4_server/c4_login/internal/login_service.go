package internal

import (
	"c4_center/kproto"
	"context"
)

type LoginService struct {
	kproto.UnimplementedLoginServiceServer
}

func (l *LoginService) LoginRpc(context.Context, *kproto.SendReq) (*kproto.SendResp, error) {
	return &kproto.SendResp{}, nil
}
