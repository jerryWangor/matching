package room

import (
	"c4_center/ktcp"
	"sync"
)

var Sessions *SessionManager

type SessionManager struct {
	lock    sync.RWMutex
	storage map[string]ktcp.Session
}

func init() {
	Sessions = &SessionManager{storage: map[string]ktcp.Session{}}
}

func (s *SessionManager) SetSession(sess ktcp.Session) {
	s.lock.Lock()
	defer s.lock.Unlock()

	s.storage[sess.ID().(string)] = sess
}

func (s *SessionManager) GetSession(sid string) ktcp.Session {
	s.lock.RLock()
	defer s.lock.RUnlock()

	return s.storage[sid]
}

func (s *SessionManager) RemoveSession(sid string) {
	s.lock.Lock()
	defer s.lock.Unlock()

	delete(s.storage, sid)
}
func (s *SessionManager) Size() int32 {
	return int32(len(s.storage))
}
