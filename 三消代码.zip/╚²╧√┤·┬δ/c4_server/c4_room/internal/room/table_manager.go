package room

import (
	"sync"
)

var SrManagerInstant *SrManager

type SrManager struct {
	rmap map[string]*TableFsm
	sync.Mutex
}

func init() {
	SrManagerInstant = &SrManager{
		rmap: make(map[string]*TableFsm),
	}
}

func (r *SrManager) CreateRoom(rmInfo *TableFsm) {
	r.Lock()
	defer r.Unlock()

	r.rmap[rmInfo.Table.ID] = rmInfo
}

func (r *SrManager) DestoryRoom(id string) {
	r.Lock()
	defer r.Unlock()

	delete(r.rmap, id)
}

func (r *SrManager) GetRoom(id string) *TableFsm {
	r.Lock()
	defer r.Unlock()

	return r.rmap[id]
}

func (r *SrManager) GetSize() int {
	r.Lock()
	defer r.Unlock()
	return len(r.rmap)
}
