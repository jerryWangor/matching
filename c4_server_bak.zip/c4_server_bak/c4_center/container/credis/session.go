package credis

//json
type SessionInfo struct {
	UserID          string `json:"UserID"`      // session key in redis
	Session         string `json:"Session"`     // user session
	GateGrpcAddress string `json:"GateAddress"` // searching gate info in etcd : exemple:"gate-grpc/ID"
	RoomID          string `json:"RoomID"`
	RoomTcpAddress  string `json:"RoomAddress"`
}
