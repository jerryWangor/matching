package rules

import (
	"c4_center/game_config"
	"c4_match/internal/store"
)

type MatchRule interface {
	Match(user1, user2 *store.User) bool
	GetName() string
	GetConfig() *game_config.MatchRuleData
}
