package game_config

type ShopItem struct {
	ID                int32   `tb_name:"商品ID"`
	ShopID            int32   `tb_name:"商店ID"`
	Item_Info         string  `tb_name:"商品配置"`
	Item_Name         int32   `tb_name:"商品名字"`
	Item_Icon         string  `tb_name:"商品图标"`
	Current_Consumer  string  `tb_name:"现价"`
	Original_Consumer string  `tb_name:"原价"`
	Discount          string  `tb_name:"折扣"`
	Product_ID        string  `tb_name:"支付类型"`
	Grad_Price        int32   `tb_name:"梯度计价ID"`
	Person_Limit      int32   `tb_name:"单人限购次数"`
	Order             int32   `tb_name:"商品排序"`
	Conditional_ID    []int32 `tb_name:"上架条件索引"`
}

var ShopItemConfigInstant *ShopItemConfig

type ShopItemConfig struct {
	ShopItem   []*ShopItem
	Infos      map[int32]map[int32]*ShopItem   //key == Id
	OrderInfos map[int32]map[int32][]*ShopItem //key == Order
}

func InitShopItemConfig(path string) {
	ShopItemConfigInstant = &ShopItemConfig{Infos: make(map[int32]map[int32]*ShopItem), OrderInfos: make(map[int32]map[int32][]*ShopItem)}
	//加载
	LoadJsonFile(path+"/ShopItem.json", ShopItemConfigInstant)
	//初始化
	ShopItemConfigInstant.InitIndex()
}

func (h *ShopItemConfig) InitIndex() {
	for i, _ := range h.ShopItem {
		if h.Infos[h.ShopItem[i].ShopID] == nil {
			h.Infos[h.ShopItem[i].ShopID] = make(map[int32]*ShopItem)
		}
		h.Infos[h.ShopItem[i].ShopID][h.ShopItem[i].ID] = h.ShopItem[i]

		if h.OrderInfos[h.ShopItem[i].ShopID] == nil {
			h.OrderInfos[h.ShopItem[i].ShopID] = make(map[int32][]*ShopItem)
		}
		h.OrderInfos[h.ShopItem[i].ShopID][h.ShopItem[i].Order] = append(h.OrderInfos[h.ShopItem[i].ShopID][h.ShopItem[i].Order], h.ShopItem[i])
	}
}

func (h *ShopItemConfig) GetShopItems(id int32) map[int32]*ShopItem {
	data, ok := h.Infos[id]
	if !ok {
		return nil
	}
	return data
}

func (h *ShopItemConfig) GetItem(shopId int32, itemId int32) *ShopItem {
	data, ok := h.Infos[shopId]
	if !ok {
		return nil
	}
	item, ok := data[itemId]
	if !ok {
		return nil
	}
	return item
}

func (h *ShopItemConfig) GetShopIds() []int32 {
	// 数组默认长度为map长度,后面append时,不需要重新申请内存和拷贝,效率很高
	keys := make([]int32, 0, len(h.Infos))
	for k := range h.Infos {
		keys = append(keys, k)
	}
	return keys
}

func (h *ShopItemConfig) GetShopItemsByOrder(id int32) map[int32][]*ShopItem {
	data, ok := h.OrderInfos[id]
	if !ok {
		return nil
	}
	return data
}

func (h *ShopItemConfig) GetItemByOrder(shopId int32, orderId int32) []*ShopItem {
	data, ok := h.OrderInfos[shopId]
	if !ok {
		return nil
	}
	item, ok := data[orderId]
	if !ok {
		return nil
	}
	return item
}
