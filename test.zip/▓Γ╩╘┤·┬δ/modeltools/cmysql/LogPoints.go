package cmysql

// 打点日志表
type LogPoints struct {
	Id int `gorm:"primaryKey" json:"id"` 
	Accid string `gorm:"" json:"accid"` // 账号ID
	PointId int `gorm:"" json:"pointid"` // 协议ID
	DateTime int `gorm:"" json:"datetime"` // 插入时间
}