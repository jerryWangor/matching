package room

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/utils"
	"context"
	"fmt"
	"strconv"
	"strings"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

type RankReward interface {
	CalcReward(win, lose *Player, isWin bool)
	OutData() interface{}
}

type RankDefaultRewardResult struct {
	Score int32          //比赛结果积分
	Items []*cmongo.Item //获得道具
}

func (rr *RankDefaultRewardResult) CalcReward(win, lose *Player, isWin bool) {

}

func (rr *RankDefaultRewardResult) OutData() interface{} {
	return nil
}

//----------------------------------------reward1-------------------------------------------------//
type Rank1RewardResult struct {
	ScoreBefore int32          //比赛结果积分结算前
	ScoreAfter  int32          //比赛结果积分结算后
	Score       int32          //结算积分
	Items       []*cmongo.Item //获得道具
}

//结算
func (rr *Rank1RewardResult) CalcReward(win, lose *Player, isWin bool) {
	rr.SetScore(win, lose, 1, isWin)
	rr.SetItems(win, isWin)
}

func (rr *Rank1RewardResult) OutData() interface{} {
	ret := &kproto.Rank1Result{}
	ret.ScoreBefore = rr.ScoreBefore
	ret.ScoreAfter = rr.ScoreAfter

	for k := range rr.Items {
		ret.Items = append(ret.Items, ItemData(rr.Items[k]))
	}

	return ret
}

//更新物品
func (rr *Rank1RewardResult) SetItems(win *Player, isWin bool) {
	if !isWin {
		return
	}

	orderId := game_config.PVPChestOrderConfigInstant.GetOrder(win.RankInfo.Rank_1.ChestOrder + 1)
	chestOrder := game_config.PVPChestOrderConfigInstant.GetInfo(orderId)     //chest order
	segment := game_config.PvPSegmentConfigInstant.GetMinInfo(rr.ScoreBefore) //段位信息

	//chest
	chest := game_config.PVPChestQualityConfigInstant.GetInfo(chestOrder.QualityId, segment.Grad)
	if chest == nil {
		logrus.Errorf("can not get quality -> quality_id : %v , rank_id : %v", chestOrder.QualityId, segment.Grad)
		return
	}

	//segment
	coin, err := InitItemByString(win.ID, segment.WinReward)
	if err != nil {
		logrus.Error(err)
		return
	}
	rr.Items = append(rr.Items, coin)

	//chest
	item, err := InitItemByString(win.ID, chest.ItemId)
	if err != nil {
		logrus.Error(err)
		return
	}
	rr.Items = append(rr.Items, item)

	//update db
	rr.UpdateItem()
	//update chest order of rank
	kmongo.UpdateOne(context.TODO(), kmongo.PlayerRankInfoCollection, bson.M{"user_id": win.ID}, bson.M{"$set": bson.M{"rank_1.chest_order": orderId}})
}

//更新数据库
func (rr *Rank1RewardResult) UpdateItem() {
	for k, v := range rr.Items {
		if v.Num <= 0 {
			return
		}

		if v.ItemConfig.StackingLimit == 0 {
			v.Num = rr.AddItemUnlimit(rr.Items[k])
		} else {
			v.Num = rr.AddItemLimit(rr.Items[k])
		}
	}

}

//无数量限制堆叠 (return : 实际写入数量)
func (rr *Rank1RewardResult) AddItemUnlimit(item *cmongo.Item) int64 {
	var tmp cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &tmp, bson.M{"user_id": item.UserID, "type_id": item.TypeId})

	//无数据写入,有数量更新
	if len(tmp.ID) > 0 {
		kmongo.UpdateOne(context.TODO(), kmongo.ItemCollection, bson.M{"_id": tmp.ID}, bson.M{"$set": bson.M{"num": tmp.Num + item.Num}})
	} else {
		kmongo.InsertOne(context.TODO(), kmongo.ItemCollection, item)
	}
	return item.Num
}

//有数量限制堆叠(return : 实际写入数量)
func (rr *Rank1RewardResult) AddItemLimit(item *cmongo.Item) int64 {
	var tmp []*cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &tmp, bson.M{"user_id": item.UserID, "type_id": item.TypeId})

	totalNum := item.Num //总数量
	lastNum := item.Num  //剩余数量
	if len(tmp) <= 0 {
		lastNum = rr.InsertOrUpdateLimitNum(item, lastNum, true)
	} else {
		for k := range tmp {
			lastNum = rr.InsertOrUpdateLimitNum(tmp[k], lastNum, false)
		}
	}

	//剩余数量循环写入
	for lastNum > 0 {
		lastNum = rr.InsertOrUpdateLimitNum(item, lastNum, true)
	}

	return totalNum - lastNum
}

//写入&更新物品数据-> (int64 : 返回剩余数量)
func (rr *Rank1RewardResult) InsertOrUpdateLimitNum(item *cmongo.Item, maxNum int64, isInsert bool) int64 {
	if isInsert {
		item.Num = 0
	}

	//装载量
	load := utils.Min64(int64(item.ItemConfig.StackingLimit)-item.Num, maxNum)
	//剩余量
	last := maxNum - load

	//更新装载数量
	item.Num += load

	if isInsert {
		//宝箱类需要检测是否能获取
		if item.MainType == game_config.MainType_Box && item.SubType == game_config.SubType_BoxGrade {
			item.Index = GetBoxIndex(item.UserID)
			if item.Index < 0 {
				return 0
			}
		}

		//更新ID
		item.ID = primitive.NewObjectID().Hex()
		//写入
		kmongo.InsertOne(context.TODO(), kmongo.ItemCollection, item)
	} else {
		//更新
		kmongo.UpdateOne(context.TODO(), kmongo.ItemCollection, bson.M{"_id": item.ID}, bson.M{"$set": bson.M{"num": item.Num}})
	}

	return last
}

//更新积分
func (rr *Rank1RewardResult) UpdateScore(p *Player, isWin bool) {
	//结算前
	rr.ScoreBefore = p.RankInfo.GetRank1Score()
	//设置积分
	p.RankInfo.AddRank1Score(rr.Score)
	//设置输赢
	p.RankInfo.SetWinLose(isWin)
	//结算后
	rr.ScoreAfter = p.RankInfo.GetRank1Score()
	//更新数据库
	if len(p.RankInfo.ID) <= 0 {
		p.RankInfo.ID = primitive.NewObjectID().Hex()
		kmongo.InsertOne(context.TODO(), kmongo.PlayerRankInfoCollection, p.RankInfo)
	} else {
		kmongo.UpdateOne(context.TODO(), kmongo.PlayerRankInfoCollection, bson.M{"user_id": p.ID}, bson.M{"$set": bson.M{"rank_1": p.RankInfo.GetRank1Info()}})
	}
}

//设置积分
func (rr *Rank1RewardResult) SetScore(win, lose *Player, matchType int32, isWin bool) {
	if isWin {
		rr.Score = rr.calcScore(win.RankInfo.GetRank1Score(), lose.RankInfo.GetRank1Score(), matchType, isWin)
		rr.UpdateScore(win, isWin)
	} else {
		rr.Score = utils.Min(rr.calcScore(win.RankInfo.GetRank1Score(), lose.RankInfo.GetRank1Score(), matchType, isWin), lose.RankInfo.GetRank1Score()) * -1
		rr.UpdateScore(lose, isWin)
	}
}

//胜利积分
func (rr *Rank1RewardResult) calcScore(winScore, loseScore, matchType int32, isWin bool) int32 {
	config := game_config.FormulaParametersConfigInstant.GetInfo(matchType)
	if config == nil {
		return 0
	}

	switch isWin {
	case true: // 基础积分 + (对方积分 - 我方积分) / 胜利系数
		score := float64(config.BaseScore) + (float64(loseScore)-float64(winScore))/float64(config.AddRate)
		return utils.Max(config.AddScore_Min, int32(score))
	case false: // 基础积分 - (对方积分 - 我方积分) / 失败系数
		score := float64(config.BaseScore) - (float64(winScore)-float64(loseScore))/float64(config.ReduceRate)
		return utils.Min(config.ReduceScore_Max, int32(score))
	}

	return 0
}

//字符串初始化道具
func InitItemByString(uid, itemStr string) (*cmongo.Item, error) {
	//split
	itemInfo := strings.Split(itemStr, "*")
	if len(itemInfo) <= 0 {
		return nil, fmt.Errorf("chest item error -> : %v", itemStr)
	}

	itemId, _ := strconv.ParseInt(itemInfo[0], 10, 32)
	itemNum, _ := strconv.ParseInt(itemInfo[1], 10, 32)

	item, err := InitItem(uid, int32(itemId), itemNum)
	if err != nil {
		return nil, err
	}

	return item, nil
}

//初始化道具
func InitItem(uid string, tid int32, num int64) (*cmongo.Item, error) {
	ret := &cmongo.Item{ID: primitive.NewObjectID().Hex(), UserID: uid, TypeId: tid, Num: num}
	//道具配置
	ret.ItemConfig = game_config.ItemConfigInstant.GetInfo(ret.TypeId)
	if ret.ItemConfig == nil {
		return nil, fmt.Errorf("cannot get config . type_id -> %v", ret.TypeId)
	}

	//设置大类小类，方便后面的宝箱插槽查询
	ret.MainType = ret.ItemConfig.MainType
	ret.SubType = ret.ItemConfig.SubType

	//num != nil
	if ret.Num <= 0 {
		return nil, fmt.Errorf("item num can not be nil -> %v", tid)
	}

	return ret, nil
}

//得到宝箱槽索引
func GetBoxIndex(uid string) int32 {
	// 判断是否有空槽
	bs := LoadBoxSlotByUserId(uid)
	if len(bs) >= int(cmongo.MAX_BOX_SLOT_INDEX+1) {
		return -1
	} else {
		hasIndexMap := make(map[int32]int32)
		for k := range bs {
			hasIndexMap[bs[k].Index] = bs[k].Index
		}
		//循环判断哪个是空槽
		for i := cmongo.MIN_BOX_SLOT_INDEX; i <= cmongo.MAX_BOX_SLOT_INDEX; i++ {
			_, ok := hasIndexMap[i]
			if !ok {
				return i
			}
		}
	}

	// 没有空槽返回-1
	return -1
}

//获取用户所有宝箱槽位信息
func LoadBoxSlotByUserId(uid string) []*cmongo.Item {
	var ret []*cmongo.Item
	kmongo.Get(context.TODO(), kmongo.ItemCollection, &ret, bson.M{"user_id": uid, "main_type": game_config.MainType_Box, "sub_type": game_config.SubType_BoxGrade})
	return ret
}

//用户增加道具
func InsertItem(i *cmongo.Item) error {
	if !kmongo.InsertOne(context.TODO(), kmongo.ItemCollection, i) {
		return fmt.Errorf("insert item error. -> user_id: %v, type_id: %v", i.UserID, i.TypeId)
	}
	return nil
}

//获取用户某个道具信息（根据item_id）
func LoadItemByUserItemId(uid string, itemId int32) *cmongo.Item {
	var ret cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &ret, bson.M{"user_id": uid, "type_id": itemId})
	if len(ret.ID) <= 0 {
		return nil
	}
	return &ret
}

//用户更新道具，更新数量（根据idx）
func UpdateItemNumByIdx(uid string, idx string, num int64) error {
	if !kmongo.UpdateOne(context.TODO(), kmongo.ItemCollection, bson.M{"user_id": uid, "_id": idx}, bson.M{"$set": bson.M{"num": num}}) {
		return fmt.Errorf("update item error -> idx: %v", idx)
	}
	return nil
}

//道具信息返回
func ItemData(h *cmongo.Item) *kproto.ItemInfo {
	ret := &kproto.ItemInfo{}
	ret.Id = h.ID
	ret.TypeId = h.TypeId
	ret.Num = h.Num
	ret.Index = h.Index
	ret.UnlockTime = h.UnlockTime
	return ret
}
