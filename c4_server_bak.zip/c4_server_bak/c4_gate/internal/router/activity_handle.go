package router

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_gate/internal"
	"github.com/sirupsen/logrus"
)

// 签到
func LobbySignIn(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_SIGN_IN_RESP_ID), &kproto.LOBBY_SIGN_IN_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_SIGN_IN_RESP_ID), &kproto.LOBBY_SIGN_IN_RESP{Code: -2})
	}
}
