package ktcp

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func newContext(sess *session, reqMsg *Message) *routeContext {
	ctx := NewContext()
	ctx.session = sess
	ctx.reqMsg = reqMsg
	return ctx
}

func Test_routeContext_Deadline(t *testing.T) {
	c := newContext(nil, nil)
	dl, ok := c.Deadline()
	assert.False(t, ok)
	assert.Zero(t, dl)
}

func Test_routeContext_Done(t *testing.T) {
	c := newContext(nil, nil)
	done := c.Done()
	assert.Nil(t, done)
}

func Test_routeContext_Err(t *testing.T) {
	c := newContext(nil, nil)
	assert.Nil(t, c.Err())
}

func Test_routeContext_Value(t *testing.T) {
	c := newContext(nil, nil)
	assert.Nil(t, c.Value("not found"))
	c.Set("found", true)
	assert.True(t, c.Value("found").(bool))

	assert.Nil(t, c.Value(123))
}

func Test_routeContext_Get(t *testing.T) {
	c := newContext(nil, nil)
	v, ok := c.Get("not found")
	assert.False(t, ok)
	assert.Nil(t, v)

	c.Set("found", true)
	v, ok = c.Get("found")
	assert.True(t, ok)
	assert.True(t, v.(bool))
}

func Test_routeContext_Set(t *testing.T) {
	c := newContext(nil, nil)
	c.Set("found", true)
	v, ok := c.storage["found"]
	assert.True(t, ok)
	assert.True(t, v.(bool))
}

func Test_routeContext_Remove(t *testing.T) {
	c := newContext(nil, nil)
	c.Set("found", true)
	c.Remove("found")
	v, ok := c.Get("found")
	assert.False(t, ok)
	assert.Nil(t, v)
}

func Test_routeContext_Bind(t *testing.T) {
	t.Run("when session has codec", func(t *testing.T) {
		reqMsg := NewMessage(1, []byte(`{"data":"test"}`))
		sess := newSession(nil, &sessionOption{Codec: &JsonCodec{}})

		c := newContext(sess, reqMsg)
		data := make(map[string]string)
		assert.NoError(t, c.Bind(&data))
		assert.EqualValues(t, data["data"], "test")

		// when dst is invalid
		var dst string
		assert.Error(t, c.Bind(&dst))
	})
	t.Run("when session hasn't codec", func(t *testing.T) {
		reqMsg := NewMessage(1, []byte("test"))
		sess := newSession(nil, &sessionOption{})

		c := newContext(sess, reqMsg)
		var data string
		assert.Error(t, c.Bind(&data))
		assert.Empty(t, data)
	})
}

func Test_routeContext_Session(t *testing.T) {
	sess := newSession(nil, &sessionOption{})

	c := newContext(sess, nil)
	assert.Equal(t, c.Session(), sess)
}

func Test_routeContext_SetRequestMessage(t *testing.T) {
	reqMsg := NewMessage(1, []byte("test"))
	c := NewContext()
	c.SetRequestMessage(reqMsg)
	assert.Equal(t, c.reqMsg, reqMsg)
}
