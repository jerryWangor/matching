package game_config

type MatchRuleData struct {
	ID            int32 `tb_name:"匹配ID"`
	MathPointUp   int32 `tb_name:"匹配范围积分上限"`
	MathPointDown int32 `tb_name:"匹配范围积分下限"`
	MatchArea     int32 `tb_name:"跨范围次数"`
	MatchProtect  int32 `tb_name:"积分保护范围"`
	MatchTIME     int32 `tb_name:"匹配总时长"`
	AreaTime      int32 `tb_name:"单次范围匹配时长"`
}

var MatchRuleConfigInstant *MatchRuleConfig

type MatchRuleConfig struct {
	MatchRuleData []*MatchRuleData
	Infos         map[int32]*MatchRuleData
}

func InitMatchRuleConfig(path string) {
	MatchRuleConfigInstant = &MatchRuleConfig{Infos: make(map[int32]*MatchRuleData)}
	//加载
	LoadJsonFile(path+"/MatchRuleData.json", MatchRuleConfigInstant)
	//初始化
	MatchRuleConfigInstant.InitIndex()
}

func (s *MatchRuleConfig) InitIndex() {
	for i, v := range s.MatchRuleData {
		s.Infos[v.ID] = s.MatchRuleData[i]
	}
}

func (s *MatchRuleConfig) GetInfo(id int32) *MatchRuleData {
	return s.Infos[id]
}
