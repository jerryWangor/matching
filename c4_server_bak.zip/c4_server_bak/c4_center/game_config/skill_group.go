package game_config

type SkillGroupData struct {
	GroupId int32 `tb_name:"技能库ID"`
	SkillId int32 `tb_name:"技能ID"`
	Scale   int32 `tb_name:"抽取权重"`
}

var SkillGroupConfigInstant *SkillGroupConfig

type SkillGroupConfig struct {
	SkillGroupData []*SkillGroupData
	Infos          map[int32][]*SkillGroupData //{key = 技能库ID, value = []技能信息}
}

func InitSkillGroup(path string) {
	SkillGroupConfigInstant = &SkillGroupConfig{Infos: make(map[int32][]*SkillGroupData)}
	//加载
	LoadJsonFile(path+"/SkillGroupData.json", SkillGroupConfigInstant)
	//初始化
	SkillGroupConfigInstant.InitIndex()
}

func (s *SkillGroupConfig) InitIndex() {
	for i, v := range s.SkillGroupData {
		s.Infos[v.GroupId] = append(s.Infos[v.GroupId], s.SkillGroupData[i])
	}
}

//取得指定组内所有技能列表
func (hc *SkillGroupConfig) GetInfo(id int32) []*SkillGroupData {
	return hc.Infos[id]
}
