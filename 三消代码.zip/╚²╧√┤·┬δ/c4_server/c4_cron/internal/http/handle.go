package http

import (
	"c4_center/khttp"
	"c4_center/utils"
)

func GetTime(ctx khttp.Context) {
	ReturnJson(ctx, 0, "success", utils.GetNowTime())
}
