package kmysql

import (
	"testing"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

func TestMysql(t *testing.T) {

}

type Account struct {
	ID   primitive.ObjectID `bson:"_id"`
	Name string             `bosn:"name"`
	PSWD string             `bson:"pswd"`
}
