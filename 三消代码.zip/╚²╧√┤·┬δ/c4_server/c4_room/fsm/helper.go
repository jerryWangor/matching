package fsm

import (
	"github.com/sirupsen/logrus"
)

func GoSafe(fn func()) {
	go goSafe(fn)
}

func goSafe(fn func()) {
	defer func() {
		if err := recover(); err != nil {
			logrus.Infof("defer err:", err)
		}
	}()
	fn()
}
