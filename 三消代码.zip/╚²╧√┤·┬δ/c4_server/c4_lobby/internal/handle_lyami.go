//go:build lyami
// +build lyami

package internal

import (
	"c4_center/container/cmongo"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_lobby/internal/hero"
	"context"
	"fmt"
	"strconv"
	"strings"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
)

const (
	ADD_HERO = "@addhero"
	DEL_HERO = "@delhero"
)

func AddHero(userid, order string, ret *kproto.LOBBY_GM_RESP) {
	sp := strings.Fields(strings.TrimSpace(order))
	if len(sp) != 5 {
		ret.Code = -2
		return
	}

	level, err := strconv.ParseInt(strings.Trim(sp[3], " "), 10, 32)
	if err != nil {
		ret.Code = -3
		return
	}

	grade, err := strconv.ParseInt(strings.Trim(sp[4], " "), 10, 32)
	if err != nil {
		ret.Code = -4
		return
	}

	hero.InsertHero(hero.GetInitHero(userid, sp[1], sp[2], int32(grade), int32(level)))
}

func DelHero(userid string, ret *kproto.LOBBY_GM_RESP) {
	kmongo.DeleteMany(context.TODO(), kmongo.HeroCollection, bson.M{"user_id": userid})
}

//gm指令
func GmOrder(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_GM_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	sp := strings.Fields(strings.TrimSpace(reqData.Order))
	if len(sp) <= 0 {
		return nil, fmt.Errorf("gm order error -> %v", -999)
	}

	info := &kproto.LOBBY_GM_RESP{}

	switch sp[0] {
	case ADD_HERO:
		AddHero(req.UserId, reqData.Order, info)
	case DEL_HERO:
		DelHero(req.UserId, info)
	default:
		info.Code = -9
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_GM_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//get heroes
func GetHeroes(req *kproto.SendReq) (*kproto.SendResp, error) {
	//get heroes
	hs := hero.LoadHeroByUserId(req.UserId)

	//all heroes info
	info := &kproto.LOBBY_HERO_RESP{}
	for _, v := range hs {
		if v.State == cmongo.DELETE {
			continue
		}

		info.Heroes = append(info.Heroes, hero.HeroData(v))
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_HERO_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

//set hero pos
func SetHeroPos(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_HERO_POS_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	//将pos!=0的heroes 更新pos=0 state=0
	if !kmongo.UpdateMany(context.TODO(), kmongo.HeroCollection, bson.M{"user_id": req.UserId, "pos": bson.M{"$ne": 0}}, bson.M{"$set": bson.M{"pos": 0, "state": cmongo.NORMAL}}) {
		return nil, fmt.Errorf("update heroes pos error : -> userid : %v", req.UserId)
	}

	var code int32
	//其中一个不成功code = -1
	for _, v := range reqData.Pos {
		//位置判断
		if v.Pos < 1 || v.Pos > 6 {
			logrus.Infof("idx -> %v , pos -> %v is illegal", v.Idx, v.Pos)
			continue
		}

		//更新位置
		if !kmongo.UpdateOne(context.TODO(), kmongo.HeroCollection, bson.M{"_id": v.Idx}, bson.M{"$set": bson.M{"pos": v.Pos, "state": cmongo.ATTACK}}) {
			code = -1
			logrus.Infof("idx -> %v not exist", v.Idx)
			continue
		}
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_HERO_POS_RESP_ID), &kproto.LOBBY_HERO_POS_RESP{Code: code})
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
