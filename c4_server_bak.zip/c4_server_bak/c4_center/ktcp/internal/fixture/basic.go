package fixture

const ServerAddr = "0.0.0.0:8888"
