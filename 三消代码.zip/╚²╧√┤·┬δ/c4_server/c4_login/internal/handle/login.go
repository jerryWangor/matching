package handle

import (
	"c4_center/container/cmongo"
	"c4_center/container/credis"
	"c4_center/khttp"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_login/login_registry"
	"context"
	"encoding/json"
	"fmt"
	"math/rand"
	"time"

	"github.com/google/uuid"
	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

func NotFound(ctx khttp.Context) {
	// panic("11111111111111111")
	// fmt.Fprintln(ctx.ResponseWriter(), "not found.")
	logrus.Errorf("cant find router for url: %s", ctx.Request().URL)
}

//第三方登陆
func PlatformHandler(ctx khttp.Context) {
	var reqData kproto.LOGIN_SESSION_PLATFORM_REQ
	if ctx.Bind(&reqData) != nil {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -1})
		return
	}

	if len(reqData.Token) <= 0 {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -9})
		return
	}

	//check exist
	var account cmongo.Account
	kmongo.GetOne(context.Background(), kmongo.AccountCollection, &account, bson.M{"token": reqData.Token})
	if account.Token != reqData.Token {
		account.ID = primitive.NewObjectID().Hex()
		account.UserID = uuid.NewString()
		account.Platform = reqData.Platform
		account.Token = reqData.Token
		account.NickName = fmt.Sprintf("Player%v", GetRandNickName())
		account.RegisterTime = time.Now()

		//create account
		if !kmongo.InsertOne(context.Background(), kmongo.AccountCollection, &account) {
			ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -3})
			return
		}
	}

	//get gate
	g, err := login_registry.EtcdClient.GetServiceInDiscovery(login_registry.GATE_SERVICE)
	if err != nil {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -6})
		return
	}

	//set session
	session, err := SetSession(account.UserID)
	if err != nil {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -5})
		return
	}

	//ret
	ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: 0, Data: &kproto.LoginResp{Userid: account.UserID, Session: session, Gate: g.Endpoints[0]}})
}

//第一方登陆
func SessionHandler(ctx khttp.Context) {
	fmt.Println("收到请求")
	var reqData kproto.LOGIN_SESSION_REQ
	if ctx.Bind(&reqData) != nil {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -1})
		return
	}

	if len(reqData.Userid) <= 0 || len(reqData.Pswd) <= 0 {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -9})
		return
	}

	//check account&pswd
	var account cmongo.Account
	kmongo.GetOne(context.Background(), kmongo.AccountCollection, &account, bson.M{"user_id": reqData.Userid})
	if account.UserID == reqData.Userid && account.Password != reqData.Pswd {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -2})
		return
	}

	//create account if not exist
	if len(account.ID) <= 0 {
		account.ID = primitive.NewObjectID().Hex()
		account.UserID = reqData.Userid
		account.Password = reqData.Pswd
		account.NickName = fmt.Sprintf("Player%v", GetRandNickName())
		account.RegisterTime = time.Now()

		if !kmongo.InsertOne(context.Background(), kmongo.AccountCollection, &account) {
			ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -3})
			return
		}
	}

	//get gate
	g, err := login_registry.EtcdClient.GetServiceInDiscovery(login_registry.GATE_SERVICE)
	if err != nil {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -4})
		return
	}

	//set session
	session, err := SetSession(reqData.Userid)
	if err != nil {
		ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: -5})
		return
	}
	fmt.Println("登录成功", reqData.Userid)

	//ret
	ctx.Send(&kproto.LOGIN_SESSION_RESP{Code: 0, Data: &kproto.LoginResp{Userid: account.UserID, Session: session, Gate: g.Endpoints[0]}})
}

func SetSession(userid string) (string, error) {
	//get session
	sessStr, err := kredis.GetStr(context.Background(), userid)
	if err == nil && len(sessStr) > 0 {
		//redis session decode to json
		var sessData credis.SessionInfo
		if err := json.Unmarshal([]byte(sessStr), &sessData); err != nil {
			return "", err
		}

		return sessData.Session, nil
	}

	//session create
	sess := &credis.SessionInfo{UserID: userid, Session: uuid.New().String()}
	b, err := json.Marshal(sess)
	if err != nil {
		return "", err
	}

	//session store
	err = kredis.SetStr(context.Background(), sess.UserID, string(b), time.Hour*24)
	if err != nil {
		return "", err
	}

	return sess.Session, nil
}

func GetRandNickName() string {
	ll := append([]string{}, fmt.Sprintf("%02v", rand.Int31n(100)), fmt.Sprintf("%02v", rand.Int31n(100)), fmt.Sprintf("%01v", rand.Int31n(10)))
	ShuffleSlice(ll)
	return fmt.Sprintf("%v%v%v", ll[0], ll[1], ll[2])
}

func ShuffleSlice[T any](slice []T) {
	r := rand.New(rand.NewSource(time.Now().Unix()))
	for len(slice) > 0 {
		n := len(slice)
		randIndex := r.Intn(n)
		slice[n-1], slice[randIndex] = slice[randIndex], slice[n-1]
		slice = slice[:n-1]
	}
}
