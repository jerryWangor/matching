package kmongo

import (
	"context"
	"testing"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func TestMongo(t *testing.T) {
	Init("test", options.Client().ApplyURI("mongodb://192.168.1.45:27017/test?maxPoolSize=100&authSource=admin"))

	InsertOne(context.TODO(), AccountCollection, &Account{ID: primitive.NewObjectID(), Name: "1", PSWD: "2"})
	InsertOne(context.TODO(), AccountCollection, &Account{ID: primitive.NewObjectID(), Name: "3", PSWD: "4"})

	ret := &Account{}
	GetOne(context.TODO(), AccountCollection, ret, bson.M{"name": "1"})
	if ret.Name != "1" {
		t.Error("error.")
	}

	DeleteMany(context.TODO(), AccountCollection, bson.M{})
}

type Account struct {
	ID   primitive.ObjectID `bson:"_id"`
	Name string             `bosn:"name"`
	PSWD string             `bson:"pswd"`
}
