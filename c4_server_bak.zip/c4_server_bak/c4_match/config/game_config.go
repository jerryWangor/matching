package config

import "c4_center/game_config"

func InitGameConfig() {
	//init
	game_config.InitMatchRuleConfig(GameConfigInstant.Path)
	game_config.InitRobotMatchRuleConfig(GameConfigInstant.Path)
	game_config.InitRobotParametersConfig(GameConfigInstant.Path)
	game_config.InitRobotTeamConfig(GameConfigInstant.Path)

	game_config.InitHeroAttrConfig(GameConfigInstant.Path)
	game_config.InitHeroConfig(GameConfigInstant.Path)
	game_config.InitChessColorGroupConfig(GameConfigInstant.Path)
	game_config.InitSkillGroup(GameConfigInstant.Path)
}
