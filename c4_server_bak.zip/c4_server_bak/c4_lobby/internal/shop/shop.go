package shop

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kmongo"
	"context"
	"fmt"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

// 获取商品限购
func GetShopItemBuyLimit(userId string, shopId int32, itemId int32) *cmongo.ShopBuyLimit {
	var ret cmongo.ShopBuyLimit
	kmongo.GetOne(context.TODO(), kmongo.ShopBuyLimitCollection, &ret, bson.M{"user_id": userId, "shop_id": shopId, "item_id": itemId})
	if len(ret.ID) <= 0 {
		return nil
	}
	return &ret
}

// 获取所有限购
func GetAllShopItemBuyLimit(userId string) map[int32]map[int32]*cmongo.ShopBuyLimit {
	var ret []*cmongo.ShopBuyLimit
	kmongo.Get(context.TODO(), kmongo.ShopBuyLimitCollection, &ret, bson.M{"user_id": userId})
	mapData := make(map[int32]map[int32]*cmongo.ShopBuyLimit)
	for k, v := range ret {
		if mapData[v.ShopId] == nil {
			mapData[v.ShopId] = make(map[int32]*cmongo.ShopBuyLimit)
		}
		mapData[v.ShopId][v.ItemId] = ret[k]
	}
	return mapData
}

func InsertShopItemBuyLimit(i *cmongo.ShopBuyLimit) error {
	if !kmongo.InsertOne(context.TODO(), kmongo.ShopBuyLimitCollection, i) {
		return fmt.Errorf("insert ShopBuyLimit error. -> user_id: %v, shop_id: %v, item_id: %v", i.UserID, i.ShopId, i.ItemId)
	}
	return nil
}

func UpdateShopItemBuyLimit(i *cmongo.ShopBuyLimit) error {
	if !kmongo.UpdateOne(context.TODO(), kmongo.ShopBuyLimitCollection, bson.M{"user_id": i.UserID, "_id": i.ID}, bson.M{"$set": bson.M{"buy_num": i.BuyNum, "limit_num": i.LimitNum}}) {
		return fmt.Errorf("update ShopBuyLimit error. -> user_id: %v, shop_id: %v, item_id: %v", i.UserID, i.ShopId, i.ItemId)
	}
	return nil
}

func InitShopBuyLimit(userId string, shopItemConf *game_config.ShopItem) *cmongo.ShopBuyLimit {
	return &cmongo.ShopBuyLimit{
		ID:       primitive.NewObjectID().Hex(),
		UserID:   userId,
		ShopId:   shopItemConf.ShopID,
		ItemId:   shopItemConf.Order,
		LimitNum: shopItemConf.Person_Limit,
	}
}
