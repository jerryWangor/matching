package cmongo

import "go.mongodb.org/mongo-driver/bson/primitive"

const (
	MATCH_TYPE_1       = 1
	MATCH_TYPE_2       = 2
	RANKING_REDIS_NAME = "player_ranking" // redis key
	RANKING_SHOW_NUM   = 50               // client show num
	RANKING_SAVE_NUM   = 999              // mongo save num
)

// 用户道具信息
type PlayerRankInfo struct {
	ID     string     `bson:"_id"`     // idx
	UserID string     `bson:"user_id"` // 所属玩家ID
	Rank_1 *Rank1Info `bson:"rank_1"`  // rank_1 info
}

type Rank1Info struct {
	TopScore       int32 `bson:"top_score"`        //最高积分
	Score          int32 `bson:"score"`            //积分
	Win            int32 `bson:"win"`              //赢场次
	Lose           int32 `bson:"lose"`             //输场次
	ConLose        int32 `bson:"con_lose"`         //连输场次
	ChestOrder     int32 `bson:"chest_order"`      //chest_order记录
	RankRewardFlag int64 `bson:"rank_reward_flag"` //等级奖励领取记录
}

func (p *PlayerRankInfo) InitPlayerRankInfo(userid string) {
	p.ID = primitive.NewObjectID().Hex()
	p.UserID = userid
	p.Rank_1 = &Rank1Info{}
}

func (p *PlayerRankInfo) SetWinLose(isWin bool) {
	if p.Rank_1 == nil {
		p.Rank_1 = &Rank1Info{}
	}

	//set win&lose
	if isWin {
		p.Rank_1.Win++
		p.Rank_1.ConLose = 0
	} else {
		p.Rank_1.Lose++
		p.Rank_1.ConLose++
	}
}

func (p *PlayerRankInfo) SetRank1Score(s int32) {
	if p.Rank_1 == nil {
		p.Rank_1 = &Rank1Info{}
	}

	//set score
	p.Rank_1.Score = s

	//set top score
	if p.Rank_1.Score > p.Rank_1.TopScore {
		p.Rank_1.TopScore = p.Rank_1.Score
	}
}

func (p *PlayerRankInfo) AddRank1Score(s int32) {
	if p.Rank_1 == nil {
		p.Rank_1 = &Rank1Info{}
	}

	//set score
	p.Rank_1.Score += s

	//set top score
	if p.Rank_1.Score > p.Rank_1.TopScore {
		p.Rank_1.TopScore = p.Rank_1.Score
	}
}

func (p *PlayerRankInfo) GetRank1Info() *Rank1Info {
	return p.Rank_1
}

func (p *PlayerRankInfo) GetConLose() int32 {
	if p.Rank_1 == nil {
		return 0
	}

	return p.Rank_1.ConLose
}

func (p *PlayerRankInfo) GetRank1Score() int32 {
	if p.Rank_1 == nil {
		return 0
	}

	return p.Rank_1.Score
}

func (p *PlayerRankInfo) GetRank1TopScore() int32 {
	if p.Rank_1 == nil {
		return 0
	}

	return p.Rank_1.TopScore
}

type PlayerRankingTmp struct {
	ID       string `bson:"_id"`       // idx
	Rank     int32  `bson:"rank"`      // 排名
	Token    string `bson:"token"`     // 钱包地址
	Score    int32  `bson:"score"`     // 分数
	DateTime int64  `bson:"date_time"` // 时间点
}
