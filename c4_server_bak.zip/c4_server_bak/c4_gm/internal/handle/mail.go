package handle

import (
	"c4_center/khttp"
	"c4_center/utils"
	"encoding/json"
)

// 定义message struct
type Mail struct {
	Title   string      `json:"title"`   // 标题
	Content string      `json:"content"` // 内容
	Items   []Item      `json:"items"`   // 道具列表
	Target  []Target    `json:"target"`  // 目标用户
	Other   interface{} `json:"other"`   // 其他参数
}

type Item struct {
	Id  int32 `json:"id"`  // Id
	Num int64 `json:"num"` // 数量
}

// target参数目前没用，等邮件系统出来
type Target struct {
	Type string      `json:"type"` // 类型 例：expire_time  list_role
	Args interface{} `json:"args"` // 参数 例：1667870797   xxxxxxxxx
}

// 发邮件
func SendMail(ctx khttp.Context) {

	ctx.Request().ParseForm()
	pass := ctx.Request().FormValue("pass")
	message := ctx.Request().FormValue("message")
	if pass == "" || message == "" {
		ReturnJson(ctx, -1, "param is null", nil)
		return
	}
	// 验证pass
	sign := utils.GetMd5String(KEY + message)
	if pass != sign {
		ReturnJson(ctx, -2, "pass error", nil)
		return
	}
	// 解析message
	var mail = Mail{}
	if err := json.Unmarshal([]byte(message), &mail); err != nil {
		ReturnJson(ctx, -1, "params error", nil)
		return
	}
	err := SaveToMongo(mail)
	if err != nil {
		ReturnJson(ctx, -3, err.Error(), nil)
		return
	}

	ReturnJson(ctx, 0, "success", nil)
}

func GetMail(ctx khttp.Context) {
	var items []Item
	items = append(items, Item{Id: 101, Num: 100})
	items = append(items, Item{Id: 201, Num: 4})

	var target []Target
	target = append(target, Target{Type: "list_role", Args: []string{"wangjin1"}})

	mail := Mail{
		Title:   "发奖",
		Content: "发奖内容",
		Items:   items,
		Target:  target,
		Other:   "",
	}

	message, _ := json.Marshal(mail)
	pass := utils.GetMd5String(KEY + string(message))
	str := `pass=` + pass + `&message=` + string(message)

	ctx.ResponseWriter().Write([]byte(str))
}

// 直接保存mongo
func SaveToMongo(mail Mail) error {
	//for _, v := range mail.Target {
	//	switch v.Type {
	//	case "list_role":
	//		for _, uids := range v.Args.([]interface{}) {
	//			uida := strings.Split(uids.(string), ",")
	//			for _, u := range uida {
	//				fmt.Println("user_id", u)
	//				// 判断账号表有没有
	//				var account cmongo.Account
	//				kmongo.GetOne(context.TODO(), kmongo.AccountCollection, &account, bson.M{"user_id": u})
	//				if len(account.ID) <= 0 {
	//					logrus.Warnf("account not found -> user_id: %v", u)
	//					continue
	//				}
	//				for _, i := range mail.Items {
	//					fmt.Println("item_id", i.Id, i.Num)
	//					// 插入数据
	//					conf := game_config.ItemConfigInstant.GetInfo(i.Id)
	//					var info *cmongo.Item
	//					if conf.MainType == game_config.MainType_Box && conf.SubType == game_config.SubType_BoxGrade {
	//						item, err := item.GetInitBoxSlot(u, i.Id)
	//						if err != nil {
	//							logrus.Warn(err.Error())
	//							continue
	//						}
	//						info = item
	//					} else {
	//						info = item.GetInitItem(u, i.Id, i.Num)
	//					}
	//					if err := item.InsertUpdateItem(info); err != nil {
	//						return fmt.Errorf("insert item error -> user_id: %v", u)
	//					}
	//				}
	//			}
	//		}
	//	}
	//}

	return nil
}

// 发到邮件服务
func SaveToMail(mail Mail) error {
	return nil
}
