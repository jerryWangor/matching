package cmongo

// 圣诞每日掉落上限
type XmasLimit struct {
	ID       string `bson:"_id"`       // idx
	UserID   string `bson:"user_id"`   // 所属玩家ID
	HeroID   string `bson:"hero_id"`   //所属英雄ID
	LimitNum int32  `bson:"limit_num"` // 限购数量
}
