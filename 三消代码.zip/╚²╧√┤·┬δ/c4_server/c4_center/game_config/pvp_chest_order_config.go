package game_config

type PVPChestOrderData struct {
	OrderId   int32 `tb_name:"顺序"`
	QualityId int32 `tb_name:"品质类型Id"`
}

var PVPChestOrderConfigInstant *PVPChestOrderConfig

type PVPChestOrderConfig struct {
	PVPChestOrderData []*PVPChestOrderData
	Infos             map[int32]*PVPChestOrderData
}

func InitPVPChestOrderConfig(path string) {
	PVPChestOrderConfigInstant = &PVPChestOrderConfig{Infos: make(map[int32]*PVPChestOrderData)}
	//加载
	LoadJsonFile(path+"/PVPChestOrderData.json", PVPChestOrderConfigInstant)
	//初始化
	PVPChestOrderConfigInstant.InitIndex()
}

func (s *PVPChestOrderConfig) InitIndex() {
	for i, v := range s.PVPChestOrderData {
		s.Infos[v.OrderId] = s.PVPChestOrderData[i]
	}
}

func (s *PVPChestOrderConfig) GetInfo(id int32) *PVPChestOrderData {
	return s.Infos[id]
}

func (s *PVPChestOrderConfig) GetOrder(id int32) int32 {
	if _, ok := s.Infos[id]; ok {
		return id
	}

	return 1
}
