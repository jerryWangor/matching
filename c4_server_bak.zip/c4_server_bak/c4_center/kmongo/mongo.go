package kmongo

import (
	"context"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.mongodb.org/mongo-driver/mongo/readpref"
)

var (
	Client                     *mongo.Client
	AccountCollection          *mongo.Collection
	HeroCollection             *mongo.Collection
	ItemCollection             *mongo.Collection
	PlayerRankInfoCollection   *mongo.Collection
	SignCollection             *mongo.Collection
	ShopBuyLimitCollection     *mongo.Collection
	PlayerRankingTmpCollection *mongo.Collection
	PayOrderCollection       *mongo.Collection
)

func Init(dbname string, opts ...*options.ClientOptions) {
	client, err := mongo.Connect(context.TODO(), opts...)
	if err != nil {
		panic(err)
	}

	// Ping the primary
	if err := client.Ping(context.TODO(), readpref.Primary()); err != nil {
		panic(err)
	}
	Client = client

	//account
	AccountCollection = client.Database(dbname).Collection("account")
	//hero
	HeroCollection = client.Database(dbname).Collection("hero")
	//item
	ItemCollection = client.Database(dbname).Collection("item")
	//sign
	SignCollection = client.Database(dbname).Collection("sign")
	//player_score
	PlayerRankInfoCollection = client.Database(dbname).Collection("player_rank_info")
	//shop buy limit
	ShopBuyLimitCollection = client.Database(dbname).Collection("shop_buy_limit")
	//player ranking
	PlayerRankingTmpCollection = client.Database(dbname).Collection("player_ranking_tmp")
	//pay order
	PayOrderCollection = client.Database(dbname).Collection("pay_order")
}

func GetOne(ctx context.Context, collection *mongo.Collection, rValue, filter interface{}, opts ...*options.FindOneOptions) error {
	return collection.FindOne(ctx, filter, opts...).Decode(rValue)
}

func Get(ctx context.Context, collection *mongo.Collection, rValue, filter interface{}, opts ...*options.FindOptions) {
	result, err := collection.Find(ctx, filter, opts...)
	if err != nil {
		return
	}

	result.All(ctx, rValue)
}

func Count(ctx context.Context, collection *mongo.Collection, filter interface{}, opts ...*options.CountOptions) int64 {
	result, _ := collection.CountDocuments(ctx, filter, opts...)
	return result
}

func UpdateOne(ctx context.Context, collection *mongo.Collection, filter interface{}, update interface{}, opts ...*options.UpdateOptions) bool {
	_, err := collection.UpdateOne(ctx, filter, update, opts...)
	return err == nil
}

func UpdateMany(ctx context.Context, collection *mongo.Collection, filter interface{}, update interface{}, opts ...*options.UpdateOptions) bool {
	_, err := collection.UpdateMany(ctx, filter, update, opts...)
	return err == nil
}

func DeleteOne(ctx context.Context, collection *mongo.Collection, filter interface{}, opts ...*options.DeleteOptions) bool {
	_, err := collection.DeleteOne(ctx, filter, opts...)
	return err == nil
}

func DeleteMany(ctx context.Context, collection *mongo.Collection, filter interface{}, opts ...*options.DeleteOptions) bool {
	_, err := collection.DeleteMany(ctx, filter, opts...)
	return err == nil
}

func InsertOne(ctx context.Context, collection *mongo.Collection, document interface{}, opts ...*options.InsertOneOptions) bool {
	_, err := collection.InsertOne(ctx, document, opts...)
	return err == nil
}

func InsertMany(ctx context.Context, collection *mongo.Collection, document []interface{}, opts ...*options.InsertManyOptions) bool {
	_, err := collection.InsertMany(ctx, document, opts...)
	return err == nil
}

func ReplaceOne(ctx context.Context, collection *mongo.Collection, filter interface{}, replace interface{}, opts ...*options.ReplaceOptions) bool {
	_, err := collection.ReplaceOne(ctx, filter, replace, opts...)
	return err == nil
}
