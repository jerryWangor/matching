package game_config

type ChessColorGroupData struct {
	ChessColor     int32 `tb_name:"棋子颜色组"`
	ChessColorType int32 `tb_name:"颜色种类"`
	Scale          int32 `tb_name:"抽取权重"`
}

var ChessColorGroupConfigInstant *ChessColorGroupConfig

type ChessColorGroupConfig struct {
	ChessColorGroupData []*ChessColorGroupData
	Infos               map[int32][]*ChessColorGroupData //{key = 技能库ID, value = []技能信息}
}

func InitChessColorGroupConfig(path string) {
	ChessColorGroupConfigInstant = &ChessColorGroupConfig{Infos: make(map[int32][]*ChessColorGroupData)}
	//加载
	LoadJsonFile(path+"/ChessColorGroupData.json", ChessColorGroupConfigInstant)
	//初始化
	ChessColorGroupConfigInstant.InitIndex()
}

func (s *ChessColorGroupConfig) InitIndex() {
	for i, v := range s.ChessColorGroupData {
		s.Infos[v.ChessColor] = append(s.Infos[v.ChessColor], s.ChessColorGroupData[i])
	}
}

//取得指定组内所有技能列表
func (hc *ChessColorGroupConfig) GetInfo(id int32) []*ChessColorGroupData {
	return hc.Infos[id]
}
