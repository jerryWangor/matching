package battle

import (
	"c4_center/container/cmongo"
	"fmt"
	"math/rand"
	"testing"
	"time"
)

func TestSkill(t *testing.T) {
	a := GetHero("0", "0", "abc", 1, 10, 10)
	b := GetHero("1", "0", "abc", 2, 10, 10)
	c := GetHero("2", "0", "abc", 3, 10, 10)
	d := GetHero("3", "0", "abc", 4, 10, 10)
	e := GetHero("4", "0", "abc", 5, 10, 10)

	aa := GetHero("5", "0", "ccc", 1, 10, 10)
	bb := GetHero("6", "0", "ccc", 2, 3, 10)
	cc := GetHero("7", "0", "ccc", 3, 10, 10)
	dd := GetHero("8", "0", "ccc", 4, 10, 10)
	ee := GetHero("9", "0", "ccc", 6, 10, 10)

	v := GetEffectValue(101001, a, b)
	fmt.Println(v)

	ret := &ScopeHero{}
	setScopeBig(ret, 4, a, []*BattleHero{a, b, c, d, e}, []*BattleHero{aa, bb, cc, dd, ee})
	setScopeSmall(ret, 8, 2)
	setScope(ret, 3)
}

func GetHero(idx, gen, userid string, pos, hp, att int32) *BattleHero {
	h := &BattleHero{Hero: &cmongo.Hero{Gene: gen, UserID: userid, Level: 1, Pos: pos, CurHp: hp}}
	h.LoadHeroConfig()
	h.SetInitSkill()
	h.LoadSkillConfig()
	h.SetChessColor()
	return h
}

func TestRan(t *testing.T) {
	aaa := 30 * int64(time.Second) / int64(3)
	time.Sleep(time.Duration(aaa))

	for i := 0; i < 100000; i++ {
		ll := append([]string{}, fmt.Sprintf("%02v", rand.Int31n(100)), fmt.Sprintf("%02v", rand.Int31n(100)), fmt.Sprintf("%01v", rand.Int31n(10)))
		ShuffleSlice(ll)

		d := fmt.Sprintf("%v%v%v", ll[0], ll[1], ll[2])
		fmt.Println(d)
	}

}

func ShuffleSlice[T any](slice []T) {
	r := rand.New(rand.NewSource(time.Now().Unix()))
	for len(slice) > 0 {
		n := len(slice)
		randIndex := r.Intn(n)
		slice[n-1], slice[randIndex] = slice[randIndex], slice[n-1]
		slice = slice[:n-1]
	}
}
