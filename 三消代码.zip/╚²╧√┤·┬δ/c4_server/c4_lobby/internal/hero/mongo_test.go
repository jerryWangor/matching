package hero

import (
	"c4_center/kmongo"
	"context"
	"testing"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func TestMongo(t *testing.T) {
	kmongo.Init("test", options.Client().ApplyURI("mongodb://192.168.1.45:27017/test?maxPoolSize=100&authSource=admin"))

	// LoadHeroByUserId("aaaa")

	// LoadHeroByIdx("6343d8204133f499586834bc")

	kmongo.UpdateMany(context.TODO(), kmongo.HeroCollection, bson.M{"user_id": "123", "pos": bson.M{"$ne": 0}}, bson.M{"$set": bson.M{"pos": 0}})

	// kmongo.UpdateOne(context.TODO(), kmongo.HeroCollection, bson.M{"_id": "6343d8204133f499586834bc", "state": bson.M{"$ne": -1}}, bson.M{"$set": bson.M{"pos": 1}})
}
