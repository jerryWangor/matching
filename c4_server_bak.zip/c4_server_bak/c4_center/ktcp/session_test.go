package ktcp

import (
	"fmt"
	"sync"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewTCPSession(t *testing.T) {
	var s *session
	assert.NotPanics(t, func() {
		s = newSession(nil, &sessionOption{})
	})
	assert.NotNil(t, s)
	assert.NotNil(t, s.closed)
	assert.NotNil(t, s.respQueue)
}

func TestTCPSession_close(t *testing.T) {
	sess := newSession(nil, &sessionOption{})
	wg := sync.WaitGroup{}
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			sess.Close() // goroutine safe
		}()
	}
	wg.Wait()
	_, ok := <-sess.closed
	assert.False(t, ok)
}

func TestTCPSession_ID(t *testing.T) {
	sess := newSession(nil, &sessionOption{})
	assert.NotEmpty(t, sess.id)
	assert.Equal(t, sess.ID(), sess.id)
}

func TestSessionFlag(t *testing.T) {
	// var flag1 int64 = 1<<0
	var flag2 int64 = 1 << 1
	var flag3 int64 = 1 << 12

	var flag int64 = 0

	flag |= flag2

	fmt.Println(flag)

	flag |= flag3

	fmt.Println(flag)

	// fmt.Println(flag&(1<<12) != 0)

	flag &= ^flag3
	// fmt.Println(flag&(1<<12) != 0)
	fmt.Println(flag)

	flag &= ^flag2
	fmt.Println(flag)
}
