package game_config

type SignRewardData struct {
	SignDay    int32    `tb_name:"签到天数"`
	SignReward []string `tb_name:"奖励内容"`
}

var SignRewardConfigInstant *SignRewardConfig

type SignRewardConfig struct {
	SignRewardData []*SignRewardData
	Infos          map[int32]*SignRewardData //key == Id
}

func InitSignRewardConfig(path string) {
	SignRewardConfigInstant = &SignRewardConfig{Infos: make(map[int32]*SignRewardData)}
	//加载
	LoadJsonFile(path+"/SignRewardData.json", SignRewardConfigInstant)
	//初始化
	SignRewardConfigInstant.InitIndex()
}

func (h *SignRewardConfig) InitIndex() {
	for i, _ := range h.SignRewardData {
		h.Infos[h.SignRewardData[i].SignDay] = h.SignRewardData[i]
	}
}

func (h *SignRewardConfig) GetInfo(id int32) *SignRewardData {
	data, ok := h.Infos[id]
	if !ok {
		return nil
	}
	return data
}
