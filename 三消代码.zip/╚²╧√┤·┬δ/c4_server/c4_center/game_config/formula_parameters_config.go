package game_config

type FormulaParametersData struct {
	ID              int32 `tb_name:"公式参数ID"`
	BaseScore       int32 `tb_name:"基础积分"`
	AddRate         int32 `tb_name:"胜利系数"`
	ReduceRate      int32 `tb_name:"失败系数"`
	AddScore_Min    int32 `tb_name:"最低胜利加分"`
	ReduceScore_Max int32 `tb_name:"最高失败扣分"`
}

var FormulaParametersConfigInstant *FormulaParametersConfig

type FormulaParametersConfig struct {
	FormulaParametersData []*FormulaParametersData
	Infos                 map[int32]*FormulaParametersData
}

func InitFormulaParametersConfig(path string) {
	FormulaParametersConfigInstant = &FormulaParametersConfig{Infos: make(map[int32]*FormulaParametersData)}
	//加载
	LoadJsonFile(path+"/FormulaParametersData.json", FormulaParametersConfigInstant)
	//初始化
	FormulaParametersConfigInstant.InitIndex()
}

func (s *FormulaParametersConfig) InitIndex() {
	for i, v := range s.FormulaParametersData {
		s.Infos[v.ID] = s.FormulaParametersData[i]
	}
}

func (s *FormulaParametersConfig) GetInfo(id int32) *FormulaParametersData {
	return s.Infos[id]
}
