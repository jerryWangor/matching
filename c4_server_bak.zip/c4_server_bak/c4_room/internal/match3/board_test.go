package match3

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"
)

func Sim() {
	var msg string
	reader := bufio.NewReader(os.Stdin)

	var row, col int64
	var b *Board

	for {
		msg, _ = reader.ReadString('\n')

		switch msg {
		case "init":
			row, _ = strconv.ParseInt(strings.Split(msg, " ")[0], 10, 32)
			col, _ = strconv.ParseInt(strings.Split(msg, " ")[1], 10, 32)
			b = NewBoard(int32(row), int32(col))
			b.InitBoard()
			b.Print()
		case "swap":
			sx, _ := strconv.ParseInt(strings.Split(strings.Split(msg, " ")[0], ":")[0], 10, 32)
			sy, _ := strconv.ParseInt(strings.Split(strings.Split(msg, " ")[0], ":")[1], 10, 32)
			dx, _ := strconv.ParseInt(strings.Split(strings.Split(msg, " ")[1], ":")[0], 10, 32)
			dy, _ := strconv.ParseInt(strings.Split(strings.Split(msg, " ")[1], ":")[1], 10, 32)
			b.SwapManual(int32(sx), int32(sy), int32(dx), int32(dy))
			b.Print()
		case "match":
			b.GetMatches()
			b.Print()
		case "falldown":
			b.FallDown()
			b.Print()
		case "newpiece":
			b.AutoCreateNewPiece()
			b.Print()
		}
	}
}

func TestTicket(t *testing.T) {
	Delay := 5000 * int64(time.Millisecond)
	Ticker := *time.NewTicker(time.Duration(Delay))

	for a := range Ticker.C {
		fmt.Println(a)
	}
}

func TestB(t *testing.T) {
	// Sim()
	// var ret []*Piece

	// tt := NewPiece(0, 0, 0)
	// ret = append(ret, tt)

	// for i := 0; i < 10; i++ {
	// 	ret = append(ret, NewPiece(0, int32(i), int32(i)))
	// }

	// fmt.Println(slices.Contains(ret, tt))

	row, col := 3, 3
	b := NewBoard(int32(row), int32(col))
	b.InitBoard()

	Pr := func() {
		for i := row - 1; i >= 0; i-- {
			for j := 0; j < col; j++ {
				fmt.Printf("%v:%v->%v | ", b.Pieces[i][j].PosX, b.Pieces[i][j].PosY, b.Pieces[i][j].PType)
			}
			fmt.Println()
		}
		fmt.Println()
	}

	Pr()

	b.Shuffle()
	Pr()

	// for i := 0; i < 8; i++ {
	// 	// for j := 0; j < 8; j++ {
	// 	fmt.Printf("%v :", b.Pieces[0][i].PType)
	// 	// }
	// }
	// fmt.Println()

	// b.GetMatches()

	fmt.Println(b.SwapManual(0, 0, 1, 0))
	fmt.Println("swap")
	Pr()

	b.GetMatches()
	fmt.Println("match")
	Pr()

	b.FallDown()
	fmt.Println("falldown")
	Pr()

	b.AutoCreateNewPiece()
	fmt.Println("new piece")
	Pr()

	/* 	Pr()

	   	b.Pieces[0][1].PType = 0
	   	b.Pieces[1][1].PType = 0
	   	b.Pieces[2][1].PType = 0

	   	b.FallDown()

	   	Pr() */

	// b.AutoCreateNewPiece()
	// Pr()
	fmt.Printf("isdead : %v ", b.IsDead())
}

func TestC(t *testing.T) {
	b := NewBoard(int32(8), int32(8))
	b.InitBoard()

	// b.CheckIntrval(true, NewPiece(4, 3, 2), NewPiece(7, 3, 2))

	// aaa := b.GetMatches()

	fmt.Println(b.IsDead())

}
