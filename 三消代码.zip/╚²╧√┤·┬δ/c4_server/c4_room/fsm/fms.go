package fsm

import (
	"context"

	"github.com/sirupsen/logrus"
)

// FSM is the finite state machine
type FSM struct {
	// current state
	state State
	// current business
	businessName BusinessName
	// [business] -> [state] -> [event] ->[ eventEntity->handler]
	stateMachineMap map[BusinessName]map[State]map[EventName]*EventEntity
}

// NewFSM creates a new fsm
func NewFSM(businessName BusinessName, initState State) (fsm *FSM) {
	fsm = new(FSM)
	fsm.state = initState
	fsm.businessName = businessName
	fsm.stateMachineMap = make(map[BusinessName]map[State]map[EventName]*EventEntity)
	return
}

// Call the state's event func
func (f *FSM) Call(eventName EventName, opts ...ParamOption) (State, error) {
	businessMap, ok := f.stateMachineMap[f.businessName]
	if !ok {
		return f.getState(), UnKnownBusinessError{businessName: f.businessName}
	}
	events, ok := businessMap[f.getState()]
	if !ok || events == nil {
		return f.getState(), UnKnownStateError{businessName: f.businessName, state: f.getState()}
	}

	param := new(Param)
	// Default ctx
	param.Ctx = context.TODO()
	for _, fn := range opts {
		fn(param)
	}

	eventEntity, ok := events[eventName]
	if !ok || eventEntity == nil {
		return f.getState(), UnKnownEventError{businessName: f.businessName, state: f.getState(), event: eventName}
	}

	// call eventName func
	state, err := eventEntity.execute(param)
	if err != nil {
		return f.getState(), err
	}
	oldState := f.getState()
	f.setState(state)
	logrus.Infof("eventName:", eventName, "beforeState:", oldState, "afterState:", f.getState())
	return f.getState(), nil
}

//RegisterStateMachine register state machine
func (f *FSM) RegisterStateMachine(state State, events ...*EventEntity) {
	if len(events) == 0 {
		return
	}

	if f.stateMachineMap[f.businessName] == nil {
		f.stateMachineMap[f.businessName] = make(map[State]map[EventName]*EventEntity)
	}
	if f.stateMachineMap[f.businessName][state] == nil {
		f.stateMachineMap[f.businessName][state] = make(map[EventName]*EventEntity)
	}

	for _, event := range events {
		if event == nil || event.eventName == "" || event.eventFunc == nil {
			continue
		}
		f.stateMachineMap[f.businessName][state][event.eventName] = event
	}
}

// getState get the state
func (f *FSM) getState() State {
	return f.state
}

// setState set the state
func (f *FSM) setState(newState State) {
	f.state = newState
}
