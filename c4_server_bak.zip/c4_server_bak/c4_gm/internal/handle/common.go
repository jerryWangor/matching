package handle

import (
	"c4_center/khttp"
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/registry"
	"c4_gm/gm_registry"
	"context"
	"encoding/json"
	"time"

	"github.com/sirupsen/logrus"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

var Codec ktcp.Codec

// 接收到的数据格式: pass=xxxxx&message={定好的json数据}
// 使用key加密规则: key=md5(KEY+message)
const KEY = "153dc7b62ec637173a4f3f288e252e6c"

type JsonResp struct {
	Code    int32
	Message string
	Data    interface{}
}

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

func NotFound(ctx khttp.Context) {
	logrus.Errorf("cant find router for url: %s", ctx.Request().URL)
}

func ReturnJson(ctx khttp.Context, code int32, message string, data interface{}) {
	jdata := JsonResp{Code: code, Message: message, Data: data}
	jsondata, _ := json.Marshal(jdata)
	ctx.ResponseWriter().Write(jsondata)
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}

func PayRpc(packet *kproto.Packet) (*kproto.SendResp, error) {
	//get grpc service
	service, err := gm_registry.EtcdClient.GetServiceInDiscovery(gm_registry.PAY_SERVICE)
	if err != nil {
		return nil, err
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}

	defer conn.Close()

	//client
	client := kproto.NewPayServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*30)
	defer cancel()

	//request
	resp, err := client.PayRpc(ctx, &kproto.SendReq{UserId: "", Packet: packet})
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func GateRpc(packet *kproto.Packet, service *registry.ServiceInstance) (*kproto.SendResp, error) {
	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}

	defer conn.Close()

	//client
	client := kproto.NewGateServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	resp, err := client.GateRpc(ctx, &kproto.SendReq{UserId: "", Packet: packet})
	if err != nil {
		return nil, err
	}

	return resp, nil
}

func RoomRpc(packet *kproto.Packet, service *registry.ServiceInstance) (*kproto.SendResp, error) {
	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}

	defer conn.Close()

	//client
	client := kproto.NewRoomServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	resp, err := client.RoomCreateRpc(ctx, &kproto.SendReq{UserId: "", Packet: packet})
	if err != nil {
		return nil, err
	}

	return resp, nil
}
