package utils

import (
	"runtime"

	"github.com/sirupsen/logrus"
)

const (
	MaxRandPro         = 10000
	TimeMinuteToSecond = 60
	TimeHourToSecond   = TimeMinuteToSecond * 60
)

func HasFlag(val, flag int64) bool {
	return val&flag != 0
}

func SetFlag(val, flag int64) int64 {
	val |= flag
	return val
}

func ClearFlag(val, flag int64) int64 {
	val &= ^flag
	return val
}

func Max64(x, y int64) int64 {
	if x > y {
		return x
	}

	return y
}

func Min64(x, y int64) int64 {
	if x < y {
		return x
	}

	return y
}

func Max(x, y int32) int32 {
	if x > y {
		return x
	}

	return y
}

func Min(x, y int32) int32 {
	if x < y {
		return x
	}

	return y
}

func InArray[T int32 | int64 | string, A []T](arr A, s T) bool {
	m := make(map[T]int)
	for _, v := range arr {
		m[v] = 1
	}
	if _, ok := m[s]; ok {
		return true
	}
	return false
}

func HandleCrash() {
	if r := recover(); r != nil {
		PrintStack()
		logrus.Error(r)
	}
}

func PrintStack() {
	var buf [4096]byte
	n := runtime.Stack(buf[:], false)
	logrus.Error(string(buf[:n]))
}
