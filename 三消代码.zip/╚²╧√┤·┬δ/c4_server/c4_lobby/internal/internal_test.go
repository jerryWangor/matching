package internal

import (
	"c4_center/kmongo"
	"c4_center/kproto"
	"testing"

	"go.mongodb.org/mongo-driver/mongo/options"
)

func TestSplit(t *testing.T) {
	AddHero("aaa", "@addhero   111   222   333   444   ", nil)
}

func TestApi(t *testing.T) {
	// var account cmongo.Account
	// kmongo.GetOne(context.TODO(), kmongo.AccountCollection, &account, bson.M{"user_id": req.UserId})

	GetBalls("0xbe6c996cef32a8af6bfaade5a9b75fa11176273d")
}

func TestRank(t *testing.T) {
	kmongo.Init("test", options.Client().ApplyURI("mongodb://192.168.1.45:27017/test?maxPoolSize=100&authSource=admin"))

	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_RANKREWARD_REQ_ID), &kproto.LOBBY_RANKREWARD_REQ{})
	req := &kproto.SendReq{UserId: "eee", Packet: packet}

	RankInfo(req)

	packet, _ = getPacket(uint32(kproto.MSG_LOBBY_RECEIVE_RANKREWARD_REQ_ID), &kproto.LOBBY_RECEIVE_RANKREWARD_REQ{Cid: 1})
	req = &kproto.SendReq{UserId: "eee", Packet: packet}

	ReceiveRankReward(req)
}
