package router

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_gate/internal"
	"github.com/sirupsen/logrus"
)

// 获取商店信息
func LobbyGetShop(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_SHOP_RESP_ID), &kproto.LOBBY_SHOP_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_SHOP_RESP_ID), &kproto.LOBBY_SHOP_RESP{Code: -2})
	}
}

// 商店购买商品
func LobbyShopBuy(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_SHOP_BUY_RESP_ID), &kproto.LOBBY_SHOP_BUY_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_SHOP_BUY_RESP_ID), &kproto.LOBBY_SHOP_BUY_RESP{Code: -2})
	}
}
