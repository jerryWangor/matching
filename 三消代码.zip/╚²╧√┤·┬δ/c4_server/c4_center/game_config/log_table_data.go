package game_config

type LogTableData struct {
	ModelName string                    `tb_name:"model"`
	TableName string                    `tb_name:"表名"`
	Split     int                       `tb_name:"是否分表：0不分表 1分月 2分天"`
	Sql       string                    `tb_name:"sql"`
	Field     map[string]*LogTableField `tb_name:"字段信息"`
}

type LogTableField struct {
	Name string
	Type string
	Key  string
}

var LogTableConfigInstant *LogTableConfig

type LogTableConfig struct {
	LogTableData    []*LogTableData
	Infos           map[string]*LogTableData
	NotSplitInfos   map[string]*LogTableData
	SplitMonthInfos map[string]*LogTableData
	SplitDayInfos   map[string]*LogTableData
}

func InitLogTableConfig(path string) {
	LogTableConfigInstant = &LogTableConfig{
		Infos:           make(map[string]*LogTableData),
		NotSplitInfos:   make(map[string]*LogTableData),
		SplitMonthInfos: make(map[string]*LogTableData),
		SplitDayInfos:   make(map[string]*LogTableData),
	}
	//加载
	LoadJsonFile(path+"/LogTableData.json", LogTableConfigInstant)
	//初始化
	LogTableConfigInstant.InitIndex()
}

func (s *LogTableConfig) InitIndex() {
	for i, v := range s.LogTableData {
		//s.Infos[v.ModelName] = append(s.Infos[v.ModelName], s.LogTableData[i])
		s.Infos[v.TableName] = s.LogTableData[i]
		switch v.Split {
		case 0:
			s.NotSplitInfos[v.TableName] = s.LogTableData[i]
			break
		case 1:
			s.SplitMonthInfos[v.TableName] = s.LogTableData[i]
			break
		case 2:
			s.SplitDayInfos[v.TableName] = s.LogTableData[i]
			break
		}
	}
}

//取得指定组内所有技能列表
func (s *LogTableConfig) GetInfo(n string) *LogTableData {
	return s.Infos[n]
}
