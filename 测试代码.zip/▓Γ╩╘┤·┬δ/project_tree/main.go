package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"time"
)

func main() {
	/**
	遍历文件夹：
	*/

	//dirname := "D:\\代码包\\game_server_frame\\stateless_game\\cherry"
	//listFiles(dirname, 0)

	fmt.Println(8 / 4)

	a := 1
	go func() {
		a = 2
		fmt.Println("子goroutine。。", a)
	}()
	a = 3
	time.Sleep(1 * time.Second)
	fmt.Println("main goroutine。。", a)
}

func listFiles(dirname string, level int) {
	// level用来记录当前递归的层次
	// 生成有层次感的空格
	s := "|--"
	for i := 0; i < level; i++ {
		s = "|   " + s
	}

	fileInfos, err := ioutil.ReadDir(dirname)
	if err != nil {
		log.Fatal(err)
	}
	for _, fi := range fileInfos {
		filename := dirname + "/" + fi.Name()
		if fi.IsDir() {
			fmt.Printf("%s%s\n", s, fi.Name())
		}
		if fi.IsDir() {
			//继续遍历fi这个目录
			listFiles(filename, level+1)
		}
	}
}
