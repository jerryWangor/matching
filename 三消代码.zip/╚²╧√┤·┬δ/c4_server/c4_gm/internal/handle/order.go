package handle

import (
	"c4_center/container/cmongo"
	"c4_center/khttp"
	"c4_center/kproto"
)

// 订单检查
func OrderCheck(ctx khttp.Context) {
	ctx.Request().ParseForm()
	orderId := ctx.Request().FormValue("order_id")
	hashData := ctx.Request().FormValue("hash_data")
	if len(orderId) != cmongo.ORDER_ID_LENGTH || len(hashData) == 0 {
		ReturnJson(ctx, -1, "param error", nil)
		return
	}

	// grpc请求充值服务器
	info := &kproto.PAY_ORDER_CHECK_REQ{
		OrderId:  orderId,
		HashData: hashData,
	}
	packet, _ := getPacket(uint32(kproto.MSG_PAY_ORDER_CHECK_REQ_ID), info)
	resp, err := PayRpc(packet)
	if err != nil {
		ReturnJson(ctx, -2, err.Error(), nil)
		return
	}

	// code=0才是成功
	if resp.Code == 0 {
		var respData kproto.PAY_ORDER_CHECK_RESP
		if err := Codec.Decode(resp.Packet.Data, &respData); err != nil {
			ReturnJson(ctx, -3, "resp data error", nil)
		}
		ReturnJson(ctx, 0, respData.Msg, nil)
	} else {
		ReturnJson(ctx, -4, "internal error", nil)
	}
}

// 补单
func OrderSupple(ctx khttp.Context) {
	ctx.Request().ParseForm()
	orderId := ctx.Request().FormValue("order_id")
	hashData := ctx.Request().FormValue("hash_data")
	if len(orderId) != cmongo.ORDER_ID_LENGTH || len(hashData) == 0 {
		ReturnJson(ctx, -1, "param error", nil)
		return
	}

	// grpc请求充值服务器
	info := &kproto.PAY_ORDER_SUPPLE_REQ{
		OrderId:  orderId,
		HashData: hashData,
	}
	packet, _ := getPacket(uint32(kproto.MSG_PAY_ORDER_SUPPLE_REQ_ID), info)
	resp, err := PayRpc(packet)
	if err != nil {
		ReturnJson(ctx, -2, err.Error(), nil)
		return
	}

	// code=0才是成功
	if resp.Code == 0 {
		var respData kproto.PAY_ORDER_SUPPLE_RESP
		if err := Codec.Decode(resp.Packet.Data, &respData); err != nil {
			ReturnJson(ctx, -3, "resp data error", nil)
		}
		ReturnJson(ctx, 0, respData.Msg, nil)
	} else {
		ReturnJson(ctx, -4, "internal error", nil)
	}
}
