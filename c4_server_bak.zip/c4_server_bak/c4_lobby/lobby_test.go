package main

import (
	"c4_center/container/cmongo"
	"c4_center/klog"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_center/registry/etcd"
	"c4_center/utils"
	"c4_lobby/config"
	"c4_lobby/internal/item"
	lobby_register "c4_lobby/lobby_registry"
	"context"
	"fmt"
	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"testing"
	"time"
)

var Codec ktcp.Codec
var lobbyGrpc = "lobby-grpc"

//var userId = "qwe1234"

var userId = "wangjin"

func InitConfig() {
	//初始化配置
	config.Init("app.ini")
	//初始化游戏配置
	config.InitGameConfig()
	//初始化logs
	klog.InitLog(config.LogsConfigInstant.Path, config.LogsConfigInstant.Level)
	//初始化mongo
	kmongo.Init(config.MongoConfigInstant.Mongo_DB, options.Client().ApplyURI(config.MongoConfigInstant.Mongo_addr))

	Codec = &ktcp.ProtobufCodec{}
}

func TestLoadMongodb(t *testing.T) {
	InitConfig()

	info := item.LoadItemByUserIdx(userId, "6360e3d6507f2f9d84a43299")
	fmt.Println(info)
}

func TestAddItem(t *testing.T) {

	InitConfig()

	// 插入道具
	items := make([]interface{}, 0, 0)
	//item1 := item.GetInitItem(userId, 102, 5)
	//items = append(items, item1)
	//
	//item2 := item.GetInitItem(userId, 5002, 4)
	//items = append(items, item2)
	//
	//item3 := item.GetInitItem(userId, 204, 1000)
	//items = append(items, item3)
	////
	//item4 := item.GetInitItem(userId, 1501, 5)
	//items = append(items, item4)

	item5 := item.GetInitItem(userId, 1002, 1)
	items = append(items, item5)

	item6 := item.GetInitItem(userId, 1003, 1)
	items = append(items, item6)

	item7 := item.GetInitItem(userId, 1004, 1)
	items = append(items, item7)

	item8 := item.GetInitItem(userId, 1005, 1)
	items = append(items, item8)

	err := item.InsertUpdateManyItem(items)
	if err != nil {
		fmt.Println(err)
	}
}

func TestAddPlayerRank(t *testing.T) {

	InitConfig()

	// 插入account
	for i := 1; i <= 10000; i++ {
		acc := &cmongo.Account{
			ID:     primitive.NewObjectID().Hex(),
			UserID: "player_" + fmt.Sprintf("%v", i),
			Token:  "token_" + fmt.Sprintf("%v", i),
		}
		kmongo.InsertOne(context.TODO(), kmongo.AccountCollection, acc)
	}

	for i := 1; i <= 10000; i++ {
		pr := cmongo.PlayerRankInfo{
			ID:     primitive.NewObjectID().Hex(),
			UserID: "player_" + fmt.Sprintf("%v", i),
			Rank_1: &cmongo.Rank1Info{
				Score: int32(utils.GetRangeRandNum(int64(0), int64(10000))),
			},
		}
		kmongo.InsertOne(context.TODO(), kmongo.PlayerRankInfoCollection, pr)
	}
}

func TestGrpcGetItemList(t *testing.T) {

	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	//time.Sleep(3 * time.Second)
	//
	//ticker := time.NewTicker(3 * time.Second)
	//
	//go func() {
	//	<-ticker.C
	//}()

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_ITEM_LIST_REQ{}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_ITEM_LIST_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_ITEM_LIST_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Items)
}

func TestGrpcItemUse(t *testing.T) {

	InitConfig()

	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_ITEM_USE_REQ{
		Id:          "638184e3e93f26cee4b0e905",
		TypeId:      1003,
		Num:         1,
		BoxOpenType: 2,
	}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_ITEM_USE_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_ITEM_USE_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Code)
	fmt.Println(respData.Items)
	fmt.Println(respData.Consumes)
}

func TestGrpcBoxSlotUnlock(t *testing.T) {

	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_BOX_SLOT_UNLOCK_REQ{
		Id: "638184e3e93f26cee4b0e905",
	}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_BOX_SLOT_UNLOCK_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
		return
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_BOX_SLOT_UNLOCK_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Item)
}

func TestGrpcHeroLevelUp(t *testing.T) {
	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_HERO_LEVEL_UP_REQ{
		Id: "636f63ded99283b22484cf7d",
	}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_HERO_LEVEL_UP_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
		return
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_HERO_LEVEL_UP_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Code)
	fmt.Println(respData.Level)
	fmt.Println(respData.Consumes)
}

func TestGrpcGetActivity(t *testing.T) {

	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_ACTIVITY_REQ{}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_ACTIVITY_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_ACTIVITY_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Code)
	fmt.Println(respData.Data)
	for _, v := range respData.Data {
		fmt.Println(v.Type)
		fmt.Println(v.State)
		fmt.Println(v.Data)
	}
}

func TestGrpcGetActivityAssign(t *testing.T) {

	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_ACTIVITY_ASSIGN_REQ{
		Type: 1,
	}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_ACTIVITY_ASSIGN_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_ACTIVITY_ASSIGN_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Code)
	fmt.Println(respData.Data)
}

func TestGrpcSignIn(t *testing.T) {
	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_SIGN_IN_REQ{}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_SIGN_IN_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
		return
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_SIGN_IN_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData.Code)
	fmt.Println(respData.Items)
}

func TestGrpcEnterLobby(t *testing.T) {
	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.GATE_ENTER_LOBBY_REQ{}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_GATE_ENTER_LOBBY_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
		return
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.GATE_ENTER_LOBBY_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData)
}

func TestGrpcGetShop(t *testing.T) {
	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_SHOP_REQ{}
	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_SHOP_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
		return
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_SHOP_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	for _, v := range respData.Data {
		fmt.Println(v.Id)
		fmt.Println(v.NEXT_REFRESH_TIME)
		for _, i := range v.Items {
			fmt.Println(i.Id, i.LimitNum, i.BuyNum)
		}
	}
}

func TestGrpcShopBuy(t *testing.T) {
	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_SHOP_BUY_REQ{
		ShopId: 5,
		ItemId: 505,
	}

	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_SHOP_BUY_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
		return
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_SHOP_BUY_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	fmt.Println(respData)
	fmt.Println(respData.GetItems)
	fmt.Println(respData.ConItems)
}

func TestGrpcGetRanking(t *testing.T) {
	InitConfig()
	//初始化etcd
	lobby_register.InitLobbyRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))
	//监听所需etcd服务
	lobby_register.EtcdClient.Watch(lobbyGrpc)

	service, err := lobby_register.EtcdClient.GetServiceInDiscovery(lobbyGrpc)
	if err != nil {
		logrus.Error(err)
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), service.Endpoints[0], grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Error(err)
	}

	defer conn.Close()

	//client
	client := kproto.NewLobbyServiceClient(conn)

	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	info := &kproto.LOBBY_RANKING_REQ{
		Token: "token_1000000",
	}

	//encode
	packet, _ := getPacket(uint32(kproto.MSG_LOBBY_RANKING_REQ_ID), info)
	resp, err := client.LobbyRpc(ctx, &kproto.SendReq{UserId: userId, Packet: packet})
	if err != nil {
		logrus.Error(err)
		return
	}

	//respone
	logrus.Info(resp.Packet.Data)

	//decode
	var respData kproto.LOBBY_RANKING_RESP
	Codec.Decode(resp.Packet.Data, &respData)
	for _, v := range respData.AllData {
		fmt.Println(v.Rank, v.Name, v.Score)
	}
	fmt.Println(respData.MyData)
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}
