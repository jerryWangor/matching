package game_config

// const BasePath = `E:\C4 GIT\c4_server\c4_room\internal\game_config\json`

type TableEnumValue struct {
	Name  string
	Index int32
}

type ChessColorType int32

const (
	ChessColorType_None   = 0 // 空
	ChessColorType_Red    = 1 // 红
	ChessColorType_Blue   = 2 // 蓝
	ChessColorType_Green  = 3 // 绿
	ChessColorType_Yellow = 4 // 黄
	ChessColorType_Purple = 5 // 紫
)

var (
	ChessColorTypeEnumValues = []TableEnumValue{
		{Name: "None", Index: 0},   // 空
		{Name: "Red", Index: 1},    // 红
		{Name: "Blue", Index: 2},   // 蓝
		{Name: "Green", Index: 3},  // 绿
		{Name: "Yellow", Index: 4}, // 黄
		{Name: "Purple", Index: 5}, // 紫
	}
	ChessColorTypeMapperValueByName = map[string]int32{}
	ChessColorTypeMapperNameByValue = map[int32]string{}
)

func (self ChessColorType) String() string {
	name, _ := ChessColorTypeMapperNameByValue[int32(self)]
	return name
}

type SkillType int32

const (
	SkillType_None           = 0 // 空
	SkillType_Normal         = 1 // 普通攻击
	SkillType_Special        = 2 // 必杀技
	SkillType_PassiveAura    = 3 // 永久型被动
	SkillType_PassiveTrigger = 4 // 触发型被动
)

var (
	SkillTypeEnumValues = []TableEnumValue{
		{Name: "None", Index: 0},           // 空
		{Name: "Normal", Index: 1},         // 普通攻击
		{Name: "Special", Index: 2},        // 必杀技
		{Name: "PassiveAura", Index: 3},    // 永久型被动
		{Name: "PassiveTrigger", Index: 4}, // 触发型被动
	}
	SkillTypeMapperValueByName = map[string]int32{}
	SkillTypeMapperNameByValue = map[int32]string{}
)

func (self SkillType) String() string {
	name, _ := SkillTypeMapperNameByValue[int32(self)]
	return name
}

type BindObjType int32

const (
	BindObjType_None                = 0 // 无
	BindObjType_Initiator           = 1 // 发起对象
	BindObjType_Target              = 2 // 目标对象
	BindObjType_InitiatorHomeCenter = 3 // 发起对象的阵营中心
	BindObjType_TargetHomeCenter    = 4 // 目标对象的阵营中心
	BindObjType_InitiatorHead       = 5 // 发起对象的头
)

var (
	BindObjTypeEnumValues = []TableEnumValue{
		{Name: "None", Index: 0},                // 无
		{Name: "Initiator", Index: 1},           // 发起对象
		{Name: "Target", Index: 2},              // 目标对象
		{Name: "InitiatorHomeCenter", Index: 3}, // 发起对象的阵营中心
		{Name: "TargetHomeCenter", Index: 4},    // 目标对象的阵营中心
		{Name: "InitiatorHead", Index: 5},       // 发起对象的头
	}
	BindObjTypeMapperValueByName = map[string]int32{}
	BindObjTypeMapperNameByValue = map[int32]string{}
)

func (self BindObjType) String() string {
	name, _ := BindObjTypeMapperNameByValue[int32(self)]
	return name
}

type EffectType int32

const (
	EffectType_UpdateOriginHP     = 0 // 更新技能发起者血量
	EffectType_UpdateTargetHP     = 1 // 更新作用目标者血量
	EffectType_UpdateOriginPower  = 2 // 更新技能发起者能量
	EffectType_UpdateTargetPower  = 3 // 更新技能作用者能量
	EffectType_PhoneShakeLite     = 4 // 小震动
	EffectType_PhoneShakeSerious  = 5 // 大震动
	EffectType_CameraShakeLite    = 6 // 小震屏
	EffectType_CameraShakeSerious = 7 // 大震屏
	EffectType_UpdateTargetShield = 8 // 更新作用目标者护盾
)

var (
	EffectTypeEnumValues = []TableEnumValue{
		{Name: "UpdateOriginHP", Index: 0},     // 更新技能发起者血量
		{Name: "UpdateTargetHP", Index: 1},     // 更新作用目标者血量
		{Name: "UpdateOriginPower", Index: 2},  // 更新技能发起者能量
		{Name: "UpdateTargetPower", Index: 3},  // 更新技能作用者能量
		{Name: "PhoneShakeLite", Index: 4},     // 小震动
		{Name: "PhoneShakeSerious", Index: 5},  // 大震动
		{Name: "CameraShakeLite", Index: 6},    // 小震屏
		{Name: "CameraShakeSerious", Index: 7}, // 大震屏
		{Name: "UpdateTargetShield", Index: 8}, // 更新作用目标者护盾
	}
	EffectTypeMapperValueByName = map[string]int32{}
	EffectTypeMapperNameByValue = map[int32]string{}
)

func (self EffectType) String() string {
	name, _ := EffectTypeMapperNameByValue[int32(self)]
	return name
}

type Vocation int32

const (
	Vocation_None    = 0 // 无
	Vocation_Tank    = 1 // 坦克
	Vocation_Mage    = 2 // 法师
	Vocation_Ranger  = 3 // 游侠
	Vocation_Support = 4 // 辅助
)

var (
	VocationEnumValues = []TableEnumValue{
		{Name: "None", Index: 0},    // 无
		{Name: "Tank", Index: 1},    // 坦克
		{Name: "Mage", Index: 2},    // 法师
		{Name: "Ranger", Index: 3},  // 游侠
		{Name: "Support", Index: 4}, // 辅助
	}
	VocationMapperValueByName = map[string]int32{}
	VocationMapperNameByValue = map[int32]string{}
)

func (self Vocation) String() string {
	name, _ := VocationMapperNameByValue[int32(self)]
	return name
}

type MainType int32

const (
	MainType_Currency = 1 // 货币
	MainType_Sundries = 2 // 杂物
	MainType_Box      = 3 // 宝箱
)

var (
	MainTypeEnumValues = []TableEnumValue{
		{Name: "Currency", Index: 1}, // 货币
		{Name: "Sundries", Index: 2}, // 杂物
		{Name: "Box", Index: 3},      // 宝箱
	}
	MainTypeMapperValueByName = map[string]int32{}
	MainTypeMapperNameByValue = map[int32]string{}
)

func (self MainType) String() string {
	name, _ := MainTypeMapperNameByValue[int32(self)]
	return name
}

type SubType int32

const (
	SubType_CurrencyGold        = 101 // 货币-金币
	SubType_CurrencyDiamond     = 102 // 货币-钻石
	SubType_CurrencyGrade       = 103 // 货币-排位积分
	SubType_CurrencyM           = 104 // 货币-M币
	SubType_CurrencyLEQ         = 105 // 货币-LEQ币
	SubType_SundriesHeroLevelUp = 201 // 杂物-英雄升级材料
	SubType_SundriesHeroStar    = 202 // 杂物-英雄升星材料
	SubType_SundriesOther       = 203 // 杂物-其他
	SubType_BoxGrade            = 301 // 宝箱-排位宝箱
	SubType_BoxNormal           = 302 // 宝箱-普通宝箱
	SubType_BoxSelect           = 303 // 宝箱-自选宝箱
)

var (
	SubTypeEnumValues = []TableEnumValue{
		{Name: "CurrencyGold", Index: 101},        // 货币-金币
		{Name: "CurrencyDiamond", Index: 102},     // 货币-钻石
		{Name: "CurrencyGrade", Index: 103},       // 货币-排位积分
		{Name: "CurrencyM", Index: 104},           // 货币-M币
		{Name: "CurrencyLEQ", Index: 105},         // 货币-LEQ币
		{Name: "SundriesHeroLevelUp", Index: 201}, // 杂物-英雄升级材料
		{Name: "SundriesHeroStar", Index: 202},    // 杂物-英雄升星材料
		{Name: "SundriesOther", Index: 203},       // 杂物-其他
		{Name: "BoxGrade", Index: 301},            // 宝箱-排位宝箱
		{Name: "BoxNormal", Index: 302},           // 宝箱-普通宝箱
		{Name: "BoxSelect", Index: 303},           // 宝箱-自选宝箱
	}
	SubTypeMapperValueByName = map[string]int32{}
	SubTypeMapperNameByValue = map[int32]string{}
)

func (self SubType) String() string {
	name, _ := SubTypeMapperNameByValue[int32(self)]
	return name
}

type ActivityType int32

const (
	ActivityType_Sign = 1 // 签到活动
)

var (
	ActivityTypeEnumValues = []TableEnumValue{
		{Name: "Sign", Index: 1}, // 签到活动
	}
	ActivityTypeMapperValueByName = map[string]int32{}
	ActivityTypeMapperNameByValue = map[int32]string{}
)

func (self ActivityType) String() string {
	name, _ := ActivityTypeMapperNameByValue[int32(self)]
	return name
}

type DropType int32

const (
	DropType_Independent = 1 // 独立掉落
	DropType_Random      = 2 // 随机掉落
	DropType_Optional    = 3 // 自选
)

var (
	DropTypeEnumValues = []TableEnumValue{
		{Name: "Independent", Index: 1}, // 独立掉落
		{Name: "Random", Index: 2},      // 随机掉落
		{Name: "Optional", Index: 3},    // 自选
	}
	DropTypeMapperValueByName = map[string]int32{}
	DropTypeMapperNameByValue = map[int32]string{}
)

func (self DropType) String() string {
	name, _ := DropTypeMapperNameByValue[int32(self)]
	return name
}

type ConditionaType int32

const (
	ConditionaType_Grade = 1 // 段位
)

var (
	ConditionaTypeEnumValues = []TableEnumValue{
		{Name: "Grade", Index: 1}, // 段位
	}
	ConditionaTypeMapperValueByName = map[string]int32{}
	ConditionaTypeMapperNameByValue = map[int32]string{}
)

func (self ConditionaType) String() string {
	name, _ := ConditionaTypeMapperNameByValue[int32(self)]
	return name
}

func init() {

	for _, v := range ChessColorTypeEnumValues {
		ChessColorTypeMapperValueByName[v.Name] = v.Index
		ChessColorTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range SkillTypeEnumValues {
		SkillTypeMapperValueByName[v.Name] = v.Index
		SkillTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range BindObjTypeEnumValues {
		BindObjTypeMapperValueByName[v.Name] = v.Index
		BindObjTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range EffectTypeEnumValues {
		EffectTypeMapperValueByName[v.Name] = v.Index
		EffectTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range VocationEnumValues {
		VocationMapperValueByName[v.Name] = v.Index
		VocationMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range MainTypeEnumValues {
		MainTypeMapperValueByName[v.Name] = v.Index
		MainTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range SubTypeEnumValues {
		SubTypeMapperValueByName[v.Name] = v.Index
		SubTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range ActivityTypeEnumValues {
		ActivityTypeMapperValueByName[v.Name] = v.Index
		ActivityTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range DropTypeEnumValues {
		DropTypeMapperValueByName[v.Name] = v.Index
		DropTypeMapperNameByValue[v.Index] = v.Name
	}

	for _, v := range ConditionaTypeEnumValues {
		ConditionaTypeMapperValueByName[v.Name] = v.Index
		ConditionaTypeMapperNameByValue[v.Index] = v.Name
	}

}
