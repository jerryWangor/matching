package rpc

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"encoding/json"
	"github.com/sirupsen/logrus"
	"io/ioutil"
	"net/http"
)

const (
	CurrencyType        = "BNB" // 原始货币类型
	QBTargetAddress     = "0xE7AfE8771D09e849b6DF048920C8fa3f542dA86B"
	BSCApiKey           = "FE5SXMB3PE4PXG5AE7UCDFPTUBXSKGX143"
	BSCHashCheckUrl     = "https://api.bscscan.com/api?module=transaction&action=gettxreceiptstatus&apikey=" + BSCApiKey + "&txhash="
	PLGHashCheckUrl     = "https://api-testnet.polygonscan.com/api?module=transaction&action=gettxreceiptstatus&apikey=YourApiKeyToken&txhash="
	BSCAccountTxListUrl = "https://api.bscscan.com/api?module=account&action=txlist&startblock=0&endblock=1000000000&page=1&offset=30&sort=desc&apikey=" + BSCApiKey + "&address="

	PayFailed     = 0
	PaySuccess    = 1
	SuppleFailed  = 0
	SuppleSuccess = 1
	GWeiInternal  = 100000000000000
)

// 验证hash
type BSCHashResult struct {
	Status  string              `json:"status"`
	Message string              `json:"message"`
	Result  BSCHashResultStatus `json:"result"`
}

type BSCHashResultStatus struct {
	Status string `json:"status"`
}

// 查询账号订单
type BSCTxList struct {
	Status  string             `json:"status"`
	Message string             `json:"message"`
	Result  []*BSCTxListResult `json:"result"`
}

type BSCTxListResult struct {
	BlockNumber       string `json:"blockNumber"`
	TimeStamp         string `json:"timeStamp"`
	Hash              string `json:"hash"`
	Nonce             string `json:"nonce"`
	BlockHash         string `json:"blockHash"`
	TransactionIndex  string `json:"transactionIndex"`
	From              string `json:"from"`
	To                string `json:"to"`
	Value             string `json:"value"`
	Gas               string `json:"gas"`
	GasPrice          string `json:"gasPrice"`
	IsError           string `json:"message"`
	TxreceiptStatus   string `json:"txreceipt_status"`
	Input             string `json:"input"`
	ContractAddress   string `json:"contractAddress"`
	CumulativeGasUsed string `json:"cumulativeGasUsed"`
	GasUsed           string `json:"gasUsed"`
	Confirmations     string `json:"confirmations"`
}

var Codec ktcp.Codec

func init() {
	Codec = &ktcp.ProtobufCodec{}
}

func getPacket(msgId uint32, val interface{}) (*kproto.Packet, error) {
	b, err := Codec.Encode(val)
	if err != nil {
		return nil, err
	}

	return &kproto.Packet{MsgId: msgId, Data: b}, nil
}

func getBSCHashCheckResult(hash string) (*BSCHashResult, error) {
	resp, err := http.Get(BSCHashCheckUrl + hash)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// 读取数据
	bds, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	var jsonResp BSCHashResult
	json.Unmarshal(bds, &jsonResp)

	return &jsonResp, nil
}

// 获取用户链上的交易记录
func getBSCAccountTxList(token string) (*BSCTxList, error) {
	resp, err := http.Get(BSCAccountTxListUrl + token)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// 读取数据
	bds, err := ioutil.ReadAll(resp.Body)
	logrus.Info(token, "接口返回值", string(bds))
	if err != nil {
		return nil, err
	}
	var jsonResp BSCTxList
	json.Unmarshal(bds, &jsonResp)

	return &jsonResp, nil
}
