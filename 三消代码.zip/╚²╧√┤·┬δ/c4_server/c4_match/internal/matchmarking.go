package internal

import (
	"c4_center/utils"
	"c4_match/internal/rules"
	"c4_match/internal/store"
	"time"

	"github.com/sirupsen/logrus"
)

type MatchMakingPool map[int32]*Matchmaking

func (mi MatchMakingPool) Put(id int32, matchMaking *Matchmaking) {
	mi[id] = matchMaking
}

func (mi MatchMakingPool) Get(id int32) *Matchmaking {
	return mi[id]
}

func (mi MatchMakingPool) Start() {
	for _, v := range mi {
		v.Start()
	}
}

var MatchMakingPoolInstant MatchMakingPool

func init() {
	MatchMakingPoolInstant = make(map[int32]*Matchmaking)
}

type Matchmaking struct {
	ID            int32
	Store         store.Store
	Service       MatchService
	Timeout       time.Duration
	Rule          rules.MatchRule
	MatchBot      MatchBot
	SearchTimeOut int
}

type Options struct {
	ID       int32
	Store    store.Store
	Service  MatchService
	Rule     rules.MatchRule
	MatchBot MatchBot
}

func New(opts *Options) {
	MatchMakingPoolInstant.Put(opts.ID, &Matchmaking{
		ID:       opts.ID,
		Store:    opts.Store,
		Rule:     opts.Rule,
		Service:  opts.Service,
		MatchBot: opts.MatchBot,
	})
}

func (m *Matchmaking) Start() {
	logrus.Infof("matchmarking_start : store : %s; rule : %s;", m.Store.GetName(), m.Rule.GetName())
	//channel
	go m.Service.Process()

	//match
	go func() {
		for {
			func() {
				defer utils.HandleCrash()
				m.RunLoop()
			}()
			time.Sleep(time.Millisecond * 500)
		}
	}()
}

func (m *Matchmaking) AddUser(user *store.User) {
	m.Store.Add(user)
}

func (m *Matchmaking) RemoveUser(userid string) {
	m.Store.Remove(userid)
}

func (m *Matchmaking) RunLoop() {
	r := func(k, v any) bool {
		//time out
		if m.isUserExtendTime(v.(*store.User)) {
			m.RemoveUser(v.(*store.User).ID)

			//publish
			m.Service.MatchTimeOut(NewMatchTimeOutResponse(m.Rule.GetName(), v.(*store.User)))
			logrus.Infof("user_timeout : user_id %s", v.(*store.User).ID)
			return true
		}

		//area time out
		if m.isUserAreaTimeOut(v.(*store.User)) {
			logrus.Infof("user_area_timeout : user_id %s , score : %v ,area : %v", v.(*store.User).ID, v.(*store.User).Score, v.(*store.User).MatchArea)
			v.(*store.User).AddMatchArea(m.Rule.GetConfig().MatchArea)
		}

		//bot
		if m.MatchBot.Match(v.(*store.User)) {
			logrus.Infof("user_match_bot : user_id %s", v.(*store.User).ID)
			m.SendMatch(v.(*store.User), store.InitBot("BOT"))
			return true
		}

		m.Store.Range(func(kk, vv any) bool {
			if m.CanMatch(v.(*store.User), vv.(*store.User)) {
				m.SendMatch(v.(*store.User), vv.(*store.User))
				return false
			}
			return true
		})

		return true
	}

	m.Store.Range(r)

}

func (m *Matchmaking) CanMatch(user1, user2 *store.User) bool {
	if user1.ID == user2.ID {
		return false
	}
	return m.Rule.Match(user1, user2)
}

func (m *Matchmaking) SendMatch(user1, user2 *store.User) {
	if !user1.Bot {
		m.RemoveUser(user1.ID)
	}

	if !user2.Bot {
		m.RemoveUser(user2.ID)
	}

	//publish
	m.Service.MatchFinish(NewMatchFinishResponse(m.Rule.GetName(), user1, user2, m.ID))
}

//总匹配时间检测
func (m *Matchmaking) isUserExtendTime(user *store.User) bool {
	now := time.Now()
	extendTime := user.JoinTime.Add(time.Second * time.Duration(m.Rule.GetConfig().MatchTIME))
	return now.Unix() > extendTime.Unix()
}

//单次范围匹配时间检测
func (m *Matchmaking) isUserAreaTimeOut(user *store.User) bool {
	//己达最大范围匹配次数
	if user.MatchArea >= m.Rule.GetConfig().MatchArea {
		return false
	}

	now := time.Now()
	extendTime := user.JoinTime.Add(time.Second * time.Duration(m.Rule.GetConfig().AreaTime*user.MatchArea))
	return now.Unix() > extendTime.Unix()
}
