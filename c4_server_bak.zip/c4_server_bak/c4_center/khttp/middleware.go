package khttp

import (
	"runtime/debug"

	"github.com/sirupsen/logrus"
)

func RecoverMiddleware() MiddlewareFunc {
	return func(next HandlerFunc) HandlerFunc {
		return func(ctx Context) {
			defer func() {
				if rr := recover(); rr != nil {
					logrus.WithField("path", ctx.Request().URL.Path).Errorf("PANIC | %+v | %s", rr, debug.Stack())
				}
			}()
			// fmt.Fprintln(ctx.ResponseWriter(), "middle recover before")
			next(ctx)
			// fmt.Fprintln(ctx.ResponseWriter(), "middle recover after")
		}
	}
}
