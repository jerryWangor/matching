package room

import (
	"c4_center/kmongo"
	"c4_room/fsm"
	"c4_room/internal/match3"
	"context"
	"fmt"
	"testing"

	"github.com/google/uuid"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var initState fsm.State = 1

func TestFsm(t *testing.T) {
	init := fsm.NewEventEntity("init", func(opt *fsm.Param) (fsm.State, error) {
		fmt.Println("init state")
		return 2, nil
	})

	paid := fsm.NewEventEntity("paid", func(opt *fsm.Param) (fsm.State, error) {
		fmt.Println("paid state")
		return 3, nil
	})

	cancel := fsm.NewEventEntity("cancel", func(opt *fsm.Param) (fsm.State, error) {
		fmt.Println("canceled state")
		return 4, nil
	})

	fsm1 := fsm.NewFSM("Room", initState)
	fsm1.RegisterStateMachine(initState, init, paid, cancel)

	fsm1.Call("init", fsm.WithData(1))
	fsm1.Call("paid", fsm.WithData(1))
}

func TestTableFsm(t *testing.T) {
	table := NewTable(uuid.NewString(), 1, 1000)
	tf := NewTableFsm(table)
	// go func() {
	// 	time.Sleep(time.Second * 10)
	// 	tf.GameOver()
	// }()

	// go func() {
	// 	tf.ReciveAction("a", "11111111111")
	// 	time.Sleep(time.Second * 3)
	// 	tf.ReciveAction("b", "2222222222222")
	// }()

	tf.Loop()
}

func TestActionCount(t *testing.T) {
	ll := []*match3.Piece{match3.NewPiece(0, 1, 1), match3.NewPiece(1, 1, 1), match3.NewPiece(2, 1, 1), match3.NewPiece(3, 1, 1), match3.NewPiece(0, 2, 1), match3.NewPiece(0, 3, 1)}

	row, col := make(map[int32]int32), make(map[int32]int32)

	for _, v := range ll {
		row[v.PosX] = row[v.PosX] + 1
		col[v.PosY] = col[v.PosY] + 1
	}

	for _, v := range row {
		if v >= 4 {
			return
		}
	}

	for _, v := range col {
		if v >= 4 {
			return
		}
	}
}

func TestSession(t *testing.T) {
	m := make(map[int32]*ABC)
	m[1] = &ABC{aaa: 1, bbb: 2}

	l := []*ABC{m[1]}

	fmt.Println(l)

	m[1] = nil
	delete(m, 1)

	fmt.Println(l)

	var aaa []int32
	fmt.Println(aaa == nil)
	var bbb map[int32]int32
	fmt.Println(bbb == nil)
}

func TestMongo(t *testing.T) {
	kmongo.Init("test", options.Client().ApplyURI("mongodb://192.168.1.45:27017/test?maxPoolSize=100&authSource=admin"))

	for i := 0; i < 100; i++ {
		fmt.Println(kmongo.Count(context.TODO(), kmongo.HeroCollection, bson.M{"user_id": "fff", "state": 1}))
	}
}

type ABC struct {
	aaa int32
	bbb int32
}
