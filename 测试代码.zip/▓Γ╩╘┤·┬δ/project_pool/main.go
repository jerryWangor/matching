package main

import (
	"bufio"
	"fmt"
	"os"
	"sync"
)

// 一个[]byte的对象池，每个对象为一个[]byte
var bytePool = sync.Pool{
	New: func() interface{} {
		b := make([]byte, 300000)
		return &b
	},
}

//func main() {
//	a := time.Now().Unix()
//	// 不使用对象池
//	for i := 0; i < 1000000; i++ {
//		obj := make([]byte, 300000)
//		_ = obj
//	}
//	b := time.Now().Unix()
//	// 使用对象池
//	for i := 0; i < 1000000; i++ {
//		obj := bytePool.Get().(*[]byte)
//		bytePool.Put(obj)
//	}
//	c := time.Now().Unix()
//	fmt.Println("without pool ", b-a, "s")
//	fmt.Println("with    pool ", c-b, "s")
//}

//var rwMutex sync.RWMutex //定义一个读写互斥锁
//
////注意传递的组等待是指针形式
//func WriteData(wg *sync.WaitGroup, id int) {
//	rwMutex.Lock() //加 写锁
//	fmt.Println("增加第", id, "个写锁")
//	for i := 0; i < 5; i++ {
//		fmt.Println("进行写操作")
//		time.Sleep(time.Second)
//	}
//	fmt.Println("释放第", id, "个写锁")
//	rwMutex.Unlock() //释放 写锁
//	wg.Done()
//}
//
//func ReadData(wg *sync.WaitGroup, id int) {
//	rwMutex.RLock() //加 读锁
//	fmt.Println("增加第", id, "个读锁")
//	for i := 0; i < 5; i++ {
//		fmt.Println("进行读操作")
//		time.Sleep(time.Second)
//	}
//	fmt.Println("释放第", id, "个读锁")
//	rwMutex.RUnlock() //释放 读锁
//	wg.Done()
//}
//
//func main() {
//	var wg sync.WaitGroup
//	for i := 1; i < 3; i++ {
//		wg.Add(1)
//		go WriteData(&wg, i)
//	}
//	for i := 1; i < 4; i++ {
//		wg.Add(1)
//		go ReadData(&wg, i)
//	}
//
//	wg.Wait()
//	fmt.Println("主程序执行完毕")
//}

func demo() {
	fmt.Println("运行demo函数")
}

func main() {
	//var wg sync.WaitGroup
	//var once sync.Once
	//for i := 0; i < 10; i++ {
	//	wg.Add(1)
	//	go func() {
	//		once.Do(demo)
	//		//注意不要写成once.Do(demo()),这样写是把demo()的运行结果传入Do
	//		wg.Done()
	//	}()
	//}
	//wg.Wait()
	//fmt.Println("主程序结束")

	fmt.Println("请输入一个字符串：")
	reader := bufio.NewReader(os.Stdin)
	s1, _ := reader.ReadString('\n')
	fmt.Println("读到的数据：", s1)
}
