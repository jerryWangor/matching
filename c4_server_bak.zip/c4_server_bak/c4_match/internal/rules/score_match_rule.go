package rules

import (
	"c4_center/game_config"
	"c4_match/internal/store"
	"fmt"
)

type ScoreMatchRule struct {
	*game_config.MatchRuleData
}

func NewScoreMatchRule(id int32) ScoreMatchRule {
	return ScoreMatchRule{
		MatchRuleData: game_config.MatchRuleConfigInstant.GetInfo(id),
	}
}

func (r ScoreMatchRule) Match(user1, user2 *store.User) bool {
	minScore, maxScore := float64(0), float64(0)

	//双方同为保护积分
	if user1.Score <= float64(r.MatchProtect) && user2.Score <= float64(r.MatchProtect) {
		return true
	}

	//任何一方为非保护积分则不能匹配
	if user1.Score <= float64(r.MatchProtect) || user2.Score <= float64(r.MatchProtect) {
		return false
	}

	//普通积分
	minScore = user1.Score - float64(user1.MatchArea)*float64(r.MathPointDown)
	maxScore = user1.Score + float64(user1.MatchArea)*float64(r.MathPointUp)

	//匹配判断
	if user2.Score >= minScore && user2.Score <= maxScore {
		return true
	}

	return false
}

func (r ScoreMatchRule) GetName() string {
	return fmt.Sprintf("Score ID -> %v", r.ID)
}

func (r ScoreMatchRule) GetConfig() *game_config.MatchRuleData {
	return r.MatchRuleData
}
