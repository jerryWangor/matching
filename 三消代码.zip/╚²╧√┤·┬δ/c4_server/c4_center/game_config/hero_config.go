package game_config

type HeroData struct {
	HeroId          int32  `tb_name:"英雄Id"`
	HeaddressId     string `tb_name:"头饰显性基因ID"`
	NameId          int32  `tb_name:"名字ID"`
	Vocation        int32  `tb_name:"职业"`
	HpParam         int32  `tb_name:"生命系数(/10000)"`
	ShieldParam     int32  `tb_name:"护盾系数(/10000)"`
	AttParam        int32  `tb_name:"攻击系数(/10000)"`
	Crt             int32  `tb_name:"暴击率"`
	Cdmg            int32  `tb_name:"暴击伤害"`
	ChessColor      int32  `tb_name:"棋子颜色"`
	MaxEnerge       int32  `tb_name:"能量点上限"`
	NSkill          int32  `tb_name:"普攻Id"`
	USkill          int32  `tb_name:"必杀技Id"`
	PSkill_1        int32  `tb_name:"被动技能1"`
	PSkill_2        int32  `tb_name:"被动技能2"`
	PSkill_3        int32  `tb_name:"被动技能3"`
	ChristmasDropID int32  `tb_name:"圣诞礼物掉落ID"`
	InitialLevel_A  int32  `tb_name:"A初始等级"`
	InitialLevel    int32  `tb_name:"K初始等级"`
	Quality_A       int32  `tb_name:"A品质"`
	Quality         int32  `tb_name:"K品质"`
	MaxEnerge_A     int32  `tb_name:"A能量点上限"`
}

var HeroConfigInstant *HeroConfig

type HeroConfig struct {
	HeroData []*HeroData
	Infos    map[string]*HeroData //key == HeaddresId
}

func InitHeroConfig(path string) {
	HeroConfigInstant = &HeroConfig{Infos: make(map[string]*HeroData)}
	//加载
	LoadJsonFile(path+"/HeroData.json", HeroConfigInstant)
	//初始化
	HeroConfigInstant.InitIndex()
}

func (h *HeroConfig) InitIndex() {
	for i, v := range h.HeroData {
		h.Infos[v.HeaddressId] = h.HeroData[i]
	}
}

func (h *HeroConfig) GetInfo(key string) *HeroData {
	return h.Infos[key]
}
