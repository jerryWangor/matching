package game_config

import "sort"

type HeroLevelUpData struct {
	ChessColor     int32    `tb_name:"英雄颜色"`
	Level          int32    `tb_name:"等级"`
	UpgradeConsume []string `tb_name:"升级消耗"`
}

var HeroLevelUpConfigInstant *HeroLevelUpConfig

type HeroLevelUpConfig struct {
	HeroLevelUpData []*HeroLevelUpData
	Infos           map[int32]map[int32]*HeroLevelUpData //key == ChessColor_Level
}

func InitHeroLevelUpConfig(path string) {
	HeroLevelUpConfigInstant = &HeroLevelUpConfig{Infos: make(map[int32]map[int32]*HeroLevelUpData)}
	//加载
	LoadJsonFile(path+"/HeroLevelUpData.json", HeroLevelUpConfigInstant)
	//初始化
	HeroLevelUpConfigInstant.InitIndex()
}

func (h *HeroLevelUpConfig) InitIndex() {
	for i, v := range h.HeroLevelUpData {
		if h.Infos[v.ChessColor] == nil {
			h.Infos[v.ChessColor] = make(map[int32]*HeroLevelUpData)
		}
		h.Infos[v.ChessColor][v.Level] = h.HeroLevelUpData[i]
	}
}

func (h *HeroLevelUpConfig) GetInfo(c int32, l int32) *HeroLevelUpData {
	data, ok := h.Infos[c][l]
	if !ok {
		return nil
	}
	return data
}

func (h *HeroLevelUpConfig) GetHeroMaxLevel(c int32) int32 {
	data, ok := h.Infos[c]
	if !ok {
		return 0
	}
	levels := make([]int, 0, 0)
	for k, _ := range data {
		levels = append(levels, int(k))
	}
	if len(levels) <= 0 {
		return 0
	}
	sort.Ints(levels)
	return int32(levels[len(levels)-1])
}
