package game_config

import "math/rand"

type RobotTeamData struct {
	ID         int32  `tb_name:"阵容ID"`
	Hero       int32  `tb_name:"英雄数量"`
	Position_1 string `tb_name:"1号位"`
	Position_2 string `tb_name:"2号位"`
	Position_3 string `tb_name:"3号位"`
	Position_4 string `tb_name:"4号位"`
	Position_5 string `tb_name:"5号位"`
	Position_6 string `tb_name:"6号位"`
}

var RobotTeamConfigInstant *RobotTeamConfig

type RobotTeamConfig struct {
	RobotTeamData []*RobotTeamData
	Infos         map[int32][]*RobotTeamData
}

func InitRobotTeamConfig(path string) {
	RobotTeamConfigInstant = &RobotTeamConfig{Infos: make(map[int32][]*RobotTeamData)}
	//加载
	LoadJsonFile(path+"/RobotTeamData.json", RobotTeamConfigInstant)
	//初始化
	RobotTeamConfigInstant.InitIndex()
}

func (s *RobotTeamConfig) InitIndex() {
	for i, v := range s.RobotTeamData {
		s.Infos[v.Hero] = append(s.Infos[v.Hero], s.RobotTeamData[i])
	}
}

func (s *RobotTeamConfig) GetByCount(count int32) *RobotTeamData {
	if _, ok := s.Infos[count]; !ok {
		return nil
	}

	return s.Infos[count][rand.Intn(len(s.Infos[count]))]
}
