package internal

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kproto"
	"c4_center/utils"
	"c4_lobby/internal/item"
	"c4_lobby/internal/sign"
	"fmt"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"time"
)

//sign in
func SignIn(req *kproto.SendReq) (*kproto.SendResp, error) {
	// 判断签到活动是否过期了
	conf := game_config.ActivityConfigInstant.GetInfo(game_config.ActivityId_Sign)
	endTime := utils.DateTimeToTimestamp(cmongo.DATETIME_FORMAT, conf.EndTime)
	startTime := utils.DateTimeToTimestamp(cmongo.DATETIME_FORMAT, conf.StartTime)
	nowTime := time.Now().Unix()
	if startTime > nowTime {
		return nil, fmt.Errorf("sign activity not open  : -> userid : %v", req.UserId)
	}
	if endTime < nowTime {
		return nil, fmt.Errorf("sign activity is expire : -> userid : %v", req.UserId)
	}

	// 查询玩家签到数据
	totalNum := int64(len(game_config.SignRewardConfigInstant.Infos)) // 总天数
	days, err := utils.GetDaysBetween2Date(cmongo.DATETIME_FORMAT, conf.StartTime, time.Now().Format(cmongo.DATETIME_FORMAT))
	if err != nil {
		return nil, fmt.Errorf("time error : -> userid : %v", req.UserId)
	}
	//fmt.Println("days", days+1)
	// 签到天数比奖励天数还多就返回
	if days >= totalNum {
		return nil, fmt.Errorf("sign activity is expire : -> userid : %v", req.UserId)
	}
	signData := sign.LoadMonthSignByUserId(req.UserId, cmongo.TYPE_SIGN_ACTIVITY, startTime)
	if signData != nil {
		// 判断是否签到过了
		var nData int64 = 1 << days
		if utils.HasFlag(signData.Data, nData) {
			return nil, fmt.Errorf("user has sign : -> userid : %v", req.UserId)
		}
		// 更新签到数据
		signData.Data = utils.SetFlag(signData.Data, nData)
		if err := sign.UpdateSign(signData); err != nil {
			return nil, fmt.Errorf("sign data update error : -> userid : %v", req.UserId)
		}
	} else {
		var data int64 = 1 << days
		inData := &cmongo.Sign{
			ID:       primitive.NewObjectID().Hex(),
			UserID:   req.UserId,
			Type:     cmongo.TYPE_SIGN_ACTIVITY,
			DateTime: startTime,
			Data:     data,
		}
		// 先插入签到数据
		if err := sign.InsertSign(inData); err != nil {
			return nil, fmt.Errorf("sign data insert error : -> userid : %v", req.UserId)
		}
	}

	getItemsResp := make([]*kproto.ItemInfo, 0) //获得的道具返回信息

	// 活动开启的当天为签到的第1天
	// 根据当前时间-活动开启时间来判断是领取第几天的奖励
	if info := game_config.SignRewardConfigInstant.GetInfo(int32(days + 1)); info != nil {
		for _, v := range info.SignReward {
			if tid, num, err := utils.ParseItem(v); err == nil {
				itemInfo := item.GetInitItem(req.UserId, tid, num)
				getItemsResp = append(getItemsResp, &kproto.ItemInfo{Id: itemInfo.ID, TypeId: itemInfo.TypeId, Num: num})
				if _, err := item.InsertUpdateItem(itemInfo); err != nil {
					return nil, err
				}
			}
		}
	}

	//encode
	info := &kproto.LOBBY_SIGN_IN_RESP{}
	info.Items = getItemsResp
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_SIGN_IN_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}
