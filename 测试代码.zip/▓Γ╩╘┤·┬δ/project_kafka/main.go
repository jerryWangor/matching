package main

import (
	"context"
	"fmt"
	"github.com/confluentinc/confluent-kafka-go/kafka"
	"os"
	"os/signal"
	"syscall"
	"time"
)

const Topic = "testTopic"
const Broker = "192.168.2.6:9192"
const NumPartition = 2
const ReplicationFactor = 1
const ConsumerGroup1 = "consumerTest1"
const ConsumerGroup2 = "consumerTest2"

func main() {

	fmt.Println("Kafka Demo RUN:")
	//创建topic
	KafkaCreateTopic()
	//创建生产者
	go KafkaProducer()
	//创建消费者
	go KafkaConsumer(ConsumerGroup1)
	go KafkaConsumer(ConsumerGroup1)
	go KafkaConsumer(ConsumerGroup2)

	sigchan := make(chan os.Signal, 1)
	signal.Notify(sigchan, syscall.SIGINT, syscall.SIGTERM)
	run := true
	for run {
		select {
		case sig := <-sigchan:
			fmt.Printf("Caught signal %v: terminating\n", sig)
			run = false
		}
	}
}

/*
   创建topic
*/
func KafkaCreateTopic() {

	// 创建一个新的AdminClient。
	a, err := kafka.NewAdminClient(&kafka.ConfigMap{"bootstrap.servers": Broker})
	if err != nil {
		fmt.Printf("Failed to create Admin client: %s\n", err)
		os.Exit(1)
	}

	// Contexts 用于中止或限制时间量
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	//在集群上创建主题。
	results, err := a.CreateTopics(
		ctx,
		//通过提供的TopicSpecification结构，可以同时创建多个主题
		[]kafka.TopicSpecification{{
			Topic:             Topic,
			NumPartitions:     NumPartition,
			ReplicationFactor: ReplicationFactor}},
		// Admin options
		kafka.SetAdminOperationTimeout(60*time.Second))
	if err != nil {
		fmt.Printf("Failed to create topic: %v\n", err)
		os.Exit(1)
	}

	// Print results
	for _, result := range results {
		fmt.Printf("%s\n", result)
	}

	a.Close()
}
