package lobby_register

import (
	"c4_center/container/credis"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/registry"
	"c4_center/registry/discovery"
	"c4_center/registry/etcd"
	"context"
	"encoding/json"
	"fmt"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
	"math/rand"
	"time"

	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
)

var EtcdClient *LobbyRegistry

type LobbyRegistry struct {
	ctx       context.Context
	client    *etcd.Registry
	discovery *discovery.Discovery
}

func InitLobbyRegistry(config clientv3.Config, opts ...etcd.Option) {
	cli, err := clientv3.New(config)
	if err != nil {
		logrus.Fatal(err)
	}

	EtcdClient = &LobbyRegistry{ctx: context.TODO(), client: etcd.New(cli, opts...), discovery: discovery.NewDiscovery()}
}

func (g *LobbyRegistry) Register(service *registry.ServiceInstance) error {
	return g.client.Register(g.ctx, service)
}

func (g *LobbyRegistry) Deregister(service *registry.ServiceInstance) error {
	return g.client.Deregister(g.ctx, service)
}

func (g *LobbyRegistry) GetService(name string) (*registry.ServiceInstance, error) {
	infos, err := g.client.GetService(g.ctx, name)
	if err != nil {
		return nil, err
	}

	if len(infos) <= 0 {
		return nil, fmt.Errorf("service of %s :  is empty", name)
	}

	return infos[rand.Intn(len(infos))], nil
}

func (g *LobbyRegistry) GetServiceInDiscovery(name string) (*registry.ServiceInstance, error) {
	node := g.discovery.PickNode(name)
	if node == nil {
		logrus.Errorf("cannot get service ->  %v", name)
		return g.GetService(name)
	}
	return node, nil
}

func (g *LobbyRegistry) Watch(name string) {
	w, err := g.client.Watch(g.ctx, name)
	if err != nil {
		logrus.Fatal(err)
		return
	}

	//init
	res, err := w.Next()
	if err != nil {
		logrus.Fatal(err)
		return
	}

	g.discovery.RefreshNode(name, res...)

	//loop watch
	go func() {
		for {
			res, err := w.Next()
			if err != nil {
				logrus.Error(err)
				return
			}

			g.discovery.RefreshNode(name, res...)
		}
	}()
}

// 异步发送给网关服务器
func RpcSendToGate(userid string, val *kproto.Packet) {
	sessStr, err := kredis.GetStr(context.Background(), userid)
	if err != nil {
		logrus.Infof("do not have session of userid : %s;", userid)
		return
	}

	var sessData credis.SessionInfo
	if json.Unmarshal([]byte(sessStr), &sessData) != nil {
		logrus.Infof("session unmarshal err of userid : %s;", userid)
		return
	}

	//connection grpc service
	conn, err := grpc.DialContext(context.Background(), sessData.GateGrpcAddress, grpc.WithBlock(), grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		logrus.Infof("grpc error that invoke gate: %v;", err)
		return
	}

	defer conn.Close()

	client := kproto.NewGateServiceClient(conn)
	//client timeout
	ctx, cancel := context.WithTimeout(context.Background(), time.Second*10)
	defer cancel()

	//request
	resp, err := client.SendToClient(ctx, &kproto.SendReq{UserId: userid, Packet: val})
	if err != nil {
		logrus.Infof("send to gate error: %v;", err)
		return
	}

	logrus.Info(resp)
}
