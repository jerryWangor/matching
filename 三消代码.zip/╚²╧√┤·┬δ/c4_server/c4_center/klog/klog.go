package klog

import (
	"io"
	"os"
	"strings"
	"time"

	rotatelogs "github.com/lestrrat/go-file-rotatelogs"
	"github.com/sirupsen/logrus"
)

type LogType int32

const (
	LogTypeInsert LogType = iota + 1 // 插入
	LogTypeUpdate                    // 更新
)

type LogData struct {
	Type      LogType                // 类型：插入 更新
	ModelName string                 // 模型名字，LogLogin
	Data      map[string]interface{} // 结构体map数据
}

func InitLog(logPath string, lvl logrus.Level) {
	logrus.SetFormatter(&logrus.TextFormatter{})
	logrus.SetReportCaller(true)
	logrus.SetOutput(os.Stdout)

	file, err := rotatelogs.New(
		logPath+".%Y%m%d",
		rotatelogs.WithLinkName(strings.Split(logPath, "/")[len(strings.Split(logPath, "/"))-1]), // 生成软链，指向最新日志文件
		rotatelogs.WithRotationCount(int(30)),                                                    // 文件最大保存份数
		rotatelogs.WithRotationTime(time.Hour*24),                                                // 日志切割时间间隔
	)

	writers := []io.Writer{file, os.Stdout}

	fileAndStdoutWriter := io.MultiWriter(writers...)
	if err == nil {
		logrus.SetOutput(fileAndStdoutWriter)
	} else {
		logrus.Fatal(err)
	}

	logrus.SetLevel(lvl)
}
