package config

import "c4_center/game_config"

func InitGameConfig() {
	//init
	game_config.InitItemConfig(GameConfigInstant.Path)
	game_config.InitShopTypeConfig(GameConfigInstant.Path)
	game_config.InitShopItemConfig(GameConfigInstant.Path)
}
