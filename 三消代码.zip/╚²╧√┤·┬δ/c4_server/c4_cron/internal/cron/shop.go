package cron

import (
	"c4_center/game_config"
	"c4_center/utils"
	"github.com/robfig/cron/v3"
	"github.com/sirupsen/logrus"
)

type Shop struct {
	Id      int32
	EntryID cron.EntryID
	Cron    *cron.Cron
	Config  *game_config.ShopType
	Items   map[int32]*game_config.ShopItem
}

func (s *Shop) Init() {
	logrus.Infof("商店初始化！-> %v", s.Id)
	s.Config = game_config.ShopTypeConfigInstant.GetInfo(s.Id)
	s.Items = make(map[int32]*game_config.ShopItem)
	// 把商品载入到Items中，用于后面的上架/下架，改价
	if infos, ok := game_config.ShopItemConfigInstant.Infos[s.Id]; ok {
		for k, v := range infos {
			s.Items[v.ID] = infos[k]
		}
	}
}

func (s *Shop) Run() {
	logrus.Infof("商店检查中！-> %v", s.Id)
	// 其他情况直接reset，包括中途重启
	s.Reset()
}

func (s *Shop) Begin() {
	logrus.Infof("商店开启！-> %v", s.Id)
	SendShopState(s.Id, ShopOpen, utils.GetNextRefreshTime(s.Config.Refresh_Time))
}

func (s *Shop) End() {
	logrus.Infof("商店关闭！-> %v", s.Id)
	delete(AllCronData.ShopEntryIds, s.Id)
	s.Cron.Remove(s.EntryID)
	SendShopState(s.Id, ShopClose, 0)
}

// 商店刷新
func (s *Shop) Reset() {
	logrus.Infof("商店刷新!-> %v", s.Id)
	// 循环商品列表，计算需要随机权重的道具

	// 给网关发送消息
	SendShopState(s.Id, ShopReset, utils.GetNextRefreshTime(s.Config.Refresh_Time))
}

// 商店中的物品发生改变
func (s *Shop) Change() {
	SendShopState(s.Id, ShopChange, utils.GetNextRefreshTime(s.Config.Refresh_Time))
}
