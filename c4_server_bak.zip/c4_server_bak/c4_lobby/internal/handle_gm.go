package internal

import (
	"c4_center/cinternal"
	"c4_center/container/cmongo"
	"c4_center/kmongo"
	"c4_center/kproto"
	"context"
	"fmt"
	"os/exec"
	"strconv"
	"strings"

	"go.mongodb.org/mongo-driver/bson"
)

const (
	ADD_HERO  = "@addhero"
	DEL_HERO  = "@delhero"
	SET_SCORE = "@setscore"
	ADD_ITEM  = "@additem"
	SET_TIME  = "@settime"
)

func AddHero(userid, order string, ret *kproto.LOBBY_GM_RESP) {
	sp := strings.Fields(strings.TrimSpace(order))
	if len(sp) != 5 {
		ret.Code = -2
		return
	}

	level, err := strconv.ParseInt(strings.Trim(sp[3], " "), 10, 32)
	if err != nil {
		ret.Code = -3
		return
	}

	grade, err := strconv.ParseInt(strings.Trim(sp[4], " "), 10, 32)
	if err != nil {
		ret.Code = -4
		return
	}

	h := cinternal.GetInitHero(userid, sp[1], sp[2], 0, int32(grade), int32(level))
	if h == nil {
		ret.Code = -5
		return
	}

	cinternal.InsertHero(h)
}

func DelHero(userid string, ret *kproto.LOBBY_GM_RESP) {
	kmongo.DeleteMany(context.TODO(), kmongo.HeroCollection, bson.M{"user_id": userid})
}

//设置积分
func SetRankScore(userid, order string, ret *kproto.LOBBY_GM_RESP) {
	sp := strings.Fields(strings.TrimSpace(order))
	if len(sp) != 2 {
		ret.Code = -2
		return
	}

	score, err := strconv.ParseInt(strings.Trim(sp[1], " "), 10, 32)
	if err != nil {
		ret.Code = -3
		return
	}

	var rankInfo cmongo.PlayerRankInfo
	kmongo.GetOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rankInfo, bson.M{"user_id": userid})
	if len(rankInfo.ID) <= 0 {
		rankInfo.InitPlayerRankInfo(userid)
		rankInfo.SetRank1Score(int32(score))
		//写入
		if !kmongo.InsertOne(context.TODO(), kmongo.PlayerRankInfoCollection, &rankInfo) {
			ret.Code = -4
			return
		}
	} else {
		rankInfo.SetRank1Score(int32(score))
		if !kmongo.UpdateOne(context.TODO(), kmongo.PlayerRankInfoCollection, bson.M{"_id": rankInfo.ID}, bson.M{"$set": bson.M{"rank_1": rankInfo.GetRank1Info()}}) {
			ret.Code = -5
			return
		}
	}
}

//设置时间
func SetTime(order string, ret *kproto.LOBBY_GM_RESP) {
	sp := strings.Fields(strings.TrimSpace(order))
	if len(sp) != 2 {
		ret.Code = -2
		return
	}

	args := []string{"-s", strings.Trim(sp[1], " ")}
	exec.Command("date", args...).Run()
}

//增加道具
func AddItem(userid, order string, ret *kproto.LOBBY_GM_RESP) {
	sp := strings.Fields(strings.TrimSpace(order))
	if len(sp) != 2 {
		ret.Code = -2
		return
	}

	item := InitItemByString(userid, sp[1])

	if item.ItemConfig.StackingLimit == 0 {
		AddItemUnlimit(item)
	} else {
		AddItemLimit(item)
	}
}

//gm指令
func GmOrder(req *kproto.SendReq) (*kproto.SendResp, error) {
	var reqData kproto.LOBBY_GM_REQ
	if err := Codec.Decode(req.Packet.Data, &reqData); err != nil {
		return nil, err
	}

	sp := strings.Fields(strings.TrimSpace(reqData.Order))
	if len(sp) <= 0 {
		return nil, fmt.Errorf("gm order error -> %v", -999)
	}

	info := &kproto.LOBBY_GM_RESP{}

	switch sp[0] {
	case ADD_HERO:
		AddHero(req.UserId, reqData.Order, info)
	case DEL_HERO:
		DelHero(req.UserId, info)
	case SET_SCORE:
		SetRankScore(req.UserId, reqData.Order, info)
	case ADD_ITEM:
		AddItem(req.UserId, reqData.Order, info)
	case SET_TIME:
		SetTime(reqData.Order, info)
	default:
		info.Code = -9
	}

	//encode
	packet, err := getPacket(uint32(kproto.MSG_LOBBY_GM_RESP_ID), info)
	if err != nil {
		return nil, err
	}

	return &kproto.SendResp{Packet: packet}, nil
}
