package main

import (
	"fmt"
	"math"
	"math/rand"
	"os"
	"strconv"
	"strings"
	"time"
)

func main() {
	//stime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2021-09-22 16:00:00", time.Local)
	//etime, _ := time.ParseInLocation("2006-01-02 15:04:05", "2021-10-30 23:59:59", time.Local)

	//stime := time.Now()
	//etime := stime
	//etime = etime.AddDate(0, 3, 0)
	//fmt.Println(GetMonInfo(stime, etime))

	// 非阻塞的定时器
	//SetTimeOut(3*time.Second, func() {
	//	fmt.Println("定时器执行完成")
	//})
	//
	//fmt.Println("主进程不阻塞")
	//
	//time.Sleep(100 * time.Second)

	//生成唯一随机数字
	//currWoker := &idworker.IdWorker{}
	//currWoker.InitIdWorker(1000, 1)
	//newID, err := currWoker.NextId()
	//if err == nil {
	//	fmt.Println(newID)
	//}

	// 随机种子
	//rand.Seed(time.Now().Unix())

	// 生成 20 个 [0, 100) 范围的伪随机数。
	//for i := 0; i < 20; i++ {
	//	result := rand.Intn(50)
	//	fmt.Println(result)
	//}

	// 生成 20 个 [0, 100) 范围的真随机数。
	//for i := 0; i < 20; i++ {
	//	result, _ := rand.Int(rand.Reader, big.NewInt(50))
	//	fmt.Println(result)
	//}

	//for i := 0; i < 20; i++ {
	//	result := GetRangeRandNum(20, 50)
	//	fmt.Println(result)
	//}

	//now := time.Now()
	//num := GetNumberToSeconds("187293")
	//fmt.Println(num)
	//now = now.Add(time.Duration(num) * time.Second)
	//fmt.Println(now.Unix())

	//data := make(map[int32]string)
	//data = map[int32]string{1: "", 7: "", 6: "", 5: "", 4: "", 3: "", 2: "", 8: "", 9: "", 11: "", 12: "", 34: ""}
	//levels := make([]int, 0, 0)
	//for k, _ := range data {
	//	levels = append(levels, int(k))
	//}
	//sort.Ints(levels)
	//fmt.Println(levels)

	//num, _ := GetDaysBetween2Date("2022-11-12 09:00:00", "2022-11-15 18:00:00")
	//fmt.Println(num)

	//nums := []int{2, 2, 1, 1, 5, 3, 5, 6, 7, 6, 8, 8, 7}
	//fmt.Println(singleNumber(nums))

	//decimalToBinary(1048576)

	//t := testA(0)

	//slice := make([]int, 0, 10)
	//slice = append(slice, 1)
	//testSlice(slice)
	//fmt.Println(slice)
	//fmt.Printf("%p\n", &slice)
	//
	//fmt.Println()
	//
	//m := make(map[int]int)
	//m[1] = 2
	//testMap(m)
	//fmt.Println(m)
	//fmt.Printf("%p\n", &m)

	//var num int64 = 72
	//var diffTime int64 = 1669390921 - time.Now().Unix()
	//var lockTime int64 = 43200
	//numForOne := lockTime / num
	//fmt.Println(diffTime, numForOne)
	//
	//conNum := num
	//var extraNum int64 = 0
	//if diffTime < lockTime && diffTime%numForOne != 0 {
	//	extraNum = 1
	//}
	//conNum = (diffTime / numForOne) + extraNum
	//// 不能超过num
	//if conNum > num {
	//	conNum = num
	//}
	//fmt.Println(conNum)

	allData := make([]*int32, 0)
	fmt.Println(allData)
	if len(allData) <= 0 {
		fmt.Println("dasdadsa")
	}
}

var chars string = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

func EncodeShortId(num int64) string {
	bytes := []byte{}
	for num > 0 {
		bytes = append(bytes, chars[num%62])
		num = num / 62
	}
	Reverse(bytes)
	return string(bytes)
}

func DecodeShortId(str string) int64 {
	var num int64
	n := len(str)
	for i := 0; i < n; i++ {
		pos := strings.IndexByte(chars, str[i])
		num += int64(math.Pow(62, float64(n-i-1)) * float64(pos))
	}
	return num
}

func Reverse(a []byte) {
	for left, right := 0, len(a)-1; left < right; left, right = left+1, right-1 {
		a[left], a[right] = a[right], a[left]
	}
}

func Max64(x, y int64) int64 {
	if x > y {
		return x
	}

	return y
}

func a() {
	defer func() {
		if r := recover(); r != nil {
			fmt.Println(r)
		}
	}()

	go b()
}

func b() {

	panic("asdsadsa")
}

func testSlice(s []int) {
	s = append(s, 11)
	s = append(s, 13)
	s[0] = 11
	s[1] = 12
	fmt.Println(s)
	fmt.Printf("%p\n", &s)
}

func testMap(m map[int]int) {
	m[1] = 1
	fmt.Println(m)
	fmt.Printf("%p\n", m)
}

func testA[T int | int64](a T) func() T {
	return func() T {
		a = a + 1
		return a
	}
}

func decimalToBinary(num int) {
	var binary []int

	for num != 0 {
		binary = append(binary, num%2)
		num = num / 2
	}
	fmt.Println(binary)
	if len(binary) == 0 {
		fmt.Printf("%d\n", 0)
	} else {
		//for i := 27; i >= 0; i-- {
		//	fmt.Printf("%d", binary[i])
		//}
		fmt.Println()
	}
}

// 获取两个时间戳的相差天数
func GetTwoTimeDateNum(t1, t2 int64) int64 {
	if t1 > t2 {
		t1, t2 = t2, t1
	}
	return ((t2 - t1) / 86400) + 1
}

func singleNumber(nums []int) int {
	result := 0
	for i := 0; i < len(nums); i++ {
		result = result ^ nums[i]
		fmt.Println(result)
	}
	return result
}

func containsDuplicate(nums []int) bool {
	m := make(map[int]int8)
	for i := 0; i < len(nums); i++ {
		if _, ok := m[nums[i]]; ok {
			return true
		}
		m[nums[i]] = 1
	}
	return false
}

//func rotate(nums []int, k int) {
//	le := len(nums)
//	if le < 2 {
//		return
//	}
//	if k > le {
//		k = k % le
//	}
//	temp1 := nums[:le-k]
//	temp2 := nums[le-k:]
//	temp2 = append(temp2, temp1...)
//	for i := 0; i < le; i++ {
//		nums[i] = temp2[i]
//	}
//}

func reverse(a []int) {
	for i, n := 0, len(a); i < n/2; i++ {
		a[i], a[n-1-i] = a[n-1-i], a[i]
	}
}
func rotate(nums []int, k int) {
	k %= len(nums)
	reverse(nums)
	reverse(nums[:k])
	reverse(nums[k:])
}

func InArray[T int32 | int64 | string, A []T](arr A, s T) bool {
	m := make(map[any]int)
	for _, v := range arr {
		m[v] = 1
	}
	if _, ok := m[s]; ok {
		return true
	}
	return false
}

func GetDaysBetween2Date(date1Str, date2Str string) (int, error) {
	format := "2006-01-02 15:04:05"
	// 将字符串转化为Time格式
	date1, err := time.ParseInLocation(format, date1Str, time.Local)
	if err != nil {
		return 0, err
	}
	// 将字符串转化为Time格式
	date2, err := time.ParseInLocation(format, date2Str, time.Local)
	if err != nil {
		return 0, err
	}
	if date1.Sub(date2).Seconds() > 0 {
		return 0, nil
	}

	//计算相差天数
	return int(date2.Sub(date1).Hours()/24) + 1, nil
}

// GetNowDateString 获取当前日期
func GetNowDateString() string {
	return time.Now().Format("2006-01-02")
}

// 解析excel中的 “080000”，转成秒
func GetNumberToSeconds(s string) int64 {
	if len(s) != 6 {
		return 0
	}
	var num int64
	hour := s[0:2]
	min := s[2:4]
	sec := s[4:]
	if hour != "00" {
		hnum, _ := strconv.ParseInt(hour, 10, 32)
		fmt.Println("hour", hour)
		num += hnum * 60 * 60
	}
	if min != "00" {
		mnum, _ := strconv.ParseInt(min, 10, 32)
		fmt.Println("min", min)
		num += mnum * 60
	}
	if sec != "00" {
		snum, _ := strconv.ParseInt(sec, 10, 32)
		fmt.Println("sec", sec)
		num += snum
	}
	return num
}

func SetTimeOut(tm time.Duration, f func()) {
	go func() {
		fmt.Println("定时器执行开始")
		t := time.NewTimer(tm)
		<-t.C
		f()
	}()
}

func GetNowTimeString() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

/*
// 将时间分隔成每月
例：2021-09-22 16:00:00 -- 2021-12-01 15:59:59

结果：

2021-09-22 16:00:00 2021-09-30 23:59:59 202109
2021-10-01 00:00:00 2021-10-31 23:59:59 202110
2021-11-01 00:00:00 2021-11-30 23:59:59 202111
2021-12-01 00:00:00 2021-12-01 15:59:59 202112

*/
func GetMonInfo(t1, t2 time.Time) ([]MonInfo, bool) {
	sameMonth := false
	result := make([]MonInfo, 0)
	//	先判断两个日期是否在同一个月
	if t1.Format("200601") == t2.Format("200601") {
		result = append(result, MonInfo{
			StartDay: t1.Format("2006-01-02 15:04:05"),
			EndDay:   t2.Format("2006-01-02 15:04:05"),
			MonStr:   t2.Format("200601"),
		})
		sameMonth = true
	} else {

		//	获取第一个日期在当月的最后一天的23:59:59
		endT1 := time.Date(t1.Year(), t1.Month()+1, 1, 0, 0, 0, -1, t1.Location())

		result = append(result, MonInfo{
			StartDay: t1.Format("2006-01-02 15:04:05"),
			EndDay:   endT1.Format("2006-01-02 15:04:05"),
			MonStr:   t1.Format("200601"),
		})

		// 将第一个日期的时间重置为当月的1号，防止增加1个月后得到的日期不是下月的1号
		t1Tmp := time.Date(t1.Year(), t1.Month(), 1, 0, 0, 0, 0, t1.Location())

		// 判断是否达到第二个日期
		var i = 1
		for {
			t3 := t1Tmp.AddDate(0, i, 0)
			// 判断是否到达第二个日期所在的月份
			if t3.Format("200601") == t2.Format("200601") {
				// 获取第二个日期在当月的第一天的起始时间
				startT2 := time.Date(t2.Year(), t2.Month(), 1, 0, 0, 0, 0, t2.Location())

				result = append(result, MonInfo{
					StartDay: startT2.Format("2006-01-02 15:04:05"),
					EndDay:   t2.Format("2006-01-02 15:04:05"),
					MonStr:   t2.Format("200601"),
				})
				// 跳出
				break
			} else {
				startT3 := time.Date(t3.Year(), t3.Month(), 1, 0, 0, 0, 0, t3.Location())
				endT3 := time.Date(t3.Year(), t3.Month()+1, 1, 0, 0, 0, -1, t3.Location())
				result = append(result, MonInfo{
					StartDay: startT3.Format("2006-01-02 15:04:05"),
					EndDay:   endT3.Format("2006-01-02 15:04:05"),
					MonStr:   t3.Format("200601"),
				})
			}
			i++

			// 为了防止异常导致 for 循环无法停止出现内存溢出，加一个防护措施
			if i > 12 {
				break
			}
		}
	}

	return result, sameMonth
}

type MonInfo struct {
	StartDay string
	EndDay   string
	MonStr   string
}

var num int64

//生成24位订单号
//前面17位代表时间精确到毫秒，中间3位代表进程id，最后4位代表序号
func GetOrderId() string {
	t := time.Now()
	s := t.Format("20060102150405")
	m := t.UnixNano()/1e6 - t.UnixNano()/1e9*1e3
	ms := sup(m, 3)
	p := os.Getpid() % 1000
	ps := sup(int64(p), 3)
	//i := atomic.AddInt64(&num, int64(rand.Intn(10000)))
	i := int64(rand.Intn(10000))
	r := i % 10000
	rs := sup(r, 4)
	return fmt.Sprintf("%s%s%s%s", s, ms, ps, rs)
}

//对长度不足n的数字前面补0
func sup(i int64, n int) string {
	m := fmt.Sprintf("%d", i)
	for len(m) < n {
		m = fmt.Sprintf("0%s", m)
	}
	return m
}

////生成唯一随机数字
//func GetGlobalRandIntId() (int64, error) {
//	currWoker := &idworker.IdWorker{}
//	currWoker.InitIdWorker(1000, 1)
//	newID, err := currWoker.NextId()
//	if err != nil {
//		return 0, err
//	}
//	return newID, nil
//}
