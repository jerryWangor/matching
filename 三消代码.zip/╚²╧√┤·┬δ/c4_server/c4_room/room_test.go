package main

import (
	"bytes"
	"c4_center/kproto"
	"c4_center/ktcp"
	"github.com/sirupsen/logrus"
	"io"
	"io/ioutil"
	"net"
	"net/http"
	"testing"
	"time"
)

var Codec = &ktcp.ProtobufCodec{}
var Packer = &ktcp.DefaultPacker{}

var UserIds []string

func InitUsers() {
	UserIds = []string{"wangji1", "wangji2", "wangji3", "wangji4", "wangji5", "wangji6", "wangji7", "wangji8", "wangji9", "wangji10", "wangji11", "wangji12", "wangji13", "wangji14", "wangji15", "wangji16", "wangji17", "wangji18", "wangji19", "wangji20", "wangji21", "wangji22", "wangji23", "wangji24", "wangji25", "wangji26", "wangji27", "wangji28", "wangji29", "wangji30", "wangji31", "wangji32", "wangji33", "wangjin", "wangjin1", "wangjin2", "wangjin3", "wangjin4", "wangjin5", "wangjin6", "wangjin7", "wangjin8", "wangjin9"}
}

func TestClient(t *testing.T) {

	InitUsers()
	// 登录
	for _, id := range UserIds {
		b, _ := Codec.Encode(&kproto.LOGIN_SESSION_REQ{Userid: id, Pswd: "123456"})
		req, err := http.NewRequest("POST", "http://192.168.2.6:6001/login", bytes.NewBuffer(b))
		if err != nil {
			t.Fatal(err)
		}

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			t.Fatal(err)
		}

		body, _ := ioutil.ReadAll(resp.Body)

		m := &kproto.LOGIN_SESSION_RESP{}
		Codec.Decode(body, m)

		go connect(id, m.Data.Session)

		time.Sleep(2 * time.Second)
	}

	select {}
}

func connect(userId string, session string) {
	conn, err := net.Dial("tcp", "192.168.2.6:7001")
	if err != nil {
		panic(err)
	}
	// {"AccountId":"68f4571a-d8c5-4974-b822-67d47633d08c","Session":"ce76a5ff-e4d4-411f-9a49-fef6e92d54fa","GateAddress":"127.0.0.1:7001","RoomID":"","RoomAddress":""}
	req := &kproto.GATE_CONN_REQ{
		Userid:  userId,
		Session: session,
	}
	data, _ := Codec.Encode(req)

	sendData(conn, kproto.MSG_GATE_CONN_REQ_ID, data, req.String())
	time.Sleep(time.Second)

	go receiveData(userId, conn)

	// 匹配机器人
	reqL := &kproto.MATCH_REQUEST_REQ{Type: 1}
	dataL, _ := Codec.Encode(reqL)
	sendData(conn, kproto.MSG_MATCH_REQUEST_REQ_ID, dataL, req.String())
}

func sendData(conn io.Writer, msgId kproto.MSG, data []byte, str string) {
	packedMsg, _ := Packer.Pack(ktcp.NewMessage(uint32(msgId), data))
	if _, err := conn.Write(packedMsg); err != nil {
		logrus.Error(err)
	}
	logrus.Infof("send | id: %d; size: %d; data: %s", msgId, len(data), str)
}

func receiveData(userId string, conn io.Reader) {
	i := 0
	for {
		msg, err := Packer.Unpack(conn)
		if err != nil {
			logrus.Error(err)
			return
		}
		var str string
		switch msg.ID() {
		case uint32(kproto.MSG_GATE_CONN_RESP_ID):
			var respData kproto.GATE_CONN_RESP
			if err := Codec.Decode(msg.Data(), &respData); err != nil {
				panic(err)
			}
			str = respData.String()
		case uint32(kproto.MSG_MATCH_RESULT_RESP_ID):
			var respData kproto.MATCH_REQUEST_RESP
			if err := Codec.Decode(msg.Data(), &respData); err != nil {
				panic(err)
			}
			str = respData.String()
			// 收到消息后连接房间
			go connectRoom(userId, &respData)
		case uint32(kproto.MSG_BATTLE_ENTER_ROOM_RESP_ID):
			var respData kproto.BATTLE_ENTER_ROOM_RESP
			if err := Codec.Decode(msg.Data(), &respData); err != nil {
				logrus.Error(err)
			}
			str = respData.String()
		}
		i += 1
		logrus.Infof("recv | id: %d; size: %d; data: %s; count: %d", msg.ID(), len(msg.Data()), str, i)
	}
}

func connectRoom(userId string, resp *kproto.MATCH_REQUEST_RESP) {
	conn, err := net.Dial("tcp", resp.RoomAddr)
	if err != nil {
		logrus.Error(err)
	}
	// {"AccountId":"68f4571a-d8c5-4974-b822-67d47633d08c","Session":"ce76a5ff-e4d4-411f-9a49-fef6e92d54fa","GateAddress":"127.0.0.1:7001","RoomID":"","RoomAddress":""}
	req := &kproto.BATTLE_ENTER_ROOM_REQ{
		UserId: userId,
		RoomId: resp.RoomId,
	}
	data, _ := Codec.Encode(req)

	sendData(conn, kproto.MSG_BATTLE_ENTER_ROOM_REQ_ID, data, req.String())
	time.Sleep(time.Second)

	go receiveData(userId, conn)
}
