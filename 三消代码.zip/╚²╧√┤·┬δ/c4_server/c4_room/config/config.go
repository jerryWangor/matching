package config

import (
	"c4_center/registry"

	"github.com/sirupsen/logrus"
	"gopkg.in/ini.v1"
)

var (
	GrpcConfigInstant  *GrpcConfig               = &GrpcConfig{}
	EtcdConfigInstant  *EtcdConfig               = &EtcdConfig{}
	MongoConfigInstant *MongoConfig              = &MongoConfig{}
	RedisConfigInstant *RedisConfig              = &RedisConfig{}
	TcpConfigInstant   *TcpConfig                = &TcpConfig{}
	GameConfigInstant  *GameConfig               = &GameConfig{}
	LogsConfigInstant  *LogsConfig               = &LogsConfig{}
	GrpcServiceInstant *registry.ServiceInstance = &registry.ServiceInstance{}
	TcpServiceInstant  *registry.ServiceInstance = &registry.ServiceInstance{}
)

type EtcdConfig struct {
	Etcd_endpoint []string
}

type GrpcConfig struct {
	Grpc_addr string
}

type TcpConfig struct {
	Tcp_addr string
}

type MongoConfig struct {
	Mongo_DB   string
	Mongo_addr string
}

type RedisConfig struct {
	Redis_addr     string
	Redis_pswd     string
	Redis_DB       int
	Redis_poolSize int
}

type LogsConfig struct {
	Path  string
	Level logrus.Level
}

type GameConfig struct {
	Path string
}

func Init(path string) {
	cfg, err := ini.Load(path)
	if err != nil {
		logrus.Fatal(err)
	}

	cfg, err = ini.Load(cfg.Section("").Key("app_mode").String())
	if err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("etcd").MapTo(EtcdConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("grpc").MapTo(GrpcConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("tcp").MapTo(TcpConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("mongo").MapTo(MongoConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("redis").MapTo(RedisConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("grpc-service-instant").MapTo(GrpcServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("tcp-service-instant").MapTo(TcpServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("game-config").MapTo(GameConfigInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := cfg.Section("logs").MapTo(LogsConfigInstant); err != nil {
		logrus.Fatal(err)
	}
}
