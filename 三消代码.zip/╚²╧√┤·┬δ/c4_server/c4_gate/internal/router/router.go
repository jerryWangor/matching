package router

import (
	"c4_center/container/credis"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/ktcp"
	"c4_gate/config"
	"c4_gate/internal"
	"context"
	"encoding/json"
	"time"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
)

func Connection(ctx ktcp.Context) {
	var reqData kproto.GATE_CONN_REQ
	if err := ctx.Bind(&reqData); err != nil {
		logrus.Error(err)
		ctx.SetResponse(uint32(kproto.MSG_GATE_CONN_RESP_ID), &kproto.GATE_CONN_RESP{Code: -1})
		return
	}

	//get session
	sessStr, err := kredis.GetStr(context.Background(), reqData.Userid)
	if err != nil {
		logrus.Error(err)
		ctx.SetResponse(uint32(kproto.MSG_GATE_CONN_RESP_ID), &kproto.GATE_CONN_RESP{Code: -2})
		return
	}

	//redis session decode to json
	var sessData credis.SessionInfo
	if err = json.Unmarshal([]byte(sessStr), &sessData); err != nil {
		logrus.Error(err)
		ctx.SetResponse(uint32(kproto.MSG_GATE_CONN_RESP_ID), &kproto.GATE_CONN_RESP{Code: -3})
		return
	}

	//session check
	if sessData.Session != reqData.Session {
		ctx.SetResponse(uint32(kproto.MSG_GATE_CONN_RESP_ID), &kproto.GATE_CONN_RESP{Code: -4})
		return
	}

	//add gate grpc address in session
	sessData.GateGrpcAddress = config.GrpcServiceInstant.Endpoints[0]
	b, err := json.Marshal(sessData)
	if err != nil {
		logrus.Error(err)
		ctx.SetResponse(uint32(kproto.MSG_GATE_CONN_RESP_ID), &kproto.GATE_CONN_RESP{Code: -5})
		return
	}

	//session store
	err = kredis.SetStr(context.Background(), sessData.UserID, string(b), time.Hour*24)
	if err != nil {
		logrus.Error(err)
		ctx.SetResponse(uint32(kproto.MSG_GATE_CONN_RESP_ID), &kproto.GATE_CONN_RESP{Code: -6})
		return
	}

	//顶号
	s := internal.Sessions.GetSession(reqData.Userid)
	if s != nil {
		logrus.Infof("same account login -> %v", reqData.Userid)
		s.SetFlag(1) //设置flag后,关闭此连接不处理
		s.Close()
	}

	//update login time
	kmongo.UpdateOne(context.TODO(), kmongo.AccountCollection, bson.M{"user_id": reqData.Userid}, bson.M{"$set": bson.M{"login_time": time.Now()}})

	//store connection session if success
	ctx.Session().SetID(reqData.Userid)
	internal.Sessions.SetSession(ctx.Session())

	//return success
	ctx.SetResponse(uint32(kproto.MSG_GATE_CONN_RESP_ID), &kproto.GATE_CONN_RESP{Code: 0, Data: &kproto.GateResp{RoomId: sessData.RoomID, RoomAddr: sessData.RoomTcpAddress}})
}

func HeartBeat(ctx ktcp.Context) {
	if internal.Sessions.GetSession(ctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		ctx.SetResponse(uint32(kproto.MSG_GATE_HEARTBEAT_RESP_ID), &kproto.GATE_HEARTBEAT_RESP{Time: -1})
		return
	}

	ctx.SetResponse(uint32(kproto.MSG_GATE_HEARTBEAT_RESP_ID), &kproto.GATE_HEARTBEAT_RESP{Time: time.Now().UnixMilli()})
}
