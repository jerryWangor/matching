package cmysql

type LogPlayer struct {
	Accid string `gorm:"primaryKey" json:"accid"` 
	Coin int `gorm:"" json:"coin"` 
	LastLoginTime int `gorm:"" json:"lastlogintime"` 
}