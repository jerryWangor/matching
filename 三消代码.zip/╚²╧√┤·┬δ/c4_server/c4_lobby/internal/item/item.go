package item

import (
	"c4_center/container/cmongo"
	"c4_center/game_config"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/utils"
	"context"
	"fmt"

	"github.com/sirupsen/logrus"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
)

//获取用户所有道具信息
func LoadItemByUserId(uid string) []*cmongo.Item {
	var ret []*cmongo.Item
	kmongo.Get(context.TODO(), kmongo.ItemCollection, &ret, bson.M{"user_id": uid, "num": bson.M{"$gt": 0}})
	return ret
}

//获取用户多个道具信息（根据type_id）
func LoadItemByUserTypeIds(uid string, tids []int32) []*cmongo.Item {
	var ret []*cmongo.Item
	kmongo.Get(context.TODO(), kmongo.ItemCollection, &ret, bson.M{"user_id": uid, "type_id": bson.M{"$in": tids}})
	return ret
}

//获取用户某个道具信息（根据ids）
func LoadItemByUserIdx(uid string, idx string) *cmongo.Item {
	var ret cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &ret, bson.M{"user_id": uid, "_id": idx})
	if len(ret.ID) <= 0 {
		return nil
	}
	return &ret
}

//获取用户多个道具信息（根据type_id）
func LoadItemByUserTypeId(uid string, tid int32) *cmongo.Item {
	var ret cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &ret, bson.M{"user_id": uid, "type_id": tid})
	if len(ret.ID) <= 0 {
		return nil
	}
	return &ret
}

//用户增加道具（对内单个）
func insertItem(i *cmongo.Item) error {
	if !kmongo.InsertOne(context.TODO(), kmongo.ItemCollection, i) {
		return fmt.Errorf("insert item error. -> user_id: %v, type_id: %v", i.UserID, i.TypeId)
	}
	return nil
}

//用户增加道具（对外，有的话会先更新，后面加道具获得日志）
func InsertUpdateItem(i *cmongo.Item) (int64, error) {

	num := i.Num
	var err error
	if i.ItemConfig.StackingLimit == 0 {
		if err = AddItemUnlimit(i); err != nil {
			return 0, err
		}
	} else {
		num, err = AddItemLimit(i)
		if err != nil {
			return num, err
		}
	}

	return num, nil
}

//无数量限制堆叠
func AddItemUnlimit(i *cmongo.Item) error {
	if item := LoadItemByUserTypeId(i.UserID, i.TypeId); item != nil {
		return UpdateItemNumByIdx(item.UserID, item.ID, item.Num+i.Num)
	} else {
		if !kmongo.InsertOne(context.TODO(), kmongo.ItemCollection, i) {
			return fmt.Errorf("insert item error. -> user_id: %v, type_id: %v", i.UserID, i.TypeId)
		}
	}

	return nil
}

//有数量限制堆叠
func AddItemLimit(item *cmongo.Item) (int64, error) {
	var tmp []*cmongo.Item
	kmongo.GetOne(context.TODO(), kmongo.ItemCollection, &tmp, bson.M{"user_id": item.UserID, "type_id": item.TypeId})

	totalNum := item.Num //总数量
	lastNum := item.Num  //剩余数量
	var err error
	//如果有的话就循环更新到limit数量
	for k := range tmp {
		// 判断数量是否已达到limit上限
		if tmp[k].Num < int64(tmp[k].ItemConfig.StackingLimit) {
			lastNum, err = InsertOrUpdateLimitNum(tmp[k], lastNum, false)
			if err != nil {
				return totalNum - lastNum, err
			}
		}
	}

	//剩余数量循环写入
	for lastNum > 0 {
		lastNum, err = InsertOrUpdateLimitNum(item, lastNum, true)
		if err != nil {
			return totalNum - lastNum, err
		}
	}

	return totalNum - lastNum, nil
}

//写入&更新物品数据-> (int64 : 返回剩余数量)
func InsertOrUpdateLimitNum(item *cmongo.Item, maxNum int64, isInsert bool) (int64, error) {
	if isInsert {
		item.Num = 0
	}

	//装载量
	load := utils.Min64(int64(item.ItemConfig.StackingLimit)-item.Num, maxNum)
	//剩余量
	last := maxNum - load
	//更新装载数量
	item.Num += load

	if isInsert {
		//宝箱类需要检测是否能获取
		if item.MainType == game_config.MainType_Box && item.SubType == game_config.SubType_BoxGrade {
			item.Index = GetBoxIndex(item.UserID)
			if item.Index < 0 {
				return 0, nil
			}
		}

		//更新ID
		item.ID = primitive.NewObjectID().Hex()
		//写入
		if err := insertItem(item); err != nil {
			return 0, err
		}
	} else {
		//更新
		if err := UpdateItemNumByIdx(item.UserID, item.ID, item.Num); err != nil {
			return 0, err
		}
	}

	return last, nil
}

//用户增加道具（多个道具）
func InsertUpdateManyItem(i []interface{}) error {
	for _, v := range i {
		if _, err := InsertUpdateItem(v.(*cmongo.Item)); err != nil {
			return err
		}
	}
	return nil
}

// 消耗道具数量（消耗统一走此入口，后面加道具消耗日志）
func ConsumeItemByIdx(uid string, idx string, nowNum int64, conNum int64) error {
	// 判断是否有足够的数量，后面可以兼容有堆叠上限的分堆消耗
	return UpdateItemNumByIdx(uid, idx, nowNum-conNum)
}

//用户更新道具，更新数量（根据idx）
func UpdateItemNumByIdx(uid string, idx string, num int64) error {
	if num <= 0 {
		return DeleteItemByIdx(uid, idx)
	}
	if !kmongo.UpdateOne(context.TODO(), kmongo.ItemCollection, bson.M{"user_id": uid, "_id": idx}, bson.M{"$set": bson.M{"num": num}}) {
		return fmt.Errorf("update item error -> idx: %v", idx)
	}
	return nil
}

//用户更新道具（全更新）（根据idx）
func ReplaceItemByIdx(i *cmongo.Item) error {
	if !kmongo.ReplaceOne(context.TODO(), kmongo.ItemCollection, bson.M{"user_id": i.UserID, "_id": i.ID}, i) {
		return fmt.Errorf("update item error -> %v", i.ID)
	}
	return nil
}

//用户删除道具（根据idx）
func DeleteItemByIdx(uid string, idx string) error {
	if !kmongo.DeleteOne(context.TODO(), kmongo.ItemCollection, bson.M{"user_id": uid, "_id": idx}) {
		return fmt.Errorf("delete item error -> %v", idx)
	}
	return nil
}

type ItemInit struct {
	*cmongo.Item
}

func GetInitItem(uid string, tid int32, num int64) *cmongo.Item {
	if num <= 0 {
		logrus.Errorf("item num can not be nil -> %v", tid)
		return nil
	}
	ret := &ItemInit{}
	return ret.InitItem(uid, tid, num)
}

func (h *ItemInit) InitItem(uid string, tid int32, num int64) *cmongo.Item {
	h.Item = &cmongo.Item{ID: primitive.NewObjectID().Hex(), UserID: uid, TypeId: tid, Num: num}
	if err := h.LoadItemConfig(); err != nil {
		logrus.Error(err)
		return nil
	}

	//设置大类小类，方便后面的宝箱插槽查询
	h.MainType = h.ItemConfig.MainType
	h.SubType = h.ItemConfig.SubType

	return h.Item
}

func (h *ItemInit) LoadItemConfig() error {
	//道具配置
	h.ItemConfig = game_config.ItemConfigInstant.GetInfo(h.TypeId)

	if h.ItemConfig == nil {
		return fmt.Errorf("cannot get config . type_id -> %v", h.TypeId)
	}
	return nil
}

//道具信息返回
func ItemData(h *cmongo.Item) *kproto.ItemInfo {
	hi := &ItemInit{h}

	ret := &kproto.ItemInfo{}
	ret.Id = hi.ID
	ret.TypeId = hi.TypeId
	ret.Num = hi.Num
	ret.Index = hi.Index
	ret.UnlockTime = hi.UnlockTime

	return ret
}

// -------------------------------------------------- 宝箱插槽相关

//获取用户所有宝箱槽位信息
func LoadBoxSlotByUserId(uid string) []*cmongo.Item {
	var ret []*cmongo.Item
	kmongo.Get(context.TODO(), kmongo.ItemCollection, &ret, bson.M{"user_id": uid, "main_type": game_config.MainType_Box, "sub_type": game_config.SubType_BoxGrade})
	return ret
}

//用户更新宝箱槽位，更新解锁时间
func UpdateBoxSlotUnlockTimeByIdx(idx string, time int64) error {
	if !kmongo.UpdateOne(context.TODO(), kmongo.ItemCollection, bson.M{"_id": idx}, bson.M{"$set": bson.M{"unlock_time": time}}) {
		return fmt.Errorf("update boxslot error -> idx: %v", idx)
	}
	return nil
}

//得到宝箱槽索引
func GetBoxIndex(uid string) int32 {
	// 判断是否有空槽
	bs := LoadBoxSlotByUserId(uid)
	if len(bs) >= int(cmongo.MAX_BOX_SLOT_INDEX+1) {
		return -1
	} else {
		hasIndexMap := make(map[int32]int32)
		for k := range bs {
			hasIndexMap[bs[k].Index] = bs[k].Index
		}
		//循环判断哪个是空槽
		for i := cmongo.MIN_BOX_SLOT_INDEX; i <= cmongo.MAX_BOX_SLOT_INDEX; i++ {
			if _, ok := hasIndexMap[i]; !ok {
				return i
			}
		}
	}

	// 没有空槽返回-1
	return -1
}
