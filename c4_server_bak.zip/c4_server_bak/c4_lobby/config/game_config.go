package config

import "c4_center/game_config"

func InitGameConfig() {
	//init
	game_config.InitHeroAttrConfig(GameConfigInstant.Path)
	game_config.InitChessColorGroupConfig(GameConfigInstant.Path)
	game_config.InitHeroConfig(GameConfigInstant.Path)
	game_config.InitSkillGroup(GameConfigInstant.Path)
	game_config.InitItemConfig(GameConfigInstant.Path)
	game_config.InitMainDropConfig(GameConfigInstant.Path)
	game_config.InitHeroLevelUpConfig(GameConfigInstant.Path)
	game_config.InitActivityConfig(GameConfigInstant.Path)
	game_config.InitPvPSegmentConfig(GameConfigInstant.Path)
	game_config.InitSignRewardConfig(GameConfigInstant.Path)
	game_config.InitShopTypeConfig(GameConfigInstant.Path)
	game_config.InitShopItemConfig(GameConfigInstant.Path)
	game_config.InitLadderQuotationConfig(GameConfigInstant.Path)
	game_config.InitConditionalOfShelfConfig(GameConfigInstant.Path)
}
