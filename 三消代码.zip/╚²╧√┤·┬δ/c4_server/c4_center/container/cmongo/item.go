package cmongo

import (
	"c4_center/game_config"
)

const (
	MAX_ITEM_NUM       int64 = 1<<63 - 1 // 无堆叠道具最大值
	MIN_BOX_SLOT_INDEX int32 = 0         // 宝箱插槽最小序号
	MAX_BOX_SLOT_INDEX int32 = 4         // 宝箱插槽最大序号
	OPEN_BOX_NORMAL    int32 = 0         // 普通解锁开启
	OPEN_BOX_KEYS      int32 = 1         // 钥匙开启
	OPEN_BOX_DIAMONDS  int32 = 2         // 钻石开启
)

// 用户道具信息
type Item struct {
	ID         string `bson:"_id"`         // idx
	UserID     string `bson:"user_id"`     // 所属玩家ID
	TypeId     int32  `bson:"type_id"`     // 道具模板ID
	Num        int64  `bson:"num"`         // 数量
	MainType   int32  `bson:"main_type"`   // 大类
	SubType    int32  `bson:"sub_type"`    // 小类
	Index      int32  `bson:"index"`       // 序号 0-4
	UnlockTime int64  `bson:"unlock_time"` // 解锁时间，时间戳 0 未解锁

	ItemConfig *game_config.ItemData `bson:"-"` // 道具信息
}

// 用户道具背包（此版本先不存mongo）
type ItemPackData struct {
	ID     string `bson:"_id"`     // idx
	UserID string `bson:"user_id"` // 所属玩家ID
	MaxCap int32  `bson:"max_cap"` // 最大容量，0 无限大

	ItemData []*Item `bson:"-"` // 道具列表
}
