package game_config

type LadderQuotation struct {
	ID          int32  `tb_name:"计价ID"`
	BuyCountMin int32  `tb_name:"购买次数min"`
	BuyCountMax int32  `tb_name:"购买次数max"`
	Consume     string `tb_name:"售价"`
}

var LadderQuotationConfigInstant *LadderQuotationConfig

type LadderQuotationConfig struct {
	LadderQuotation []*LadderQuotation
	Infos           map[int32][]*LadderQuotation //key == Id
}

func InitLadderQuotationConfig(path string) {
	LadderQuotationConfigInstant = &LadderQuotationConfig{Infos: make(map[int32][]*LadderQuotation)}
	//加载
	LoadJsonFile(path+"/LadderQuotation.json", LadderQuotationConfigInstant)
	//初始化
	LadderQuotationConfigInstant.InitIndex()
}

func (h *LadderQuotationConfig) InitIndex() {
	for i, _ := range h.LadderQuotation {
		h.Infos[h.LadderQuotation[i].ID] = append(h.Infos[h.LadderQuotation[i].ID], h.LadderQuotation[i])
	}
}

func (h *LadderQuotationConfig) GetInfo(id int32) []*LadderQuotation {
	data, ok := h.Infos[id]
	if !ok {
		return nil
	}
	return data
}
