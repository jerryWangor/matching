package room

import (
	"c4_center/container/credis"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_room/internal/match3"
	"context"
	"encoding/json"
	"sort"
	"time"

	"github.com/sirupsen/logrus"
	"golang.org/x/exp/slices"
)

const (
	//fsm state
	INIT_STATE   = 0
	ROLL_STATE   = 1
	PLAY_STATE   = 2
	FINISH_STATE = 3

	//board info
	BOARD_ROW    = 8
	BOARD_COLUMN = 8
)

type Table struct {
	ID            string
	MatchType     int32 //匹配类型
	RoundTime     int64
	RoundPastTime int64
	Delay         int64
	CurPlayerID   string
	Players       map[string]*Player
	CurRound      float32
	MaxRound      int32
	State         int32
	Board         *match3.Board
	//记录器
	ResultInfo  map[int32]*ResultInfo
	Count       int32                       //记数器
	ShuffleInfo *kproto.BATTLE_SHUFFLE_RESP //洗牌数据
	IsShuffle   bool                        //是否洗牌
	GameResult  GameResultInfo              //游戏结果
}

func NewTable(id string, matchType int32, delay int64) *Table {
	ret := &Table{ID: id, MatchType: matchType}
	ret.CurRound = 0
	ret.MaxRound = 99
	ret.RoundTime = 30 * int64(time.Second)
	ret.Delay = delay * int64(time.Millisecond)
	ret.State = INIT_STATE
	ret.Players = map[string]*Player{}
	ret.Board = match3.NewBoard(BOARD_ROW, BOARD_COLUMN)
	//初始化棋盘信息记录
	ret.ResultInfo = make(map[int32]*ResultInfo)
	ret.ActionInvoke()
	ret.Board.InitBoard()
	return ret
}

func (t *Table) ActionInvoke() {
	//回调记录
	t.Board.SetClearInvoke(t.ClearInvoke)
	t.Board.SetNewInvoke(t.NewInvoke)
	t.Board.SetSwapInvoke(t.SwapInvoke)
	t.Board.SetShuffleInvoke(t.ShuffleInvoke)
	t.Board.SetShuffleBeforeInvoke(t.ShuffleBeforeInvoke)
	t.Board.SetOneOpeartionBeforeInvoke(t.OneOpeartionBeforeInvoke)
	t.Board.SetOneOpeartionAfterInvoke(t.OneOpeartionAfterInvoke)
}

func (t *Table) OneOpeartionBeforeInvoke() {

}

func (t *Table) OneOpeartionAfterInvoke() {
	//增加操作次数处理
	t.AddActionCount()

	//记录消除的颜色(去重)
	var colors []int32

	for _, v := range t.ResultInfo[t.Count].ClearPieces {
		//增加能量
		t.GetPlayer(t.CurPlayerID).AddHeroEnergy(v.PType)

		if slices.Contains(colors, v.PType) {
			continue
		}

		colors = append(colors, v.PType)
	}

	//英雄普攻
	for _, v := range colors {
		t.GetPlayer(t.CurPlayerID).HeroAttack(t.Count, v)
	}

	//能量记录(一次消除后总结算)
	t.GetPlayer(t.CurPlayerID).RecordHeroEnergy(t.Count)

	//计数
	t.Count++
}

//判断是否增加用户可操作次数
func (t *Table) AddActionCount() {
	//只判断第一次用户操作的下落
	if t.Count != 0 {
		return
	}

	t.GetPlayer(t.CurPlayerID).AddActionCount(1) //新增
	t.ResultInfo[t.Count].SetIsAddAction(true)   //记录

	// row, col := make(map[int32]int32), make(map[int32]int32)

	// //横竖棋子数量记录
	// for _, v := range t.ResultInfo[t.Count].ClearPieces {
	// 	row[v.PosX] = row[v.PosX] + 1
	// 	col[v.PosY] = col[v.PosY] + 1
	// }

	// //检测是否有新增加(>=4)
	// if t.checkAddActionCount(row) || t.checkAddActionCount(col) {
	// 	t.GetPlayer(t.CurPlayerID).AddActionCount(1) //新增
	// 	t.ResultInfo[t.Count].SetIsAddAction(true)   //记录
	// }
}

//检测是否新增操作次数
func (t *Table) checkAddActionCount(val map[int32]int32) bool {
	for _, v := range val {
		if v >= 4 {
			return true
		}
	}
	return false
}

//清除上次记录
func (t *Table) SwapInvoke(sx, sy, dx, dy int32) {
	for k := range t.ResultInfo {
		delete(t.ResultInfo, k)
	}

	//清除记录
	t.GetPlayer(t.CurPlayerID).HeroResultInfo.Clear()

	//初始化记录器
	t.Count = 0
	t.IsShuffle = false
}

//洗牌开始前回调
func (t *Table) ShuffleBeforeInvoke() {
	t.IsShuffle = true
	t.ShuffleInfo = &kproto.BATTLE_SHUFFLE_RESP{}
}

//洗牌信息回调
func (t *Table) ShuffleInvoke(sx, sy, dx, dy int32) {
	t.ShuffleInfo.Coors = append(t.ShuffleInfo.Coors, &kproto.ShuffleCoordinate{Src: &kproto.BallCoordinate{X: sx, Y: sy}, Dst: &kproto.BallCoordinate{X: dx, Y: dy}})
}

//新生成棋子回调
func (t *Table) NewInvoke(piece []match3.Piece) {
	if info := t.ResultInfo[t.Count]; info == nil {
		t.ResultInfo[t.Count] = NewResultInfo()
	}

	t.ResultInfo[t.Count].SetNewPieces(piece)
}

//己清除棋子回调
func (t *Table) ClearInvoke(piece match3.Piece) {
	if info := t.ResultInfo[t.Count]; info == nil {
		t.ResultInfo[t.Count] = NewResultInfo()
	}

	t.ResultInfo[t.Count].SetClearPiece(piece)
}

func (t *Table) GetPlayer(userid string) *Player {
	return t.Players[userid]
}

//棋盘&玩家信息
func (t *Table) EnterRoomOutData() *kproto.BATTLE_BOARD_RESP {
	ret := &kproto.BATTLE_BOARD_RESP{}
	ret.BInfos = t.BoardOutData()
	ret.PInfos = t.PlayerOutData()
	return ret
}

func (t *Table) Roll() {
	var ps []*Player

	var except int32 = -1
	for k, v := range t.Players {
		except = v.RollExcept(except)
		ps = append(ps, t.Players[k])
	}

	sort.Slice(ps, func(i, j int) bool {
		return ps[i].RollPoint > ps[j].RollPoint
	})

	t.CurPlayerID = ps[0].ID
}

//棋盘输出信息
func (t *Table) BoardOutData() []*kproto.BallInfos {
	var ret []*kproto.BallInfos

	for i := 0; i < int(t.Board.Row); i++ {
		for j := 0; j < int(t.Board.Column); j++ {
			p := t.Board.Pieces[i][j]
			ret = append(ret, &kproto.BallInfos{Pos: &kproto.BallCoordinate{X: p.PosX, Y: p.PosY}, BallsTypes: p.PType})
		}
	}

	return ret
}

//玩家输出信息
func (t *Table) PlayerOutData() []*kproto.PlayerInfo {
	var ret []*kproto.PlayerInfo

	for _, v := range t.Players {
		ret = append(ret, v.PlayerData())
	}

	return ret
}

//重连输出信息
func (t *Table) ReEnterRoomOutData() *kproto.BATTLE_REENTER_ROOM_RESP {
	ret := &kproto.BATTLE_REENTER_ROOM_RESP{}
	ret.BInfos = t.BoardOutData()
	ret.PInfos = t.PlayerOutData()
	ret.Round = int32(t.CurRound)
	ret.UserId = t.CurPlayerID
	ret.RoundTime = (t.RoundTime - t.RoundPastTime) / int64(time.Millisecond)

	return ret
}

func (t *Table) ChangeRound(roundCount float32, changePlayer bool) {
	if changePlayer {
		for k := range t.Players {
			if k != t.CurPlayerID {
				t.CurPlayerID = k
				break
			}
		}
	}

	t.GetPlayer(t.CurPlayerID).ResetActionCount()
	t.GetPlayer(t.CurPlayerID).SetActionReceiver(true)
	t.CurRound += roundCount
	t.RoundPastTime = 0
	t.SendChangeRoundMsg()
}

func (t *Table) SetPlayer(ctx context.Context, player *Player) {
	player.SetCtx(ctx)
	t.Players[player.ID] = player
}

func (t *Table) GetExceptPlayer(userId string) *Player {
	for k := range t.Players {
		if k != userId {
			return t.Players[k]
		}
	}
	return nil
}

func (t *Table) IsReady() bool {
	if len(t.Players) != 2 {
		return false
	}

	for _, v := range t.Players {
		if !v.IsReady() {
			return false
		}
	}
	return true
}

func (t *Table) IsAlive() bool {
	for _, v := range t.Players {
		if v.Session != nil {
			return true
		}
	}

	return false
}

//游戏结束
func (t *Table) IsEnd() bool {
	ret := false

	//判断是否结束(一方死亡或投降就算结束)
	for _, v := range t.Players {
		if b, r := v.IsEnd(); b {
			t.GameResult.ResultType = r
			ret = true
			break
		}
	}

	if ret {
		//记录胜者
		for _, v := range t.Players {
			if b, _ := v.IsEnd(); !b {
				t.GameResult.Winner = v.ID
				t.GameResult.State = 1
				break
			}
		}
	}

	return ret
}

func (t *Table) SendChangeRoundMsg() {
	// logrus.Infof("change round : cur_player -> %v", t.CurPlayerID)
	//广播
	t.Boardcast(uint32(kproto.MSG_BATTLE_ROUND_RESP_ID), &kproto.BATTLE_ROUND_RESP{Round: int32(t.CurRound), RoundTime: (t.RoundTime - t.RoundPastTime) / int64(time.Millisecond), UserId: t.CurPlayerID})
}

func (t *Table) Boardcast(msgid uint32, data interface{}) {
	for _, v := range t.Players {
		if v.Session != nil {
			v.Session.AllocateContext().MustSetResponse(msgid, data).Send()
		}
	}
}

func (t *Table) Clear() {
	for _, v := range t.Players {
		if v.Bot {
			continue
		}

		t.ClearPlayerRedis(v.ID)
	}
}

func (t *Table) RewardResult() {
	winner, loser := t.GetWinner(), t.GetLoser()

	if winner == nil || loser == nil {
		logrus.Errorf("PANIC | PLAYERS LEN : %v  | WINNER : %v", len(t.Players), t.GameResult.Winner)
		for k := range t.Players {
			logrus.Errorf("PANIC | PLAYERS -> %v", t.Players[k].ID)
		}
		return
	}

	if !winner.Bot {
		winner.RankReward.CalcReward(winner, loser, true)
	}

	if !loser.Bot {
		loser.RankReward.CalcReward(winner, loser, false)
	}
}

func (t *Table) GetWinner() *Player {
	for k := range t.Players {
		if t.Players[k].ID == t.GameResult.Winner {
			return t.Players[k]
		}
	}

	return nil
}

func (t *Table) GetLoser() *Player {
	for k := range t.Players {
		if t.Players[k].ID != t.GameResult.Winner {
			return t.Players[k]
		}
	}

	return nil
}

func (t *Table) ClearPlayerRedis(userId string) {
	sessStr, err := kredis.GetStr(context.Background(), userId)
	if err != nil {
		logrus.Errorf("do not have session of userid : %s;", userId)
		return
	}

	var sessData credis.SessionInfo
	if json.Unmarshal([]byte(sessStr), &sessData) != nil {
		logrus.Errorf("session unmarshal err of userid : %s;", userId)
		return
	}

	//set room info to redis
	sessData.RoomID = ""
	sessData.RoomTcpAddress = ""

	//encode
	b, err := json.Marshal(sessData)
	if err != nil {
		logrus.Error(err)
		return
	}

	//session store
	err = kredis.SetStr(context.Background(), sessData.UserID, string(b), time.Hour*24)
	if err != nil {
		logrus.Error(err)
		return
	}
}
