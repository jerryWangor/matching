package khttp

import (
	"bytes"
	"c4_center/kproto"
	"c4_center/ktcp"
	"fmt"
	"io/ioutil"
	"net/http"
	"testing"
)

func TestHttp(t *testing.T) {
	code := &ktcp.ProtobufCodec{}
	re := &kproto.LOGIN_SESSION_REQ{Userid: "aaaa", Pswd: "bbbb"}
	b, _ := code.Encode(re)

	url := "http://127.0.0.1:6001/login"
	httpReq, err := http.NewRequest("POST", url, bytes.NewReader(b))
	if err != nil {
		fmt.Println(err)
		return
	}

	httpRsp, err := http.DefaultClient.Do(httpReq)
	if err != nil {
		fmt.Println(err)
		return
	}

	defer httpRsp.Body.Close()

	//read
	rspBody, err := ioutil.ReadAll(httpRsp.Body)
	if err != nil {
		fmt.Println(err)
		return
	}

	var rrr kproto.LOGIN_SESSION_RESP
	code.Decode(rspBody, &rrr)

	select {}
}
