package main

import (
	"fmt"
	"github.com/go-redis/redis"
	"time"
)

var redisClient *redis.Client

func main() {
	InitRedis()
	PoolRedis1()
	PoolStats()
	PoolRedis2()
	PoolStats()
	PoolRedis3()
	PoolStats()
}

func InitRedis() {

	defer func() {
		fuckedUp := recover() //recover() 捕获错误保存到变量中
		if fuckedUp != nil {
			fmt.Println("Redis连接异常：", fuckedUp)
		}
	}()

	addr := "127.0.0.1:6379"
	password := ""
	redisClient = redis.NewClient(&redis.Options{
		Addr:     addr,
		Password: password, // no password set
		DB:       0,        // use default DB
		PoolSize: 2,
	})

	_, err := redisClient.Ping().Result()
	if err != nil {
		panic(err)
	} else {
		fmt.Println(fmt.Sprintf("Connected to redis: %s", addr))
	}

}

func PoolRedis1() {
	redisClient.Set("aaa", "bbb", 10*time.Second)
}

func PoolRedis2() {
	redisClient.Set("aaa", "bbb", 10*time.Second)
}

func PoolRedis3() {
	redisClient.Set("aaa", "bbb", 10*time.Second)
}

func PoolStats() {
	fmt.Println(redisClient.PoolStats())
}
