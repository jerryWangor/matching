package game_config

type MainDropData struct {
	DropId    int32    `tb_name:"掉落Id"`
	DropType  int32    `tb_name:"掉落类型"`
	DropItems []string `tb_name:"掉落组"`
}

var MainDropConfigInstant *MainDropConfig

type MainDropConfig struct {
	MainDropData []*MainDropData
	Infos        map[int32]*MainDropData //key == Id
}

func InitMainDropConfig(path string) {
	MainDropConfigInstant = &MainDropConfig{Infos: make(map[int32]*MainDropData)}
	//加载
	LoadJsonFile(path+"/MainDropData.json", MainDropConfigInstant)
	//初始化
	MainDropConfigInstant.InitIndex()
}

func (h *MainDropConfig) InitIndex() {
	for i, _ := range h.MainDropData {
		h.Infos[h.MainDropData[i].DropId] = h.MainDropData[i]
	}
}

func (h *MainDropConfig) GetInfo(tid int32) *MainDropData {
	data, ok := h.Infos[tid]
	if !ok {
		return nil
	}
	return data
}
