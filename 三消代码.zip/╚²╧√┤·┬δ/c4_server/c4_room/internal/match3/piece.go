package match3

import "c4_center/game_config"

var (
	UP    = &Direction{DirX: 1, DirY: 0}
	DOWN  = &Direction{DirX: -1, DirY: 0}
	LEFT  = &Direction{DirX: 0, DirY: -1}
	RIGHT = &Direction{DirX: 0, DirY: 1}

	RTYPES = []int32{game_config.ChessColorType_Red, game_config.ChessColorType_Blue, game_config.ChessColorType_Green, game_config.ChessColorType_Yellow, game_config.ChessColorType_Purple}
)

//方向
type Direction struct {
	DirX int32
	DirY int32
}

type Piece struct {
	PosX  int32
	PosY  int32
	PType int32
}

func NewPiece(x, y, t int32) *Piece {
	return &Piece{
		PosX:  x,
		PosY:  y,
		PType: t,
	}
}

func (p *Piece) RelativeCoordinates(direction *Direction, distance int32) (int32, int32) {
	return p.PosX + distance*direction.DirX, p.PosY + distance*direction.DirY
}
