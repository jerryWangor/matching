package config

import "c4_center/game_config"

var firstRun = true

func InitGameConfig() {
	//init
	game_config.InitActivityConfig(GameConfigInstant.Path)
	game_config.InitShopTypeConfig(GameConfigInstant.Path)
	game_config.InitShopItemConfig(GameConfigInstant.Path)
	game_config.InitConditionalOfShelfConfig(GameConfigInstant.Path)

	//
	if !firstRun {

	}

	firstRun = false
}
