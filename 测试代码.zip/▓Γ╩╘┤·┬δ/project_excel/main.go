package main

import (
	"encoding/json"
	"fmt"
	"github.com/xuri/excelize/v2"
	"os"
	"strconv"
	"strings"
)

var AutoIncrement, PrimaryKey string
var UniqueKey, IndexKey []string

type TableData struct {
	ModelName string               `json:"ModelName"`
	TableName string               `json:"TableName"`
	Split     int                  `json:"Split"`
	Sql       string               `json:"Sql"`
	Field     map[string]FieldData `json:"Field"`
}

type JsonData struct {
	Tool         string       `json:"@Tool"`
	Version      string       `json:"@Version"`
	LogTableData []*TableData `json:"LogTableData"`
}

type FieldData struct {
	Name string `json:"Name"`
	Type string `json:"Type"`
	Key  string `json:"Key"`
}

func main() {

	f, err := excelize.OpenFile("./excel/account_login.xlsx")
	if err != nil {
		fmt.Println(err)
		return
	}
	defer func() {
		// 关闭文件
		if err := f.Close(); err != nil {
			fmt.Println(err)
		}
	}()

	jsondata := JsonData{
		Tool:         "github.com/davyxu/tabtoy",
		Version:      "",
		LogTableData: []*TableData{},
	}

	//// 从指定的单元格中取值
	//cell, err := f.GetCellValue("Sheet1", "B2")
	//if err != nil {
	//	fmt.Println(err)
	//	return
	//}
	//fmt.Println(cell)
	for _, tname := range f.GetSheetList() {
		// 从sheet中获取行数据
		rows, err := f.GetRows(tname)
		if err != nil {
			fmt.Println(err)
			return
		}

		FieldMapData := make(map[string]FieldData)
		real_tname := tname
		i := 0
		table_sql := ``
		table_name := ""
		table_comment := ""
		AutoIncrement = ""
		PrimaryKey = ""
		UniqueKey = []string{}
		IndexKey = []string{}
		split := 0
		for _, row := range rows {
			i++
			if i == 1 {
				tinfo := strings.Split(row[0], "#")
				table_name = tinfo[0]
				table_comment = tinfo[1]
				if tinfo[2] == "分月" {
					split = 1
				} else if tinfo[2] == "分天" {
					split = 2
				}
				table_sql += `CREATE TABLE ` + table_name + ` (` + "\n"
			} else if i == 2 {

			} else {
				table_sql += GetFieldSql(row, FieldMapData)
			}
		}

		// 加上主键 唯一键 索引
		var keystr []string
		if PrimaryKey != "" {
			keystr = append(keystr, fmt.Sprintf("  primary key (%s)", PrimaryKey))
		}
		if len(UniqueKey) > 0 {
			keystr = append(keystr, fmt.Sprintf("  unique key %s (%s)", strings.Join(UniqueKey, "_"), strings.Join(UniqueKey, ", ")))
		}
		if len(IndexKey) > 0 {
			for _, v := range IndexKey {
				keystr = append(keystr, fmt.Sprintf("  key (%s)", v))
			}
		}

		_ = split
		table_sql += strings.Join(keystr, ",\n") + "\n"
		table_sql += `) ENGINE=InnoDB DEFAULT CHARSET=utf8 comment='` + table_comment + `';`

		if split == 1 {
			table_sql = strings.Replace(table_sql, real_tname, real_tname+"_$month", 1)
		} else if split == 2 {
			table_sql = strings.Replace(table_sql, real_tname, real_tname+"_$day", 1)
		}

		// 字段

		tabledata := &TableData{
			ModelName: GetFirstUpper(real_tname),
			TableName: real_tname,
			Split:     split,
			Sql:       table_sql,
			Field:     FieldMapData,
		}

		jsondata.LogTableData = append(jsondata.LogTableData, tabledata)

		fmt.Println(table_sql)
	}

	// 生成json文件
	file, err := os.OpenFile("./json/LogTableData.json", os.O_CREATE|os.O_RDWR|os.O_TRUNC, os.ModePerm)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer file.Close()

	wdata, err := json.MarshalIndent(jsondata, "", " ")
	if err != nil {
		fmt.Println("json 加密失败")
	}
	file.Write(wdata)
	fmt.Println("json文件写入完成")
}

func GetFieldSql(row []string, fielddata map[string]FieldData) string {
	// 字段名	值类型	长度 	默认值	是否主键	是否唯一键	是否索引	注释
	key := ""
	value := ""
	defval := ""
	field := row[0]
	typ := row[1]
	length := row[2]
	def := row[3]
	auto := row[4]
	pkey := row[5]
	ukey := row[6]
	ikey := row[7]
	comment := row[8]

	if auto == "是" && AutoIncrement == "" {
		AutoIncrement = " AUTO_INCREMENT"
	} else {
		AutoIncrement = ""
	}

	switch typ {
	case "int":
		if num, err := strconv.ParseInt(length, 10, 64); err == nil {
			if num < 3 {
				value = fmt.Sprintf("tinyint(%d)", num)
			} else if num < 6 {
				value = fmt.Sprintf("smallint(%d)", num)
			} else if num < 12 {
				value = fmt.Sprintf("int(%d)", num)
			} else if num < 20 {
				value = fmt.Sprintf("bigint(%d)", num)
			}
		}
	case "string":
		value = fmt.Sprintf("varchar(%s)", length)
	case "text":
		value = fmt.Sprintf("text")
	case "json":
		value = fmt.Sprintf("json")
	default:
		value = fmt.Sprintf("text")
	}

	if pkey == "是" {
		PrimaryKey = field
		key = "primaryKey"
	}
	if ukey == "是" {
		UniqueKey = append(UniqueKey, field)
		key = "primaryKey"
	}
	if ikey == "是" {
		IndexKey = append(IndexKey, field)
	}

	if def != "" {
		defval = " default '" + def + "'"
	} else {
		if pkey == "是" || ukey == "是" {
			defval = " not null"
		} else {
			defval = " default null"
		}
	}

	fielddata[field] = FieldData{
		Name: GetFirstUpper(field),
		Type: typ,
		Key:  key,
	}

	return `  ` + field + ` ` + value + AutoIncrement + defval + ` comment '` + comment + `',` + "\n"
}

// 获取第一个首字母大写，以_隔开
func GetFirstUpper(s string) string {
	return strings.Replace(strings.Title(strings.Replace(s, "_", " ", -1)), " ", "", -1)
}
