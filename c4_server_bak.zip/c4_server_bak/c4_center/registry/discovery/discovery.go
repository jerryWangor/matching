package discovery

import (
	"c4_center/registry"
	"sync"
	"sync/atomic"
)

type Discovery struct {
	nodeIdx uint64
	mutex   sync.RWMutex
	nodeMap map[string][]*registry.ServiceInstance
}

func NewDiscovery() *Discovery {
	d := &Discovery{
		nodeMap: make(map[string][]*registry.ServiceInstance),
	}
	return d
}

func (d *Discovery) PickNode(name string) *registry.ServiceInstance {
	d.mutex.Lock()
	defer d.mutex.Unlock()

	if len(d.nodeMap) == 0 {
		return nil
	}

	if _, ok := d.nodeMap[name]; !ok {
		return nil
	}

	atomic.AddUint64(&d.nodeIdx, 1)
	nodes := d.nodeMap[name]
	return nodes[atomic.LoadUint64(&d.nodeIdx)%uint64(len(nodes))]
}

func (d *Discovery) GetAllNode(name string) []*registry.ServiceInstance {
	d.mutex.Lock()
	defer d.mutex.Unlock()

	if len(d.nodeMap) == 0 {
		return nil
	}

	if _, ok := d.nodeMap[name]; !ok {
		return nil
	}

	nodes := d.nodeMap[name]
	return nodes
}

func (d *Discovery) GetSpecNode(name string, id string) *registry.ServiceInstance {
	d.mutex.Lock()
	defer d.mutex.Unlock()

	if _, ok := d.nodeMap[name]; !ok {
		return nil
	}

	for k, v := range d.nodeMap[name] {
		if v.ID == id {
			return d.nodeMap[name][k]
		}
	}

	return nil
}

func (d *Discovery) RefreshNode(name string, service ...*registry.ServiceInstance) {
	d.mutex.Lock()
	defer d.mutex.Unlock()

	//刷新指定所有service
	delete(d.nodeMap, name)
	for k := range service {
		d.nodeMap[name] = append(d.nodeMap[name], service[k])
	}
}
