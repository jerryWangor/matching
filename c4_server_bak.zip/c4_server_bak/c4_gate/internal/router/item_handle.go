package router

import (
	"c4_center/kproto"
	"c4_center/ktcp"
	"c4_gate/internal"

	"github.com/sirupsen/logrus"
)

//get rank info
func LobbyGetRankInfo(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RANKREWARD_RESP_ID), &kproto.LOBBY_RANKREWARD_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RANKREWARD_RESP_ID), &kproto.LOBBY_RANKREWARD_RESP{Code: -2})
	}
}

//receive reward of rank
func LobbyReceiveRankReward(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RECEIVE_RANKREWARD_RESP_ID), &kproto.LOBBY_RECEIVE_RANKREWARD_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_RECEIVE_RANKREWARD_RESP_ID), &kproto.LOBBY_RECEIVE_RANKREWARD_RESP{Code: -2})
	}
}

//get items
func LobbyGetItems(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ITEM_LIST_RESP_ID), &kproto.LOBBY_ITEM_LIST_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ITEM_LIST_RESP_ID), &kproto.LOBBY_ITEM_LIST_RESP{Code: -2})
	}
}

//item use
func LobbyItemUse(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ITEM_USE_RESP_ID), &kproto.LOBBY_ITEM_USE_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_ITEM_USE_RESP_ID), &kproto.LOBBY_ITEM_USE_RESP{Code: -2})
	}
}

//boxslot unlock
func LobbyBoxSlotUnlock(kctx ktcp.Context) {
	if internal.Sessions.GetSession(kctx.Session().ID().(string)) == nil {
		logrus.Error("not login.")
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_BOX_SLOT_UNLOCK_RESP_ID), &kproto.LOBBY_BOX_SLOT_UNLOCK_RESP{Code: -1})
		return
	}

	err := LobbyRpc(kctx)
	if err != nil {
		logrus.Error(err)
		kctx.SetResponse(uint32(kproto.MSG_LOBBY_BOX_SLOT_UNLOCK_RESP_ID), &kproto.LOBBY_BOX_SLOT_UNLOCK_RESP{Code: -2})
	}
}
