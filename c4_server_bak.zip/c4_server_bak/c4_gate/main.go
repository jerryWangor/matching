package main

import (
	"c4_center/klog"
	"c4_center/kmongo"
	"c4_center/kproto"
	"c4_center/kredis"
	"c4_center/ktcp"
	"c4_center/registry/etcd"
	"c4_gate/config"
	"c4_gate/gate_registry"
	"c4_gate/internal"
	"c4_gate/internal/router"
	"context"
	"net"
	"os"
	"os/signal"
	"syscall"
	"time"

	redisv8 "github.com/go-redis/redis/v8"
	"github.com/sirupsen/logrus"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/grpc"
)

func main() {
	//初始化配置
	config.Init("app.ini")
	//初始化logs
	klog.InitLog(config.LogsConfigInstant.Path, config.LogsConfigInstant.Level)
	//初始化mongo
	kmongo.Init(config.MongoConfigInstant.Mongo_DB, options.Client().ApplyURI(config.MongoConfigInstant.Mongo_addr))

	//初始化redis
	kredis.Init(&redisv8.Options{
		Addr:     config.RedisConfigInstant.Redis_addr,
		Password: config.RedisConfigInstant.Redis_pswd,
		DB:       config.RedisConfigInstant.Redis_DB,
		PoolSize: config.RedisConfigInstant.Redis_poolSize,
	})

	//初始化etcd
	gate_registry.InitGateRegistry(clientv3.Config{
		Endpoints:   config.EtcdConfigInstant.Etcd_endpoint,
		DialTimeout: time.Second, DialOptions: []grpc.DialOption{grpc.WithBlock()},
	}, etcd.RegisterTTL(time.Second*15))

	//注册etcd服务
	if err := gate_registry.EtcdClient.Register(config.GrpcServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	if err := gate_registry.EtcdClient.Register(config.TcpServiceInstant); err != nil {
		logrus.Fatal(err)
	}

	//监听所需etcd服务
	gate_registry.EtcdClient.Watch(gate_registry.LOBBY_SERVICE)
	gate_registry.EtcdClient.Watch(gate_registry.MATCH_SERVICE)
	gate_registry.EtcdClient.Watch(gate_registry.ROOM_SERVICE)
	gate_registry.EtcdClient.Watch(gate_registry.PAY_SERVICE)

	//启动rpc服务
	lis, err := net.Listen("tcp", config.GrpcConfigInstant.Grpc_addr)
	if err != nil {
		logrus.Fatalf("failed to listen: %v", err)
	}

	var opts []grpc.ServerOption
	grpcServer := grpc.NewServer(opts...)
	kproto.RegisterGateServiceServer(grpcServer, &internal.GateService{})
	// grpcServer.Serve(lis)
	go func() { grpcServer.Serve(lis) }()

	//启动tcp服务
	ktcp.SetLogger(logrus.StandardLogger())
	s := ktcp.NewServer(
		&ktcp.ServerOption{
			SocketReadBufferSize:  1024 * 1024,
			SocketWriteBufferSize: 1024 * 1024,
			ReadTimeout:           time.Minute * 3,
			WriteTimeout:          time.Minute * 3,
			RespQueueSize:         0,
			Packer:                ktcp.NewDefaultPacker(),
			Codec:                 &ktcp.ProtobufCodec{},
			AsyncRouter:           false,
		})

	s.OnSessionCreate = func(sess ktcp.Session) {
		logrus.Infof("connection session created: %v", sess.ID())
	}

	s.OnSessionClose = func(sess ktcp.Session) {
		ctx := sess.AllocateContext()
		if err := ctx.SetRequest(uint32(kproto.MSG_MATCH_CANCEL_REQ_ID), &kproto.MATCH_CANCEL_REQ{}); err != nil {
			logrus.Info(err)
		} else {
			router.MatchCancel(ctx)
		}

		//标识位!=0 时不处理
		if sess.Flag() == 0 {
			//update logout time
			kmongo.UpdateOne(context.TODO(), kmongo.AccountCollection, bson.M{"user_id": sess.ID().(string)}, bson.M{"$set": bson.M{"logout_time": time.Now()}})
			//remove session
			internal.Sessions.RemoveSession(sess.ID().(string))
			logrus.Warnf("connection session closed: %v", sess.ID())
		}
	}

	//set middlewares
	s.Use(router.RecoverMiddleware())
	//set routes
	s.AddRoute(uint32(kproto.MSG_GATE_CONN_REQ_ID), router.Connection)
	s.AddRoute(uint32(kproto.MSG_GATE_HEARTBEAT_REQ_ID), router.HeartBeat)
	s.AddRoute(uint32(kproto.MSG_GATE_ENTER_LOBBY_REQ_ID), router.EnterLobby)
	s.AddRoute(uint32(kproto.MSG_LOBBY_ACTIVITY_REQ_ID), router.LobbyGetActivity)
	s.AddRoute(uint32(kproto.MSG_LOBBY_ACTIVITY_ASSIGN_REQ_ID), router.LobbyGetActivityAssign)
	s.AddRoute(uint32(kproto.MSG_LOBBY_HERO_REQ_ID), router.LobbyGetHeroes)
	s.AddRoute(uint32(kproto.MSG_LOBBY_HERO_POS_REQ_ID), router.LobbyGetHeroes)
	s.AddRoute(uint32(kproto.MSG_LOBBY_GM_REQ_ID), router.LobbyGmOrder)
	s.AddRoute(uint32(kproto.MSG_MATCH_REQUEST_REQ_ID), router.MatchRequest)
	s.AddRoute(uint32(kproto.MSG_MATCH_CANCEL_REQ_ID), router.MatchCancel)
	s.AddRoute(uint32(kproto.MSG_LOBBY_ITEM_LIST_REQ_ID), router.LobbyGetItems)
	s.AddRoute(uint32(kproto.MSG_LOBBY_ITEM_USE_REQ_ID), router.LobbyItemUse)
	s.AddRoute(uint32(kproto.MSG_LOBBY_BOX_SLOT_UNLOCK_REQ_ID), router.LobbyBoxSlotUnlock)
	s.AddRoute(uint32(kproto.MSG_LOBBY_HERO_LEVEL_UP_REQ_ID), router.LobbyHeroLeveUp)
	s.AddRoute(uint32(kproto.MSG_LOBBY_SIGN_IN_REQ_ID), router.LobbySignIn)
	s.AddRoute(uint32(kproto.MSG_LOBBY_RANKREWARD_REQ_ID), router.LobbyGetRankInfo)
	s.AddRoute(uint32(kproto.MSG_LOBBY_RECEIVE_RANKREWARD_REQ_ID), router.LobbyReceiveRankReward)
	s.AddRoute(uint32(kproto.MSG_LOBBY_SHOP_REQ_ID), router.LobbyGetShop)
	s.AddRoute(uint32(kproto.MSG_LOBBY_SHOP_BUY_REQ_ID), router.LobbyShopBuy)
	s.AddRoute(uint32(kproto.MSG_LOBBY_RANKING_REQ_ID), router.LobbyGetRanking)
	s.AddRoute(uint32(kproto.MSG_PAY_GET_ORDER_REQ_ID), router.PayGetOrder)
	s.AddRoute(uint32(kproto.MSG_PAY_CALLBACK_REQ_ID), router.PayCallBack)
	s.AddRoute(uint32(kproto.MSG_PAY_CHECK_AWAIT_ORDER_REQ_ID), router.PayCheckAwaitOrder)

	go func() {
		if err := s.Serve(config.TcpConfigInstant.Tcp_addr); err != nil {
			logrus.Errorf("serve err: %s", err)
		}
	}()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	<-sigCh
	if err := s.Stop(); err != nil {
		logrus.Errorf("server stopped err: %s", err)
	}
}
